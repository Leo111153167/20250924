
using GamingIsLove.Makinom;
using UnityEditor;
using UnityEngine;

namespace GamingIsLove.Makinom.Editor
{
	public class LanguagesTab : GenericAssetListTab<LanguageAsset, Language>
	{
		// import/export settings
		protected EditorLanguageExporter exporter = new EditorLanguageExporter();

		protected EditorLanguageExporter.ImportData importer;

		protected bool filePerSubSection = false;

		protected string schematicFolder = "";

		protected bool filePerSchematic = false;

		protected MakinomSchematicAsset schematicAsset;


		public LanguagesTab(MakinomEditorWindow parent) : base(parent)
		{
			Maki.Languages.SetAssets(this.assetList.Assets);
		}

		public override void Reloaded()
		{
			base.Reloaded();
			Maki.Languages.SetAssets(this.assetList.Assets);
		}

		public override void DefaultSetup()
		{
			if(this.assetList.Assets.Count == 0)
			{
				LanguageAsset asset = ScriptableObject.CreateInstance<LanguageAsset>();
				asset.Settings = new Language("English");
				this.assetList.Add(asset);
			}
		}


		/*
		============================================================================
		Properties
		============================================================================
		*/
		public override string Name
		{
			get { return "Languages"; }
		}

		public override string HelpText
		{
			get
			{
				return "Set up languages you want to use in your game.\n" +
					"All texts that are displayed to the player can be set up in the defined languages.";
			}
		}

		public override string HelpInfo
		{
			get { return "https://makinom.com/guide/documentation/features/languages/"; }
		}

		public override void ShowSettings()
		{
			base.ShowSettings();

			// import/export
			if(this.BeginFoldout("Language Export/Import", "Import or export language data, e.g. for translations.", "", true))
			{
				EditorAutomation.Automate(this.exporter, this);

				// export
				if(this.BeginFoldout("Export Language Data", "Export language data into files.", "", true))
				{
					EditorTool.BoldLabel("Export Settings");
					EditorTool.Field("File Per Sub-Section", ref this.filePerSubSection, "Create a file for each sub-section in the editor.", "", null, null);
					if(EditorTool.Button("Export Settings", "Exports all language texts in settings.", ""))
					{
						this.exporter.ExportSettings(this.filePerSubSection);
					}

					EditorGUILayout.Separator();
					EditorTool.BoldLabel("Export Scenes");
					if(EditorTool.Button("Export Scenes", "Exports all language texts in scenes.", ""))
					{
						if(EditorUtility.DisplayDialog("Export Scenes", "Exports all scenes added to Unity's build settings.\n" +
							"Please save your current scene before exporting, or the changes you made without saving will be lost.",
							"Export", "Cancel"))
						{
							this.exporter.ExportScenes();
						}
					}

					EditorGUILayout.Separator();
					EditorTool.BoldLabel("Export Prefabs");
					if(EditorTool.Button("Export Prefabs", "Exports all language texts in prefabs.", ""))
					{
						this.exporter.ExportPrefabs();
					}

					EditorGUILayout.Separator();
					EditorTool.BoldLabel("Export Schematics");
					EditorTool.Field("File Per Schematic", ref this.filePerSchematic, "Create a file for each schematic.\n" +
						"The files will be organized in sub-folders as the schematics are in the Unity project.", "", null, null);
					EditorTool.ExpandedTextField("Folder (in Assets)", ref this.schematicFolder,
						"You can optionally only export language data of schematics in a defined folder in the Assets path.", "");
					if(EditorTool.Button("Export Schematics", "Exports all language texts in schematics.", ""))
					{
						this.exporter.ExportSchematics(this.schematicFolder, this.filePerSchematic);
					}

					EditorGUILayout.Separator();
					EditorTool.Field("Schematic Asset", ref this.schematicAsset, "Select the schematic you want to export.", "", null, null);
					EditorGUI.BeginDisabledGroup(this.schematicAsset == null);
					if(EditorTool.Button("Export Schematic", "Exports all language texts of the selected schematic.", ""))
					{
						this.exporter.ExportSchematic(this.schematicAsset);
					}
					EditorGUI.EndDisabledGroup();
				}
				this.EndFoldout();


				// import
				if(this.BeginFoldout("Import Language Data", "Import language data from a selected file.", "", true))
				{
					EditorGUILayout.BeginHorizontal();
					if(EditorTool.Button("Load Exported File", "Loads an exported file's data.\n" +
						"You can import it as settings, scenes, prefabs or schematics language data after loading the data.", ""))
					{
						this.importer = this.exporter.LoadImportFile();
					}
					if(this.importer != null)
					{
						if(EditorTool.Button("Clear File Data", "Removes the import file's data.", ""))
						{
							this.importer = null;
						}
					}
					GUILayout.FlexibleSpace();
					EditorGUILayout.EndHorizontal();

					// import data
					if(this.importer != null)
					{
						EditorGUILayout.Separator();
						EditorGUILayout.LabelField("File", this.importer.path);
						EditorGUILayout.LabelField("Data Count", this.importer.import.Count.ToString());

						for(int i = 0; i < this.importer.language.Length; i++)
						{
							EditorGUILayout.Separator();
							EditorTool.Field("Import " + this.importer.language[i].name, ref this.importer.language[i].import,
								"Import this language's export data.", "", null, this);
							EditorAutomation.Automate(this.importer.language[i], this);
						}

						EditorGUILayout.Separator();
						EditorGUILayout.Separator();
						EditorTool.BoldLabel("Import Settings");
						if(EditorTool.Button("Import Settings", "Import the selected language texts into the settings.", ""))
						{
							this.exporter.ImportSettings(this.importer);
						}

						EditorGUILayout.Separator();
						EditorTool.BoldLabel("Import Scenes");
						if(EditorTool.Button("Import Scenes", "Imports the selected language texts into all scenes.", ""))
						{
							if(EditorUtility.DisplayDialog("Import Scenes", "Imports into all scenes added to Unity's build settings.\n" +
								"Please save your current scene before importing, or the changes you made without saving will be lost.",
								"Import", "Cancel"))
							{
								this.exporter.ImportScenes(this.importer);
							}
						}

						EditorGUILayout.Separator();
						EditorTool.BoldLabel("Import Prefabs");
						if(EditorTool.Button("Import Prefabs", "Imports the selected language texts into all prefabs.", ""))
						{
							this.exporter.ImportPrefabs(this.importer);
						}

						EditorGUILayout.Separator();
						EditorTool.BoldLabel("Import Schematics");
						EditorTool.ExpandedTextField("Folder (in Assets)", ref this.schematicFolder,
							"You can optionally only import language data into schematics in a defined folder in the Assets path.", "");
						if(EditorTool.Button("Import Schematics", "Imports the selected language texts into all schematics.", ""))
						{
							this.exporter.ImportSchematics(this.importer, this.schematicFolder);
						}

						EditorGUILayout.Separator();
						EditorTool.Field("Schematic Asset", ref this.schematicAsset, "Select the schematic you want to import to.", "", null, null);
						EditorGUI.BeginDisabledGroup(this.schematicAsset == null);
						if(EditorTool.Button("Import Schematic", "Imports the selected language texts into the selected schematic.", ""))
						{
							this.exporter.ImportSchematic(this.importer, this.schematicAsset);
						}
						EditorGUI.EndDisabledGroup();
					}
				}
				this.EndFoldout();
			}
			this.EndFoldout();
		}


		/*
		============================================================================
		Automation callbacks
		============================================================================
		*/
		public override void AutomationCallback(string info)
		{
			if(info == "check:initiallanguage")
			{
				if(this.assetList.AssetExists(this.index) &&
					this.assetList.Assets[this.index].Settings.initialLanguage)
				{
					for(int i = 0; i < this.assetList.Count; i++)
					{
						if(i != this.index)
						{
							this.assetList.Assets[i].Settings.initialLanguage = false;
						}
					}
				}
			}
			else
			{
				base.AutomationCallback(info);
			}
		}
	}
}

