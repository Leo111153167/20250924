
using GamingIsLove.Makinom;
using UnityEditor;
using UnityEngine;

namespace GamingIsLove.Makinom.Editor
{
	public class VariableConditionTemplatesTab : GenericAssetListTab<VariableConditionTemplateAsset, VariableConditionTemplate>
	{
		public VariableConditionTemplatesTab(MakinomEditorWindow parent) : base(parent)
		{

		}


		/*
		============================================================================
		Properties
		============================================================================
		*/
		public override string Name
		{
			get { return "Variable Condition Templates"; }
		}

		public override string HelpText
		{
			get { return "Set up reusable templates for variable condition checks."; }
		}

		public override string HelpInfo
		{
			get { return "https://makinom.com/guide/documentation/features/variables/"; }
		}
	}
}

