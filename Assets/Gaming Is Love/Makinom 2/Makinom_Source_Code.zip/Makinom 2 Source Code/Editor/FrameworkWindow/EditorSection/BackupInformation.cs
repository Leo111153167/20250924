
using UnityEngine;
using UnityEditor;
using GamingIsLove.Makinom;
using System.Collections.Generic;

namespace GamingIsLove.Makinom.Editor
{
	public class BackupInformation
	{
		public string path;

		public string date;

		public BackupInformation(string path)
		{
			this.path = path;

			long ticks = 0;
			int p = this.path.LastIndexOf("/");
			int p2 = this.path.LastIndexOf(".");
			if(p >= 0 && p + 1 < this.path.Length &&
				p2 >= 0 && p2 + 1 < this.path.Length)
			{
				long.TryParse(this.path.Substring(p + 1, p2 - p - 1), out ticks);
			}
			this.date = new System.DateTime(ticks).ToString();
		}
	}
}

