
using GamingIsLove.Makinom;
using UnityEditor;
using UnityEngine;

namespace GamingIsLove.Makinom.Editor
{
	public class MachineTypesTab : GenericAssetListTab<MachineTypeAsset, MachineTypeSetting>
	{
		public MachineTypesTab(MakinomEditorWindow parent) : base(parent)
		{

		}


		/*
		============================================================================
		Properties
		============================================================================
		*/
		public override string Name
		{
			get { return "Machine Types"; }
		}

		public override string HelpText
		{
			get
			{
				return "Use machine types to assign different types to machines.\n" +
					"You can e.g. use this to display different 'Interaction' HUDs based on the machine type.";
			}
		}

		public override string HelpInfo
		{
			get { return ""; }
		}
	}
}
