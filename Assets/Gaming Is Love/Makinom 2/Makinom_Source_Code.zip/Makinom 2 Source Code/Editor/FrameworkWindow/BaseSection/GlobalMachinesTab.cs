
using GamingIsLove.Makinom;
using UnityEditor;
using UnityEngine;

namespace GamingIsLove.Makinom.Editor
{
	public class GlobalMachinesTab : GenericAssetListTab<GlobalMachineAsset, GlobalMachine>
	{
		public GlobalMachinesTab(MakinomEditorWindow parent) : base(parent)
		{
			Maki.GlobalMachines.SetAssets(this.assetList.Assets);
		}

		public override void Reloaded()
		{
			base.Reloaded();
			Maki.GlobalMachines.SetAssets(this.assetList.Assets);
		}


		/*
		============================================================================
		Properties
		============================================================================
		*/
		public override string Name
		{
			get { return "Global Machines"; }
		}

		public override string HelpText
		{
			get
			{
				return "Set up machines/schematics that can be called anytime (e.g. from another schematic).\n" +
					"Global machines can also start automatically, e.g. every second or when changing scenes.";
			}
		}

		public override string HelpInfo
		{
			get { return "https://makinom.com/guide/documentation/machines/global-machine/"; }
		}
	}
}
