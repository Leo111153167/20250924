
using GamingIsLove.Makinom;
using UnityEditor;
using UnityEngine;

namespace GamingIsLove.Makinom.Editor
{
	public class SoundTypesTab : GenericAssetListTab<SoundTypeAsset, SoundType>
	{
		public SoundTypesTab(MakinomEditorWindow parent) : base(parent)
		{

		}


		/*
		============================================================================
		Properties
		============================================================================
		*/
		public override string Name
		{
			get { return "Sound Types"; }
		}

		public override string HelpText
		{
			get
			{
				return "Use sound types to set up audio clips in sound assignments.\n" +
					"This allows you to play different audio clips on different objects, while they're played using the same sound type.\n" +
					"E.g. a 'Damage' sound type could play different audio clips on individual enemies.";
			}
		}

		public override string HelpInfo
		{
			get { return "https://makinom.com/guide/documentation/features/audio-and-music/"; }
		}
	}
}

