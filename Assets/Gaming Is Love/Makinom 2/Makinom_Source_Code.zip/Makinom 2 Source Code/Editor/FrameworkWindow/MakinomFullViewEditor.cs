﻿
using UnityEngine;
using UnityEditor;
using System.Collections.Generic;

namespace GamingIsLove.Makinom.Editor
{
	public abstract class MakinomFullViewEditor : BaseEditor
	{
		protected MakinomEditorWindow parent;

		public MakinomFullViewEditor(MakinomEditorWindow parent)
		{
			this.parent = parent;

			this.isInspector = false;
			this.repaint = this.parent.Repaint;
		}

		public virtual bool ShowGUI()
		{
			this.ClearShow();
			return false;
		}
	}
}
