
using GamingIsLove.Makinom;
using GamingIsLove.Makinom.Editor;
using GamingIsLove.Makinom.Components;
using GamingIsLove.Makinom.Schematics;
using UnityEditor;
using UnityEngine;

[CustomEditor(typeof(TickMachineComponent))]
public class TickMachineInspector : BaseMachineInspector
{
	public override void OnInspectorGUI()
	{
		this.MachineSetup(target as TickMachineComponent);
	}

	private void MachineSetup(TickMachineComponent target)
	{
		serializedObject.Update();
		Undo.RecordObject(target, "Change to 'Tick Machine' on " + target.name);
		this.BaseInit(true);

		EditorAutomation.Automate(target.settings, this.baseEditor);

		this.BaseMachineSetup(target);

		this.EndSetup();
	}
}
