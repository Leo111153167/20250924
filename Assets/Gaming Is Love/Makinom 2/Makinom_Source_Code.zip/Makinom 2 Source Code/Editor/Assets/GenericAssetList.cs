﻿
using UnityEngine;
using UnityEditor;
using System.Collections.Generic;
using System.IO;
using System.Reflection;

namespace GamingIsLove.Makinom.Editor
{
	public interface IAssetList
	{
		void FindAssets();

		void GetAssets(ref List<IMakinomGenericAsset> list);

		List<string> GetNames(bool addIndex);

		IMakinomGenericAsset GetAssetAt(int index);

		IMakinomGenericAsset GetAssetForGUID(string guid);

		int AssetToIndex(IMakinomGenericAsset asset);

		string IndexToGUID(int index);

		bool ContainsGUID(string guid);

		IMakinomGenericAsset Add();

		void GetFileDifferences(bool encrypt, DataFile.SaveFormatType format,
			ref List<string> list, ref Dictionary<IMakinomGenericAsset, DataFile> dataFiles);

		void SaveChanges(bool encrypt, DataFile.SaveFormatType format,
			string dataPath, bool saveAssetDatabase, string saveTime,
			Dictionary<IMakinomGenericAsset, DataFile> dataFiles);

		void GetVariables(ref List<string> list);

		void ReplaceVariable(string oldKey, string newKey);

		void GetLanguageExport(bool resetExportIDs, GetInt getExportID, ref List<LanguageData.Export> export);

		void SetLanguageImport(bool[] importLanguage, LanguageAsset[] languageAsset, Dictionary<int, LanguageData.Import> import);
	}

	public class GenericAssetList<T> : IAssetList where T : ScriptableObject, IMakinomGenericAsset
	{
		private List<T> assets = new List<T>();

		private HashSet<T> addedAssets = new HashSet<T>();

		private List<T> removedAssets = new List<T>();

		public GenericAssetList()
		{
			this.FindAssets();
		}

		public void FindAssets()
		{
			this.assets.Clear();
			this.addedAssets.Clear();
			this.removedAssets.Clear();

			List<Object> allAssets = EditorDataHandler.Instance.AllAssets;
			for(int i = 0; i < allAssets.Count; i++)
			{
				if(allAssets[i] is T)
				{
					T asset = (T)allAssets[i];
					if(!Application.isPlaying)
					{
						asset.ClearData();
						asset.LoadData();
					}
					EditorDataHandler.DataLoaded(asset.EditorSettings);
					this.assets.Add(asset);
				}
			}

			this.SortByIndex();
		}

		public void GetAssets(ref List<IMakinomGenericAsset> list)
		{
			for(int i = 0; i < this.assets.Count; i++)
			{
				list.Add(this.assets[i]);
			}
		}

		public int AssetToIndex(IMakinomGenericAsset asset)
		{
			for(int i = 0; i < this.assets.Count; i++)
			{
				if(this.assets[i] == asset)
				{
					return i;
				}
			}
			return 0;
		}

		public List<string> GetNames(bool addIndex)
		{
			List<string> list = new List<string>();
			for(int i = 0; i < this.assets.Count; i++)
			{
				list.Add((addIndex ? i + ": " : "") +
					(this.assets[i] != null ? this.assets[i].EditorSettings.EditorName : ""));
			}
			return list;
		}

		public IMakinomGenericAsset GetAssetAt(int index)
		{
			if(this.AssetExists(index))
			{
				return this.assets[index];
			}
			return null;
		}

		public IMakinomGenericAsset GetAssetForGUID(string guid)
		{
			for(int i = 0; i < this.assets.Count; i++)
			{
				if(this.assets[i] != null &&
					this.assets[i].EditorSettings.GUID == guid)
				{
					return this.assets[i];
				}
			}
			return null;
		}


		/*
		============================================================================
		Properties
		============================================================================
		*/
		public int Count
		{
			get { return this.assets.Count; }
		}

		public bool AssetExists(int index)
		{
			return index >= 0 &&
				index < this.assets.Count &&
				this.assets[index] != null;
		}

		public List<T> Assets
		{
			get { return this.assets; }
		}


		/*
		============================================================================
		List functions
		============================================================================
		*/
		public IMakinomGenericAsset Add()
		{
			T asset = ScriptableObject.CreateInstance<T>();
			asset.EditorSettings.EditorName = "New";
			while(this.ContainsGUID(asset.EditorSettings.GUID))
			{
				asset.EditorSettings.GenerateGUID();
			}
			asset.Index = this.assets.Count;
			this.assets.Add(asset);
			this.addedAssets.Add(asset);

			return asset;
		}

		public ScriptableObject Add(T asset)
		{
			while(this.ContainsGUID(asset.EditorSettings.GUID))
			{
				asset.EditorSettings.GenerateGUID();
			}
			asset.Index = this.assets.Count;
			this.assets.Add(asset);
			this.addedAssets.Add(asset);

			return asset;
		}

		public ScriptableObject Copy(int index)
		{
			if(this.AssetExists(index))
			{
				T asset = ScriptableObject.CreateInstance<T>();
				asset.SetData(this.assets[index].EditorSettings.GetData());
				if(EditorCopyNameType.AppendFront == Maki.EditorSettings.copyNameType)
				{
					asset.EditorSettings.EditorName = "COPY " + asset.EditorSettings.DataName;
				}
				else if(EditorCopyNameType.AppendBack == Maki.EditorSettings.copyNameType)
				{
					asset.EditorSettings.EditorName = asset.EditorSettings.DataName + " COPY";
				}
				asset.EditorSettings.GenerateGUID();
				while(this.ContainsGUID(asset.EditorSettings.GUID))
				{
					asset.EditorSettings.GenerateGUID();
				}
				asset.Index = this.assets.Count;
				this.assets.Add(asset);
				this.addedAssets.Add(asset);

				return asset;
			}
			return null;
		}

		public void Remove(int index)
		{
			if(this.AssetExists(index))
			{
				T asset = this.assets[index];
				this.assets.RemoveAt(index);
				this.removedAssets.Add(asset);
				this.SetIndexes();

				EditorDataHandler.Instance.Removed(asset.GetType(), asset, asset.EditorSettings.GUID);
			}
		}

		public void Move(int index, int change)
		{
			if(this.AssetExists(index))
			{
				T asset = this.assets[index];
				this.assets.RemoveAt(index);
				this.assets.Insert(index + change, asset);
				this.SetIndexes();
			}
		}

		public string IndexToGUID(int index)
		{
			if(this.AssetExists(index))
			{
				return this.assets[index].EditorSettings.GUID;
			}
			return "";
		}

		public bool ContainsGUID(string guid)
		{
			for(int i = 0; i < this.assets.Count; i++)
			{
				if(this.assets[i] != null &&
					this.assets[i].EditorSettings.GUID == guid)
				{
					return true;
				}
			}
			return false;
		}


		/*
		============================================================================
		Save functions
		============================================================================
		*/
		public void GetFileDifferences(bool encrypt, DataFile.SaveFormatType format,
			ref List<string> list, ref Dictionary<IMakinomGenericAsset, DataFile> dataFiles)
		{
			bool added = false;
			for(int i = 0; i < this.assets.Count; i++)
			{
				if(this.assets[i] != null)
				{
					DataFile file = null;
					if(this.assets[i].Index != i ||
						this.assets[i].HasChanged(encrypt, format, out file))
					{
						dataFiles.Add(this.assets[i], file);
						this.assets[i].MarkedForSaving = true;
						if(!added)
						{
							added = true;
							if(list.Count > 0)
							{
								list.Add("");
							}
							list.Add("<b>" + this.assets[i].DataName + "</b>");
						}
						if(this.addedAssets.Contains(this.assets[i]))
						{
							list.Add("<color=green>[+]</color> <i>" + i + ": " + this.assets[i].EditorSettings.EditorName + "</i>");
						}
						else
						{
							list.Add(i + ": " + this.assets[i].EditorSettings.EditorName);
						}
					}
				}
			}
			for(int i = 0; i < this.removedAssets.Count; i++)
			{
				if(this.removedAssets[i] != null)
				{
					if(!added)
					{
						added = true;
						if(list.Count > 0)
						{
							list.Add("");
						}
						list.Add("<b>" + this.removedAssets[i].DataName + "</b>");
					}
					list.Add("<color=red>[-]</color> <i>" + this.removedAssets[i].Index + ": " + this.removedAssets[i].EditorSettings.EditorName + "</i>");
				}
			}
		}

		private static char[] NotAllowedCharacters = new char[] { '/', '?', '<', '>', '\\', ':', '*', '|', '"', '\n', '\r' };

		public void SaveChanges(bool encrypt, DataFile.SaveFormatType format,
			string dataPath, bool saveAssetDatabase, string saveTime,
			Dictionary<IMakinomGenericAsset, DataFile> dataFiles)
		{
			if(this.assets.Count > 0)
			{
				this.SetIndexes();
				string tmpPath = dataPath;
				bool createFolder = true;

				for(int i = 0; i < this.assets.Count; i++)
				{
					if(this.assets[i] != null &&
						this.assets[i].MarkedForSaving)
					{
						try
						{
							this.assets[i].SortAtEnd = false;

							if(createFolder)
							{
								createFolder = false;
								tmpPath = dataPath + this.assets[i].DataName + "/";
								MakinomAssetHelper.CreateFolder(tmpPath);
							}

							string path = AssetDatabase.GetAssetPath(this.assets[i]);
							string fileName = this.assets[i].Index + " - " + this.assets[i].EditorSettings.EditorName;
							if(fileName.IndexOfAny(NotAllowedCharacters) >= 0)
							{
								fileName = fileName.
									Replace('/', '_').
									Replace('?', '_').
									Replace('<', '_').
									Replace('>', '_').
									Replace('\\', '_').
									Replace(':', '_').
									Replace('*', '_').
									Replace('|', '_').
									Replace('"', '_').
									Replace('\n', '_').
									Replace('\r', '_');
							}

							// new asset
							if(string.IsNullOrEmpty(path))
							{
								AssetDatabase.CreateAsset(this.assets[i],
									AssetDatabase.GenerateUniqueAssetPath(tmpPath + fileName + ".asset"));
								EditorUtility.SetDirty(this.assets[i]);
								AssetDatabase.SaveAssets();
							}
							// rename
							else if(this.assets[i].name != fileName)
							{
								AssetDatabase.RenameAsset(path,
									AssetDatabase.GenerateUniqueAssetPath(tmpPath + fileName + ".asset").
										Replace(tmpPath, ""));
								EditorUtility.SetDirty(this.assets[i]);
								AssetDatabase.SaveAssets();
							}

							DataFile file = null;
							dataFiles.TryGetValue(this.assets[i], out file);
							this.assets[i].SaveData(file, encrypt, format);

							EditorUtility.SetDirty(this.assets[i]);
							if(saveAssetDatabase)
							{
								AssetDatabase.SaveAssets();
								AssetDatabase.Refresh();
							}
						}
						catch(System.Exception ex)
						{
							Debug.LogWarning("An issue occured while saving " + this.assets[i].name + ": " + ex.Message + "\n" + ex.StackTrace);
						}
					}
				}
			}
			this.addedAssets.Clear();
			this.removedAssets.Clear();
		}

		public void GetVariables(ref List<string> list)
		{
			for(int i = 0; i < this.assets.Count; i++)
			{
				if(this.assets[i] != null)
				{
					DataSerializer.GetVariables(this.assets[i].EditorSettings, ref list);
				}
			}
		}

		public void ReplaceVariable(string oldKey, string newKey)
		{
			for(int i = 0; i < this.assets.Count; i++)
			{
				if(this.assets[i] != null)
				{
					DataSerializer.ReplaceVariable(this.assets[i].EditorSettings, oldKey, newKey);
				}
			}
		}

		public void GetLanguageExport(bool resetExportIDs, GetInt getExportID, ref List<LanguageData.Export> export)
		{
			for(int i = 0; i < this.assets.Count; i++)
			{
				if(this.assets[i] != null)
				{
					DataSerializer.GetLanguageExport(this.assets[i].EditorSettings, resetExportIDs, getExportID, "", ref export);
				}
			}
		}

		public void SetLanguageImport(bool[] importLanguage, LanguageAsset[] languageAsset, Dictionary<int, LanguageData.Import> import)
		{
			bool hasImported = false;
			for(int i = 0; i < this.assets.Count; i++)
			{
				if(this.assets[i] != null)
				{
					DataSerializer.SetLanguageImport(this.assets[i].EditorSettings, ref hasImported, importLanguage, languageAsset, import);
					EditorDataHandler.Instance.CheckLanguageImportAssetReferences(this.assets[i].EditorSettings);
				}
			}
		}


		/*
		============================================================================
		Sorting functions
		============================================================================
		*/
		public void SortByIndex()
		{
			this.assets.Sort(new AssetIndexSorter());
		}

		public void SortByName(bool inverse)
		{
			this.assets.Sort(new AssetNameSorter(inverse));
			this.SetIndexes();
		}

		public void SortByTypeName(bool inverse)
		{
			this.assets.Sort(new AssetTypeNameSorter(inverse));
			this.SetIndexes();
		}

		public void SetIndexes()
		{
			for(int i = 0; i < this.assets.Count; i++)
			{
				if(this.assets[i] != null)
				{
					this.assets[i].Index = i;
				}
			}
		}

		private class AssetIndexSorter : IComparer<T>
		{
			public int Compare(T x, T y)
			{
				if(x.SortAtEnd &&
					!y.SortAtEnd)
				{
					return 1;
				}
				else if(!x.SortAtEnd &&
					y.SortAtEnd)
				{
					return -1;
				}
				return x.Index.CompareTo(y.Index);
			}
		}

		private class AssetNameSorter : IComparer<T>
		{
			private bool inverse = false;

			public AssetNameSorter(bool inverse)
			{
				this.inverse = inverse;
			}

			public int Compare(T x, T y)
			{
				if(x.EditorSettings == null &&
					y.EditorSettings == null)
				{
					return 0;
				}
				else if(x.EditorSettings == null &&
					y.EditorSettings != null)
				{
					return this.inverse ? 1 : -1;
				}
				else if(x.EditorSettings != null &&
					y.EditorSettings == null)
				{
					return this.inverse ? -1 : 1;
				}
				else if(this.inverse)
				{
					return y.EditorSettings.EditorName.CompareTo(x.EditorSettings.EditorName);
				}
				else
				{
					return x.EditorSettings.EditorName.CompareTo(y.EditorSettings.EditorName);
				}
			}
		}

		private class AssetTypeNameSorter : IComparer<T>
		{
			private bool inverse = false;

			public AssetTypeNameSorter(bool inverse)
			{
				this.inverse = inverse;
			}

			public int Compare(T x, T y)
			{
				IHasTypeAsset typeX = x as IHasTypeAsset;
				IHasTypeAsset typeY = y as IHasTypeAsset;

				if((typeX == null ||
						typeX.TypeAsset == null ||
						typeX.TypeAsset.EditorSettings == null) &&
					(typeY == null ||
						typeY.TypeAsset == null ||
						typeY.TypeAsset.EditorSettings == null))
				{
					return this.CheckName(x, y);
				}
				else if((typeX == null ||
						typeX.TypeAsset == null ||
						typeX.TypeAsset.EditorSettings == null) &&
					typeY != null &&
					typeY.TypeAsset != null &&
					typeY.TypeAsset.EditorSettings != null)
				{
					return this.inverse ? 1 : -1;
				}
				else if(typeX != null &&
					typeX.TypeAsset != null &&
					typeX.TypeAsset.EditorSettings != null &&
					(typeY == null ||
						typeY.TypeAsset == null ||
						typeY.TypeAsset.EditorSettings == null))
				{
					return this.inverse ? -1 : 1;
				}
				else if(this.inverse)
				{
					int result = typeY.TypeAsset.EditorSettings.EditorName.CompareTo(typeX.TypeAsset.EditorSettings.EditorName);
					if(result == 0)
					{
						return this.CheckName(x, y);
					}
					else return result;
				}
				else
				{
					int result = typeX.TypeAsset.EditorSettings.EditorName.CompareTo(typeY.TypeAsset.EditorSettings.EditorName);
					if(result == 0)
					{
						return this.CheckName(x, y);
					}
					else return result;
				}
			}

			private int CheckName(T x, T y)
			{
				if(x.EditorSettings == null &&
					y.EditorSettings == null)
				{
					return 0;
				}
				else if(x.EditorSettings == null &&
					y.EditorSettings != null)
				{
					return this.inverse ? 1 : -1;
				}
				else if(x.EditorSettings != null &&
					y.EditorSettings == null)
				{
					return this.inverse ? -1 : 1;
				}
				else if(this.inverse)
				{
					return y.EditorSettings.EditorName.CompareTo(x.EditorSettings.EditorName);
				}
				else
				{
					return x.EditorSettings.EditorName.CompareTo(y.EditorSettings.EditorName);
				}
			}
		}
	}
}
