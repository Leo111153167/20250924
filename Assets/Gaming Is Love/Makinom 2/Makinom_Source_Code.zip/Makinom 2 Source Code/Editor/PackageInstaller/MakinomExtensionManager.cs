﻿
using UnityEngine;
using UnityEditor;
using System.Collections.Generic;
using System.Net;

namespace GamingIsLove.Makinom.Editor.Packages
{
	public class MakinomExtensionManager : EditorWindow
	{
		protected static string ExtensionListName = "ExtensionList.txt";

		protected static string SectionStart = "<section>";

		protected static string SectionEnd = "</section>";

		protected static string DownloadStart = "<download>";

		protected static string DownloadEnd = "</download>";

		protected static MakinomExtensionManager instance;


		// infos
		protected WebClient client;

		protected int progress = 0;

		protected int downloadIndex = 0;

		protected List<System.Uri> downloads = new List<System.Uri>();

		protected List<string> path = new List<string>();

		protected Vector2 scrollView = Vector2.zero;

		protected Dictionary<string, Section> sections = new Dictionary<string, Section>();

		protected string[] sectionNames = new string[0];

		protected int currentSection = 0;

		[MenuItem("Window/Gaming Is Love/Makinom Extension Manager", false, 2540)]
		public static void ShowExtensionManager()
		{
			instance = EditorWindow.GetWindow<MakinomExtensionManager>(false, "Makinom Extension Manager", true);
			instance.minSize = new Vector2(500, 400);
			instance.Show();
		}

		protected virtual void OnEnable()
		{
			this.Init();
		}


		/*
		============================================================================
		List functions
		============================================================================
		*/
		public virtual void Init()
		{
			MakinomAssetHelper.CreateFolder(MakinomAssetHelper.DOWNLOAD_PATH);

			this.downloadIndex = 0;
			this.downloads.Add(new System.Uri("https://makinom.com/resources/downloads/extensions/" + MakinomExtensionManager.ExtensionListName));
			this.path.Add(MakinomAssetHelper.DOWNLOAD_PATH + MakinomExtensionManager.ExtensionListName);

			for(int i = 0; i < EditorContent.Extensions.Count; i++)
			{
				EditorContent.Extensions[i].GetExtensionManagerFile(this.downloads, this.path);
			}

			this.ParseList();

			if(this.client != null)
			{
				this.client.DownloadProgressChanged -= this.ListDownloadProgressChanged;
				this.client.DownloadFileCompleted -= this.ListDownloadFileCompleted;
				this.client = null;
			}

			this.DownloadNextFile();
		}

		protected virtual void DownloadNextFile()
		{
			if(this.downloadIndex < this.downloads.Count)
			{
				if(this.client == null)
				{
					this.client = new WebClient();
					this.client.DownloadProgressChanged += this.ListDownloadProgressChanged;
					this.client.DownloadFileCompleted += this.ListDownloadFileCompleted;
				}
				if(this.client != null)
				{
					int tmpIndex = this.downloadIndex;
					this.downloadIndex++;
					this.client.DownloadFileAsync(this.downloads[tmpIndex], this.path[tmpIndex]);
				}
			}
			else
			{
				this.client = null;
				AssetDatabase.Refresh();
				this.ParseList();
			}
		}

		protected virtual void ListDownloadProgressChanged(object sender, DownloadProgressChangedEventArgs e)
		{
			this.progress = e.ProgressPercentage;
			this.Repaint();
		}

		protected void ListDownloadFileCompleted(object sender, System.ComponentModel.AsyncCompletedEventArgs e)
		{
			this.DownloadNextFile();
		}

		protected virtual void ParseList()
		{
			this.sections.Clear();
			List<string> names = new List<string>();

			for(int i = 0; i < this.path.Count; i++)
			{
				TextAsset asset = AssetDatabase.LoadAssetAtPath<TextAsset>(this.path[i]);
				if(asset != null &&
					!string.IsNullOrEmpty(asset.text))
				{
					Section current = null;
					int index = 0;
					while(index >= 0 &&
						index < asset.text.Length - 1)
					{
						try
						{
							// new section
							if(asset.text.IndexOf(MakinomExtensionManager.SectionStart, index) == index)
							{
								int endIndex = asset.text.IndexOf(MakinomExtensionManager.SectionEnd, index);
								index += MakinomExtensionManager.SectionStart.Length;
								string[] info = asset.text.Substring(index, endIndex - index).Split(';');
								if(!this.sections.TryGetValue(info[0], out current))
								{
									current = new Section(this, info[0], info[1], info[2]);
									this.sections.Add(info[0], current);
									names.Add(info[0]);
								}
								index = endIndex + MakinomExtensionManager.SectionEnd.Length;
							}
							// download
							else if(asset.text.IndexOf(MakinomExtensionManager.DownloadStart, index) == index)
							{
								int endIndex = asset.text.IndexOf(MakinomExtensionManager.DownloadEnd, index);
								index += MakinomExtensionManager.DownloadStart.Length;
								string[] info = asset.text.Substring(index, endIndex - index).Split(';');
								current.downloads.Add(new DownloadInfo(current, info[0], info[1], info[2], info[3]));
								index = endIndex + MakinomExtensionManager.DownloadEnd.Length;
							}
							else
							{
								index++;
							}
						}
						catch
						{
							index++;
						}
					}
				}
			}

			this.sectionNames = names.ToArray();

			this.Repaint();
		}


		/*
		============================================================================
		GUI handling
		============================================================================
		*/
		protected virtual void OnGUI()
		{
			EditorGUILayout.BeginVertical();
			this.scrollView = EditorGUILayout.BeginScrollView(this.scrollView);

			EditorGUILayout.BeginVertical();
			EditorGUILayout.HelpBox("Extend Makinom's functionality with plugins, custom nodes, scripts and other code extensions.\n" +
				"You can also download completed schematics, e.g. for setting the player.\n\n" +
				"Downloaded packages can be found in this folder:\n" +
				MakinomAssetHelper.DOWNLOAD_PATH + "\n\n" +
				"Make sure to save your Makinom project (editor) before importing any packages.",
				MessageType.Info);
			if(GUILayout.Button("Open in Browser"))
			{
				Application.OpenURL("https://makinom.com/guide/extensions/");
			}
			EditorGUILayout.Separator();

			if(this.client != null)
			{
				EditorGUILayout.LabelField("Downloading List", this.progress.ToString() + "%");
				EditorGUILayout.Separator();
			}

			this.currentSection = GUILayout.Toolbar(this.currentSection, this.sectionNames);
			Section section = null;
			if(this.currentSection >= 0 &&
				this.currentSection < this.sectionNames.Length &&
				this.sections.TryGetValue(this.sectionNames[this.currentSection], out section))
			{
				section.Show();
			}

			EditorGUILayout.EndVertical();
			EditorGUILayout.EndScrollView();
			EditorGUILayout.EndVertical();
		}


		/*
		============================================================================
		Info classes
		============================================================================
		*/
		public class Section
		{
			public MakinomExtensionManager parent;

			public GUIContent content;

			public string infoLink = "";

			public bool foldout = true;

			public List<DownloadInfo> downloads = new List<DownloadInfo>();

			public Section(MakinomExtensionManager parent, string name, string description, string infoLink)
			{
				this.parent = parent;
				this.content = new GUIContent(name, description);
				this.infoLink = infoLink;
			}

			public virtual void Show()
			{
				EditorGUILayout.BeginVertical(EditorContent.Instance.BoxFoldoutInspectorStyle);
				this.foldout = EditorGUILayout.Foldout(this.foldout, this.content, true, EditorContent.Instance.FoldoutInspectorStyle);
				if(this.foldout)
				{
					EditorGUILayout.HelpBox(this.content.tooltip, MessageType.Info);
					EditorGUI.BeginDisabledGroup(string.IsNullOrEmpty(this.infoLink));
					if(GUILayout.Button("Open in Browser"))
					{
						Application.OpenURL(this.infoLink);
					}

					EditorGUILayout.Separator();
					for(int i = 0; i < this.downloads.Count; i++)
					{
						if(this.downloads[i] != null)
						{
							this.downloads[i].Show();
						}
					}
				}
				EditorGUILayout.EndVertical();
			}
		}

		public class DownloadInfo
		{
			public Section section;

			public GUIContent content;

			public string infoLink = "";

			public string downloadLink = "";

			public string fileName = "";

			public bool foldout = true;

			public PackageDownloader downloader;

			public DownloadInfo(Section section, string name, string description, string infoLink, string downloadLink)
			{
				this.section = section;
				this.content = new GUIContent(name, description);
				this.infoLink = infoLink;
				this.downloadLink = downloadLink;
				this.fileName = this.downloadLink.Substring(this.downloadLink.LastIndexOf("/") + 1);
			}

			public void Show()
			{
				EditorGUILayout.BeginVertical(EditorContent.Instance.BoxFoldoutInspectorStyle);
				this.foldout = EditorGUILayout.Foldout(this.foldout, this.content, true, EditorContent.Instance.FoldoutInspectorStyle);
				if(this.foldout)
				{
					EditorGUILayout.HelpBox(this.content.tooltip, MessageType.None);

					EditorGUI.BeginDisabledGroup(string.IsNullOrEmpty(this.infoLink));
					if(GUILayout.Button("Open in Browser"))
					{
						Application.OpenURL(this.infoLink);
					}
					EditorGUI.EndDisabledGroup();
					EditorGUI.BeginDisabledGroup(string.IsNullOrEmpty(this.downloadLink) ||
						this.downloader != null);
					if(GUILayout.Button("Download + Import" + (this.downloader != null ? " (" + this.downloader.progress + "%)" : "")))
					{
						this.downloader = new PackageDownloader(this, this.downloadLink, this.fileName);
					}
					EditorGUI.EndDisabledGroup();
				}
				EditorGUILayout.EndVertical();
			}
		}
	}
}
