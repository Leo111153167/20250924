
using GamingIsLove.Makinom;
using GamingIsLove.Makinom.Editor;
using GamingIsLove.Makinom.Components;
using UnityEditor;
using UnityEngine;
using System.Collections.Generic;
using System.Reflection;

namespace GamingIsLove.Makinom.Editor
{
	public class SceneWizard : EditorWindow
	{
		public enum SceneWizardMode
		{
			Overview, CreateCameraPosition,
			TestFormula, CreateGameStarter, Custom
		}

		protected static SceneWizard instance;

		protected bool reinitialize = false;

		protected Vector2 scrollView = Vector2.zero;

		protected GUIStyle buttonStyle;

		protected float maxHeight = 64;

		protected bool showHelp = false;

		protected Vector2 helpScroll = Vector2.zero;


		// modes:
		// 0 == menu
		// 1 == create object
		// 2 == add component
		// 3 == create camera position
		// 4 == game starter
		protected SceneWizardMode mode = SceneWizardMode.Overview;

		protected int customMode = 0;


		// camera position
		protected bool cpLocal = false;

		protected bool cpRotOff = false;

		protected bool cpLook = false;


		// formula
		protected FormulaAsset formula;

		protected float formulaInitialValue = 0;

		protected string testResult = "";


		// game starter
		protected MakinomProjectAsset projectAsset;

		protected bool startGame = true;


		// components
		protected Texture2D gameStarter;

		protected Dictionary<string, Texture2D> customIcons = new Dictionary<string, Texture2D>();


		// buttons
		protected EditorSortedSettingInfo createObjectInfo;

		protected EditorSortedSettingInfo addComponentInfo;

		protected EditorSortedSettingInfo addMachineInfo;

		protected GeneralPopupSelectionButton createObjectButton = new GeneralPopupSelectionButton();

		protected GeneralPopupSelectionButton addComponentButton = new GeneralPopupSelectionButton();

		protected GeneralPopupSelectionButton addMachineButton = new GeneralPopupSelectionButton();


		/*
		============================================================================
		Properties
		============================================================================
		*/
		public virtual SceneWizardMode Mode
		{
			get { return this.mode; }
			set { this.mode = value; }
		}

		public virtual int CustomMode
		{
			get { return this.customMode; }
			set { this.customMode = value; }
		}


		/*
		============================================================================
		Init function
		============================================================================
		*/
		[MenuItem("Window/Gaming Is Love/Makinom Scene Wizard %&w", false, 2520)]
		static void Init()
		{
			Maki.Initialize(MakinomAssetHelper.LoadProjectAsset());
			instance = EditorWindow.GetWindow<SceneWizard>(false, "Scene Wizard", true);
			instance.minSize = new Vector2(100, 100);
			instance.Show();
			instance.Initialize();
		}

		protected virtual void Initialize()
		{
			this.createObjectInfo = EditorAttributes.GetSettingInfos(typeof(SceneWizard_BaseCreateObject));
			this.addComponentInfo = EditorAttributes.GetSettingInfos(typeof(SceneWizard_BaseAddComponent));
			this.addMachineInfo = EditorAttributes.GetSettingInfos(typeof(SceneWizard_BaseAddMachine));


			this.showHelp = PlayerPrefs.GetInt("GamingIsLove.Makinom.SceneWizard.ShowHelp") == 1;

			// components
			this.gameStarter = this.LoadIcon("GameStarter");
		}

		protected virtual Texture2D LoadIcon(string name)
		{
			return AssetDatabase.LoadAssetAtPath(
				"Assets/Gizmos/GamingIsLove/Makinom/Components/" + name + " Icon.png",
				typeof(Texture2D)) as Texture2D;
		}

		public virtual Texture2D GetCustomIcon(string iconPath)
		{
			Texture2D icon = null;
			if(!this.customIcons.TryGetValue(iconPath, out icon))
			{
				icon = AssetDatabase.LoadAssetAtPath(iconPath, typeof(Texture2D)) as Texture2D;
				this.customIcons.Add(iconPath, icon);
			}
			return icon;
		}

		public static SceneWizard Instance()
		{
			if(instance == null)
			{
				SceneWizard.Init();
			}
			return instance;
		}

		public virtual void PlayModeStateChanged(PlayModeStateChange state)
		{
			if(PlayModeStateChange.ExitingPlayMode == state)
			{
				this.reinitialize = true;
			}
		}

		protected virtual void OnEnable()
		{
			EditorApplication.playModeStateChanged += this.PlayModeStateChanged;
		}

		protected virtual void OnDestroy()
		{
			EditorApplication.playModeStateChanged -= this.PlayModeStateChanged;
			instance = null;
		}


		/*
		============================================================================
		Button function
		============================================================================
		*/
		public virtual bool Button(string content)
		{
			return GUILayout.Button(content, this.buttonStyle, GUILayout.Height(32));
		}

		public virtual bool ButtonAdd(string content)
		{
			return GUILayout.Button(new GUIContent(content, EditorContent.Instance.AddIcon), this.buttonStyle, GUILayout.Height(32));
		}

		public virtual bool ButtonCancel()
		{
			return GUILayout.Button(new GUIContent("Cancel", EditorContent.Instance.NavigateBackIcon), this.buttonStyle, GUILayout.Height(32));
		}

		public virtual bool Button(GUIContent content)
		{
			return GUILayout.Button(content, this.buttonStyle, GUILayout.MaxHeight(this.maxHeight));
		}


		/*
		============================================================================
		Popup callback functions
		============================================================================
		*/
		protected void PopupClosed()
		{
			this.Focus();
		}

		protected void SelectIndex_CreateObject(int index)
		{
			if(this.createObjectInfo != null &&
				index >= 0 &&
				index < this.createObjectInfo.Count)
			{
				System.Type type = this.createObjectInfo.GetType(index);
				if(type != null)
				{
					object instance = null;
					MethodInfo method = ReflectionTypeHandler.Instance.GetMethod("Use", new System.Type[] { }, ref instance, ref type);
					if(method != null)
					{
						method.Invoke(null, null);
					}
				}
			}
		}

		protected void SelectIndex_AddComponent(int index)
		{
			if(this.addComponentInfo != null &&
				index >= 0 &&
				index < this.addComponentInfo.Count)
			{
				System.Type type = this.addComponentInfo.GetType(index);
				if(type != null)
				{
					object instance = null;
					MethodInfo method = ReflectionTypeHandler.Instance.GetMethod("Use", new System.Type[] { }, ref instance, ref type);
					if(method != null)
					{
						method.Invoke(null, null);
					}
				}
			}
		}

		protected void SelectIndex_AddMachine(int index)
		{
			if(this.addMachineInfo != null &&
				index >= 0 &&
				index < this.addMachineInfo.Count)
			{
				System.Type type = this.addMachineInfo.GetType(index);
				if(type != null)
				{
					object instance = null;
					MethodInfo method = ReflectionTypeHandler.Instance.GetMethod("Use", new System.Type[] { }, ref instance, ref type);
					if(method != null)
					{
						method.Invoke(null, null);
					}
				}
			}
		}


		/*
		============================================================================
		GUI handling
		============================================================================
		*/
		protected virtual void OnGUI()
		{
			if(!Maki.Initialized || this.reinitialize || this.createObjectInfo == null)
			{
				if(!Maki.Initialized)
				{
					Maki.Initialize(MakinomAssetHelper.LoadProjectAsset());
				}
				EditorDataHandler.DataHandlerLoaded();
				this.reinitialize = false;
				this.Initialize();
			}

			this.buttonStyle = new GUIStyle(GUI.skin.button);
			this.buttonStyle.alignment = TextAnchor.MiddleLeft;
			this.maxHeight = 48 + this.buttonStyle.padding.top + this.buttonStyle.padding.bottom;

			// overview menu
			if(SceneWizardMode.Overview == this.mode)
			{
				this.scrollView = EditorGUILayout.BeginScrollView(this.scrollView);

				this.createObjectButton.Show(new GUIContent("Create Game Object", EditorContent.Instance.AddIcon),
					"Creates a new game object with a ready to use component setup.", "",
					this.createObjectInfo.names, this.createObjectInfo.descriptions, "SW_CGO:", "Create Game Object",
					this.SelectIndex_CreateObject, this.PopupClosed, null,
					this.buttonStyle, GUILayout.Height(32));

				EditorGUI.BeginDisabledGroup(Selection.objects.Length == 0);
				this.addComponentButton.Show(new GUIContent("Add Component", EditorContent.Instance.AddIcon),
					"Adds components to selected game objects.", "",
					this.addComponentInfo.names, this.addComponentInfo.descriptions, "SW_AC:", "Add Component",
					this.SelectIndex_AddComponent, this.PopupClosed, null,
					this.buttonStyle, GUILayout.Height(32));

				this.addMachineButton.Show(new GUIContent("Add Machine", EditorContent.Instance.AddIcon),
					"Adds machine components to selected game objects.", "",
					this.addMachineInfo.names, this.addMachineInfo.descriptions, "SW_AM:", "Add Machine",
					this.SelectIndex_AddMachine, this.PopupClosed, null,
					this.buttonStyle, GUILayout.Height(32));

				EditorGUI.EndDisabledGroup();
				if(this.ButtonAdd("Create Camera Position"))
				{
					this.cpLocal = false;
					this.cpRotOff = false;
					this.cpLook = false;
					this.mode = SceneWizardMode.CreateCameraPosition;
				}
				if(this.Button("Test Formula"))
				{
					this.formula = null;
					this.formulaInitialValue = 0;
					this.testResult = "";
					this.mode = SceneWizardMode.TestFormula;
				}
				if(this.Button(new GUIContent("Add Game Starter", this.gameStarter)))
				{
					this.SetProject();
					this.startGame = true;
					this.mode = SceneWizardMode.CreateGameStarter;
				}
			}
			// create camera position
			else if(SceneWizardMode.CreateCameraPosition == this.mode)
			{
				if(this.ButtonCancel())
				{
					this.mode = SceneWizardMode.Overview;
				}
				EditorGUILayout.Separator();
				EditorTool.BoldLabel("Create Camera Position");

				this.scrollView = EditorGUILayout.BeginScrollView(this.scrollView);

				Camera cam = null;
				GameObject obj = null;
				if(Selection.objects.Length == 2 &&
					(cam = SceneWizard.GetSelectedCamera()) != null &&
					(obj = SceneWizard.GetSelectedNotCamera()) != null)
				{
					GUILayout.TextArea("Remember to save the settings in the editor window after creating the camera position.");
					EditorGUILayout.Separator();

					this.cpLocal = EditorGUILayout.Toggle("Local Space", this.cpLocal);
					this.cpRotOff = EditorGUILayout.Toggle("Rotation Is Offset", this.cpRotOff);
					this.cpLook = EditorGUILayout.Toggle("Look At", this.cpLook);

					if(this.cpLook)
					{
						cam.transform.LookAt(obj.transform);
					}

					EditorGUI.BeginDisabledGroup(true);
					EditorGUILayout.Vector3Field("Position", cam.transform.position - obj.transform.position);
					EditorGUILayout.Vector3Field("Rotation", cam.transform.eulerAngles);
					if(cam.orthographic)
					{
						EditorGUILayout.FloatField("Orthographic Size", cam.orthographicSize);
					}
					else
					{
						EditorGUILayout.FloatField("Field Of View", cam.fieldOfView);
					}
					EditorGUI.EndDisabledGroup();

					EditorGUILayout.Separator();
					if(this.ButtonAdd("Create Camera Position"))
					{
						CameraPositionAsset cp = EditorDataHandler.Instance.Add(typeof(CameraPositionAsset)) as CameraPositionAsset;
						if(cp != null)
						{
							cp.Settings.name = "New (From Scene)";
							cp.Settings.position = cam.transform.position - obj.transform.position;
							cp.Settings.rotation = cam.transform.eulerAngles;
							if(cam.orthographic)
							{
								cp.Settings.setOrthographicSize = true;
								cp.Settings.orthographicSize = cam.orthographicSize;
							}
							else
							{
								cp.Settings.setFoV = true;
								cp.Settings.fieldOfView = cam.fieldOfView;
							}
							cp.Settings.localSpace = this.cpLocal;
							cp.Settings.rotationIsOffset = this.cpRotOff;
							cp.Settings.lookAt = this.cpLook;
							cp.Index = int.MaxValue;
							MakinomEditorWindow.Instance.EditSetting(typeof(CameraPositionAsset), cp);
							EditorWindow.FocusWindowIfItsOpen<MakinomEditorWindow>();
							this.mode = SceneWizardMode.Overview;
						}
					}
				}
				else
				{
					GUILayout.TextArea("Select a camera and a game object in your scene.\n" +
						"The camera position will be created using the selected game object as target.");
				}

			}
			// test formula
			else if(SceneWizardMode.TestFormula == this.mode)
			{
				if(this.ButtonCancel())
				{
					this.mode = SceneWizardMode.Overview;
				}
				EditorGUILayout.Separator();
				EditorTool.BoldLabel("Test Formula");

				this.scrollView = EditorGUILayout.BeginScrollView(this.scrollView);

				EditorGUILayout.HelpBox("Select 2 game objects in your scene view to be able to test 'Position' nodes.",
					MessageType.Info);
				EditorGUILayout.Separator();

				this.formula = (FormulaAsset)EditorGUILayout.ObjectField("Formula", this.formula, typeof(FormulaAsset), false);
				this.formulaInitialValue = EditorGUILayout.FloatField("Initial Value", this.formulaInitialValue);
				EditorGUILayout.Separator();

				if(this.formula != null &&
					this.Button("Calculate"))
				{
					this.testResult = this.formula.Settings.Calculate(
						new FormulaCall(
							this.formulaInitialValue,
							Selection.objects.Length > 0 ? Selection.objects[0] as GameObject : null,
							Selection.objects.Length > 1 ? Selection.objects[1] as GameObject : null,
							null, null, 0)).ToString();
				}

				EditorGUILayout.LabelField("Result", this.testResult);

			}
			// game starter
			else if(SceneWizardMode.CreateGameStarter == this.mode)
			{
				this.ShowGameStarterSetup<GameStarter>(this.gameStarter, "Game Starter");
			}

			// extensions
			for(int i = 0; i < EditorContent.Extensions.Count; i++)
			{
				EditorContent.Extensions[i].ShowSceneWizard(this);
			}

			EditorGUILayout.EndScrollView();

			// editor help
			bool tmpHelp = this.showHelp;
			this.showHelp = EditorGUILayout.Toggle("Show Help", this.showHelp);
			if(tmpHelp != this.showHelp)
			{
				PlayerPrefs.SetInt("GamingIsLove.Makinom.SceneWizard.ShowHelp", this.showHelp ? 1 : 0);
			}
			if(this.showHelp)
			{
				EditorTool.ShowEditorHelp(ref this.helpScroll, -1, 100);
			}
		}

		protected virtual void OnInspectorUpdate()
		{
			this.Repaint();
		}

		public virtual void SetProject()
		{
			this.projectAsset = MakinomAssetHelper.LoadProjectAsset();
		}

		public virtual void ShowGameStarterSetup<T>(Texture2D texture, string name) where T : GameStarter
		{
			if(this.ButtonCancel())
			{
				this.projectAsset = null;
				this.mode = SceneWizardMode.Overview;
			}
			EditorGUILayout.Separator();

			EditorTool.BoldLabel("Add " + name);

			this.scrollView = EditorGUILayout.BeginScrollView(this.scrollView);

			GUILayout.TextArea("Select the Project Asset that will be used by this game starter.\n" +
				"The Project Asset holds your game's data and is used to set up data correctly for a running game.\n" +
				"It must be in the first scene of your game (e.g. in the main menu scene), also while testing in Unity, you need to start from this scene.");
			EditorGUILayout.Separator();

			this.projectAsset = (MakinomProjectAsset)EditorGUILayout.ObjectField("Project Asset",
				this.projectAsset, typeof(MakinomProjectAsset), false);
			this.startGame = EditorGUILayout.Toggle("Start Game", this.startGame);
			EditorGUILayout.Separator();

			EditorGUI.BeginDisabledGroup(this.projectAsset == null);
			if(this.Button(new GUIContent("Add " + name, texture)))
			{
				T gameStarter = SceneObjectHelper.CreateSimple<T>(name);
				gameStarter.project = this.projectAsset;
				gameStarter.startGame = this.startGame;
				this.projectAsset = null;
				this.mode = SceneWizardMode.Overview;
			}
			EditorGUI.EndDisabledGroup();
		}


		/*
		============================================================================
		Camera functions
		============================================================================
		*/
		public static Camera GetSelectedCamera()
		{
			foreach(GameObject obj in Selection.objects)
			{
				if(obj != null)
				{
					Camera camera = obj.GetComponent<Camera>();
					if(camera != null)
					{
						return camera;
					}
				}
			}
			return null;
		}

		public static GameObject GetSelectedNotCamera()
		{
			foreach(GameObject obj in Selection.objects)
			{
				if(obj != null)
				{
					Camera camera = obj.GetComponent<Camera>();
					if(camera == null)
					{
						return obj;
					}
				}
			}
			return null;
		}
	}
}
