﻿
using UnityEngine;
using System.Collections.Generic;

namespace GamingIsLove.Makinom.Editor
{
	public abstract class BaseDialogueImportFormat : BaseTypeData
	{
		public abstract bool CanProcess
		{
			get;
		}

		public virtual bool CanPreprocessText
		{
			get { return false; }
		}

		public virtual void PreprocessText()
		{

		}

		public abstract DialogueImportContent ProcessText();
	}
}
