
using GamingIsLove.Makinom;
using GamingIsLove.Makinom.Editor;
using GamingIsLove.Makinom.Components;
using UnityEditor;
using UnityEngine;
using System.Collections.Generic;

namespace GamingIsLove.Makinom.Editor
{
	public class VariableHandlerEditor
	{
		protected BaseEditor baseEditor;


		// editing
		// string
		private bool addString = false;

		private string addStringKey = "";

		private Dictionary<string, string> editString = new Dictionary<string, string>();

		// bool
		private bool addBool = false;

		private string addBoolKey = "";

		private Dictionary<string, bool> editBool = new Dictionary<string, bool>();

		// int
		private bool addInt = false;

		private string addIntKey = "";

		private Dictionary<string, int> editInt = new Dictionary<string, int>();

		// float
		private bool addFloat = false;

		private string addFloatKey = "";

		private Dictionary<string, float> editFloat = new Dictionary<string, float>();

		// Vector3
		private bool addVector3 = false;

		private string addVector3Key = "";

		private Dictionary<string, Vector3> editVector3 = new Dictionary<string, Vector3>();

		// string list
		private bool addStringList = false;

		private string addStringListKey = "";

		private Dictionary<string, List<string>> editStringList = new Dictionary<string, List<string>>();

		// bool list
		private bool addBoolList = false;

		private string addBoolListKey = "";

		private Dictionary<string, List<bool>> editBoolList = new Dictionary<string, List<bool>>();

		// int list
		private bool addIntList = false;

		private string addIntListKey = "";

		private Dictionary<string, List<int>> editIntList = new Dictionary<string, List<int>>();

		// float list
		private bool addFloatList = false;

		private string addFloatListKey = "";

		private Dictionary<string, List<float>> editFloatList = new Dictionary<string, List<float>>();

		// bool list
		private bool addVector3List = false;

		private string addVector3ListKey = "";

		private Dictionary<string, List<Vector3>> editVector3List = new Dictionary<string, List<Vector3>>();

		public VariableHandlerEditor(BaseEditor baseEditor)
		{
			this.baseEditor = baseEditor;
		}

		public void Show(VariableHandler handler)
		{
			if(handler != null)
			{
				// string variables
				this.ShowStringVariables(handler);

				// bool variables
				this.ShowBoolVariables(handler);

				// int variables
				this.ShowIntVariables(handler);

				// float variables
				this.ShowFloatVariables(handler);

				// Vector3 variables
				this.ShowVector3Variables(handler);

				// string list variables
				this.ShowStringListVariables(handler);

				// bool list variables
				this.ShowBoolListVariables(handler);

				// int list variables
				this.ShowIntListVariables(handler);

				// float list variables
				this.ShowFloatListVariables(handler);

				// Vector3 list variables
				this.ShowVector3ListVariables(handler);
			}
		}

		public void ShowStringVariables(VariableHandler handler)
		{
			if(this.baseEditor.BeginFoldout("String Variables", "Show string variables and their current values.", "", false))
			{
				if(this.addString)
				{
					this.addStringKey = EditorGUILayout.TextField("Variable Key", this.addStringKey);
					EditorGUILayout.BeginHorizontal();
					if(this.addStringKey != "" &&
						!handler.KeyExistsString(this.addStringKey) &&
						EditorTool.Button("Ok"))
					{
						handler.Set(this.addStringKey, "");
						this.addString = false;
					}
					if(EditorTool.Button("Cancel"))
					{
						this.addString = false;
					}
					EditorGUILayout.EndHorizontal();
				}
				else
				{
					if(EditorTool.Button(new GUIContent("Add String Variable", EditorContent.Instance.AddIcon)))
					{
						this.addString = true;
					}
				}

				List<string> keys = handler.GetStringKeys();
				for(int i = 0; i < keys.Count; i++)
				{
					bool isEdit = this.editString.ContainsKey(keys[i]);

					EditorGUILayout.BeginHorizontal();

					// edit
					if(isEdit)
					{
						isEdit = GUILayout.Toggle(isEdit,
							new GUIContent(EditorContent.Instance.EditIcon),
							"button", EditorTool.WIDTH_30);
						if(EditorTool.Button(new GUIContent(EditorContent.Instance.RemoveIcon),
							EditorTool.WIDTH_30))
						{
							handler.Remove(keys[i], VariableRemoveType.String);
							this.editString.Remove(keys[i]);
							return;
						}

						this.editString[keys[i]] = EditorGUILayout.TextField(keys[i], this.editString[keys[i]]);
						if(!isEdit)
						{
							handler.Set(keys[i], this.editString[keys[i]]);
							this.editString.Remove(keys[i]);
						}
					}
					// show
					else
					{
						isEdit = GUILayout.Toggle(isEdit,
							new GUIContent(EditorContent.Instance.EditIcon),
							"button", EditorTool.WIDTH_30);
						EditorGUILayout.LabelField(keys[i], handler.GetString(keys[i]));
						if(isEdit)
						{
							this.editString.Add(keys[i], handler.GetString(keys[i]));
						}
					}
					EditorGUILayout.EndHorizontal();
				}
				EditorGUILayout.Separator();
			}
			this.baseEditor.EndFoldout();
		}

		public void ShowBoolVariables(VariableHandler handler)
		{
			if(this.baseEditor.BeginFoldout("Bool Variables", "Show bool variables and their current values.", "", false))
			{
				if(this.addBool)
				{
					this.addBoolKey = EditorGUILayout.TextField("Variable Key", this.addBoolKey);
					EditorGUILayout.BeginHorizontal();
					if(this.addBoolKey != "" &&
						!handler.KeyExistsBool(this.addBoolKey) &&
						EditorTool.Button("Ok"))
					{
						handler.Set(this.addBoolKey, false);
						this.addBool = false;
					}
					if(EditorTool.Button("Cancel"))
					{
						this.addBool = false;
					}
					EditorGUILayout.EndHorizontal();
				}
				else
				{
					if(EditorTool.Button(new GUIContent("Add Bool Variable", EditorContent.Instance.AddIcon)))
					{
						this.addBool = true;
					}
				}

				List<string> keys = handler.GetBoolKeys();
				for(int i = 0; i < keys.Count; i++)
				{
					bool isEdit = this.editBool.ContainsKey(keys[i]);

					EditorGUILayout.BeginHorizontal();

					// edit
					if(isEdit)
					{
						isEdit = GUILayout.Toggle(isEdit,
							new GUIContent(EditorContent.Instance.EditIcon),
							"button", EditorTool.WIDTH_30);
						if(EditorTool.Button(new GUIContent(EditorContent.Instance.RemoveIcon),
							EditorTool.WIDTH_30))
						{
							handler.Remove(keys[i], VariableRemoveType.Bool);
							this.editBool.Remove(keys[i]);
							return;
						}

						this.editBool[keys[i]] = EditorGUILayout.Toggle(keys[i], this.editBool[keys[i]]);
						if(!isEdit)
						{
							handler.Set(keys[i], this.editBool[keys[i]]);
							this.editBool.Remove(keys[i]);
						}
					}
					// show
					else
					{
						isEdit = GUILayout.Toggle(isEdit,
							new GUIContent(EditorContent.Instance.EditIcon),
							"button", EditorTool.WIDTH_30);
						EditorGUILayout.LabelField(keys[i], handler.GetBool(keys[i]).ToString());
						if(isEdit)
						{
							this.editBool.Add(keys[i], handler.GetBool(keys[i]));
						}
					}
					EditorGUILayout.EndHorizontal();
				}
			}
			this.baseEditor.EndFoldout();
		}

		public void ShowIntVariables(VariableHandler handler)
		{
			if(this.baseEditor.BeginFoldout("Int Variables", "Show int variables and their current values.", "", false))
			{
				if(this.addInt)
				{
					this.addIntKey = EditorGUILayout.TextField("Variable Key", this.addIntKey);
					EditorGUILayout.BeginHorizontal();
					if(this.addIntKey != "" &&
						!handler.KeyExistsInt(this.addIntKey) &&
						EditorTool.Button("Ok"))
					{
						handler.Set(this.addIntKey, 0);
						this.addInt = false;
					}
					if(EditorTool.Button("Cancel"))
					{
						this.addInt = false;
					}
					EditorGUILayout.EndHorizontal();
				}
				else
				{
					if(EditorTool.Button(new GUIContent("Add Int Variable", EditorContent.Instance.AddIcon)))
					{
						this.addInt = true;
					}
				}

				List<string> keys = handler.GetIntKeys();
				for(int i = 0; i < keys.Count; i++)
				{
					bool isEdit = this.editInt.ContainsKey(keys[i]);

					EditorGUILayout.BeginHorizontal();

					// edit
					if(isEdit)
					{
						isEdit = GUILayout.Toggle(isEdit,
							new GUIContent(EditorContent.Instance.EditIcon),
							"button", EditorTool.WIDTH_30);
						if(EditorTool.Button(new GUIContent(EditorContent.Instance.RemoveIcon),
							EditorTool.WIDTH_30))
						{
							handler.Remove(keys[i], VariableRemoveType.Int);
							this.editInt.Remove(keys[i]);
							return;
						}

						this.editInt[keys[i]] = EditorGUILayout.IntField(keys[i], this.editInt[keys[i]]);
						if(!isEdit)
						{
							handler.Set(keys[i], this.editInt[keys[i]]);
							this.editInt.Remove(keys[i]);
						}
					}
					// show
					else
					{
						isEdit = GUILayout.Toggle(isEdit,
							new GUIContent(EditorContent.Instance.EditIcon),
							"button", EditorTool.WIDTH_30);
						EditorGUILayout.LabelField(keys[i], handler.GetInt(keys[i]).ToString());
						if(isEdit)
						{
							this.editInt.Add(keys[i], handler.GetInt(keys[i]));
						}
					}
					EditorGUILayout.EndHorizontal();
				}
			}
			this.baseEditor.EndFoldout();
		}

		public void ShowFloatVariables(VariableHandler handler)
		{
			if(this.baseEditor.BeginFoldout("Float Variables", "Show float variables and their current values.", "", false))
			{
				if(this.addFloat)
				{
					this.addFloatKey = EditorGUILayout.TextField("Variable Key", this.addFloatKey);
					EditorGUILayout.BeginHorizontal();
					if(this.addFloatKey != "" &&
						!handler.KeyExistsFloat(this.addFloatKey) &&
						EditorTool.Button("Ok"))
					{
						handler.Set(this.addFloatKey, 0.0f);
						this.addFloat = false;
					}
					if(EditorTool.Button("Cancel"))
					{
						this.addFloat = false;
					}
					EditorGUILayout.EndHorizontal();
				}
				else
				{
					if(EditorTool.Button(new GUIContent("Add Float Variable", EditorContent.Instance.AddIcon)))
					{
						this.addFloat = true;
					}
				}

				List<string> keys = handler.GetFloatKeys();
				for(int i = 0; i < keys.Count; i++)
				{
					bool isEdit = this.editFloat.ContainsKey(keys[i]);

					EditorGUILayout.BeginHorizontal();

					// edit
					if(isEdit)
					{
						isEdit = GUILayout.Toggle(isEdit,
							new GUIContent(EditorContent.Instance.EditIcon),
							"button", EditorTool.WIDTH_30);
						if(EditorTool.Button(new GUIContent(EditorContent.Instance.RemoveIcon),
							EditorTool.WIDTH_30))
						{
							handler.Remove(keys[i], VariableRemoveType.Float);
							this.editFloat.Remove(keys[i]);
							return;
						}

						this.editFloat[keys[i]] = EditorGUILayout.FloatField(keys[i], this.editFloat[keys[i]]);
						if(!isEdit)
						{
							handler.Set(keys[i], this.editFloat[keys[i]]);
							this.editFloat.Remove(keys[i]);
						}
					}
					// show
					else
					{
						isEdit = GUILayout.Toggle(isEdit,
							new GUIContent(EditorContent.Instance.EditIcon),
							"button", EditorTool.WIDTH_30);
						EditorGUILayout.LabelField(keys[i], handler.GetFloat(keys[i]).ToString());
						if(isEdit)
						{
							this.editFloat.Add(keys[i], handler.GetFloat(keys[i]));
						}
					}
					EditorGUILayout.EndHorizontal();
				}
			}
			this.baseEditor.EndFoldout();
		}

		public void ShowVector3Variables(VariableHandler handler)
		{
			if(this.baseEditor.BeginFoldout("Vector3 Variables", "Show Vector3 variables and their current values.", "", false))
			{
				if(this.addVector3)
				{
					this.addVector3Key = EditorGUILayout.TextField("Variable Key", this.addVector3Key);
					EditorGUILayout.BeginHorizontal();
					if(this.addVector3Key != "" &&
						!handler.KeyExistsVector3(this.addVector3Key) &&
						EditorTool.Button("Ok"))
					{
						handler.Set(this.addVector3Key, Vector3.zero);
						this.addVector3 = false;
					}
					if(EditorTool.Button("Cancel"))
					{
						this.addVector3 = false;
					}
					EditorGUILayout.EndHorizontal();
				}
				else
				{
					if(EditorTool.Button(new GUIContent("Add Vector3 Variable", EditorContent.Instance.AddIcon)))
					{
						this.addVector3 = true;
					}
				}

				List<string> keys = handler.GetVector3Keys();
				for(int i = 0; i < keys.Count; i++)
				{
					bool isEdit = this.editVector3.ContainsKey(keys[i]);

					EditorGUILayout.BeginHorizontal();

					// edit
					if(isEdit)
					{
						isEdit = GUILayout.Toggle(isEdit,
							new GUIContent(EditorContent.Instance.EditIcon),
							"button", EditorTool.WIDTH_30);
						if(EditorTool.Button(new GUIContent(EditorContent.Instance.RemoveIcon),
							EditorTool.WIDTH_30))
						{
							handler.Remove(keys[i], VariableRemoveType.Vector3);
							this.editVector3.Remove(keys[i]);
							return;
						}

						this.editVector3[keys[i]] = EditorGUILayout.Vector3Field(keys[i], this.editVector3[keys[i]]);
						if(!isEdit)
						{
							handler.Set(keys[i], this.editVector3[keys[i]]);
							this.editVector3.Remove(keys[i]);
						}
					}
					// show
					else
					{
						isEdit = GUILayout.Toggle(isEdit,
							new GUIContent(EditorContent.Instance.EditIcon),
							"button", EditorTool.WIDTH_30);
						EditorGUILayout.LabelField(keys[i], handler.GetVector3(keys[i]).ToString());
						if(isEdit)
						{
							this.editVector3.Add(keys[i], handler.GetVector3(keys[i]));
						}
					}
					EditorGUILayout.EndHorizontal();
				}
			}
			this.baseEditor.EndFoldout();
		}

		public void ShowStringListVariables(VariableHandler handler)
		{
			if(this.baseEditor.BeginFoldout("String List Variables", "Show string variable lists and their current values.", "", false))
			{
				if(this.addStringList)
				{
					this.addStringListKey = EditorGUILayout.TextField("Variable Key", this.addStringListKey);
					EditorGUILayout.BeginHorizontal();
					if(this.addStringListKey != "" &&
						!handler.Lists.KeyExistsString(this.addStringListKey) &&
						EditorTool.Button("Ok"))
					{
						handler.Lists.SetList(this.addStringListKey, new List<string>());
						this.addStringList = false;
					}
					if(EditorTool.Button("Cancel"))
					{
						this.addStringList = false;
					}
					EditorGUILayout.EndHorizontal();
				}
				else
				{
					if(EditorTool.Button(new GUIContent("Add String List", EditorContent.Instance.AddIcon)))
					{
						this.addStringList = true;
					}
				}

				if(handler.HasLists)
				{
					List<string> keys = handler.Lists.GetStringKeys();
					for(int i = 0; i < keys.Count; i++)
					{
						EditorTool.BoldLabel(keys[i]);

						bool isEdit = this.editStringList.ContainsKey(keys[i]);

						// edit
						if(isEdit)
						{
							EditorGUILayout.BeginHorizontal();
							if(EditorTool.Button(new GUIContent("Remove List", EditorContent.Instance.RemoveIcon)))
							{
								handler.Lists.Remove(keys[i], VariableListChangeType.Add,
									-1, VariableRemoveType.String);
								this.editStringList.Remove(keys[i]);
								return;
							}

							isEdit = GUILayout.Toggle(isEdit,
								new GUIContent("Edit List", EditorContent.Instance.EditIcon),
								"button", EditorTool.W_EXPAND);
							if(!isEdit)
							{
								handler.Lists.SetList(keys[i], this.editStringList[keys[i]]);
								this.editStringList.Remove(keys[i]);
								return;
							}

							EditorGUILayout.EndHorizontal();

							if(EditorTool.Button(new GUIContent("Add String", EditorContent.Instance.AddIcon)))
							{
								this.editStringList[keys[i]].Add("");
							}

							for(int j = 0; j < this.editStringList[keys[i]].Count; j++)
							{
								EditorGUILayout.BeginHorizontal();
								if(EditorTool.Button(new GUIContent(EditorContent.Instance.RemoveIcon),
									EditorTool.WIDTH_30))
								{
									this.editStringList[keys[i]].RemoveAt(j);
									return;
								}

								GUILayout.Label(j.ToString() + ": ");
								this.editStringList[keys[i]][j] = EditorGUILayout.TextField(
									this.editStringList[keys[i]][j]);

								EditorGUILayout.EndHorizontal();
							}
						}
						// show
						else
						{
							isEdit = GUILayout.Toggle(isEdit,
								new GUIContent("Edit List", EditorContent.Instance.EditIcon),
								"button", EditorTool.W_EXPAND);
							if(isEdit)
							{
								this.editStringList.Add(keys[i], handler.Lists.GetString(keys[i]));
							}

							List<string> list = handler.Lists.GetString(keys[i]);
							for(int j = 0; j < list.Count; j++)
							{
								GUILayout.Label(j + ": " + list[j]);
							}
						}
					}
				}
			}
			this.baseEditor.EndFoldout();
		}

		public void ShowBoolListVariables(VariableHandler handler)
		{
			if(this.baseEditor.BeginFoldout("Bool List Variables", "Show bool variable lists and their current values.", "", false))
			{
				if(this.addBoolList)
				{
					this.addBoolListKey = EditorGUILayout.TextField("Variable Key", this.addBoolListKey);
					EditorGUILayout.BeginHorizontal();
					if(this.addBoolListKey != "" &&
						!handler.Lists.KeyExistsBool(this.addBoolListKey) &&
						EditorTool.Button("Ok"))
					{
						handler.Lists.SetList(this.addBoolListKey, new List<bool>());
						this.addBoolList = false;
					}
					if(EditorTool.Button("Cancel"))
					{
						this.addBoolList = false;
					}
					EditorGUILayout.EndHorizontal();
				}
				else
				{
					if(EditorTool.Button(new GUIContent("Add Bool List", EditorContent.Instance.AddIcon)))
					{
						this.addBoolList = true;
					}
				}

				if(handler.HasLists)
				{
					List<string> keys = handler.Lists.GetBoolKeys();
					for(int i = 0; i < keys.Count; i++)
					{
						EditorTool.BoldLabel(keys[i]);

						bool isEdit = this.editBoolList.ContainsKey(keys[i]);

						// edit
						if(isEdit)
						{
							EditorGUILayout.BeginHorizontal();
							if(EditorTool.Button(new GUIContent("Remove List", EditorContent.Instance.RemoveIcon)))
							{
								handler.Lists.Remove(keys[i], VariableListChangeType.Add,
									-1, VariableRemoveType.Bool);
								this.editBoolList.Remove(keys[i]);
								return;
							}

							isEdit = GUILayout.Toggle(isEdit,
								new GUIContent("Edit List", EditorContent.Instance.EditIcon),
								"button", EditorTool.W_EXPAND);
							if(!isEdit)
							{
								handler.Lists.SetList(keys[i], this.editBoolList[keys[i]]);
								this.editBoolList.Remove(keys[i]);
								return;
							}

							EditorGUILayout.EndHorizontal();

							if(EditorTool.Button(new GUIContent("Add Bool", EditorContent.Instance.AddIcon)))
							{
								this.editBoolList[keys[i]].Add(false);
							}

							for(int j = 0; j < this.editBoolList[keys[i]].Count; j++)
							{
								EditorGUILayout.BeginHorizontal();
								if(EditorTool.Button(new GUIContent(EditorContent.Instance.RemoveIcon),
									EditorTool.WIDTH_30))
								{
									this.editBoolList[keys[i]].RemoveAt(j);
									return;
								}

								GUILayout.Label(j.ToString() + ": ");
								this.editBoolList[keys[i]][j] = EditorGUILayout.Toggle(
									this.editBoolList[keys[i]][j]);

								EditorGUILayout.EndHorizontal();
							}
						}
						// show
						else
						{
							isEdit = GUILayout.Toggle(isEdit,
								new GUIContent("Edit List", EditorContent.Instance.EditIcon),
								"button", EditorTool.W_EXPAND);
							if(isEdit)
							{
								this.editBoolList.Add(keys[i], handler.Lists.GetBool(keys[i]));
							}

							List<bool> list = handler.Lists.GetBool(keys[i]);
							for(int j = 0; j < list.Count; j++)
							{
								GUILayout.Label(j + ": " + list[j]);
							}
						}
					}
				}
			}
			this.baseEditor.EndFoldout();
		}

		public void ShowIntListVariables(VariableHandler handler)
		{
			if(this.baseEditor.BeginFoldout("Int List Variables", "Show int variable lists and their current values.", "", false))
			{
				if(this.addIntList)
				{
					this.addIntListKey = EditorGUILayout.TextField("Variable Key", this.addIntListKey);
					EditorGUILayout.BeginHorizontal();
					if(this.addIntListKey != "" &&
						!handler.Lists.KeyExistsInt(this.addIntListKey) &&
						EditorTool.Button("Ok"))
					{
						handler.Lists.SetList(this.addIntListKey, new List<int>());
						this.addIntList = false;
					}
					if(EditorTool.Button("Cancel"))
					{
						this.addIntList = false;
					}
					EditorGUILayout.EndHorizontal();
				}
				else
				{
					if(EditorTool.Button(new GUIContent("Add Int List", EditorContent.Instance.AddIcon)))
					{
						this.addIntList = true;
					}
				}

				if(handler.HasLists)
				{
					List<string> keys = handler.Lists.GetIntKeys();
					for(int i = 0; i < keys.Count; i++)
					{
						EditorTool.BoldLabel(keys[i]);

						bool isEdit = this.editIntList.ContainsKey(keys[i]);

						// edit
						if(isEdit)
						{
							EditorGUILayout.BeginHorizontal();
							if(EditorTool.Button(new GUIContent("Remove List", EditorContent.Instance.RemoveIcon)))
							{
								handler.Lists.Remove(keys[i], VariableListChangeType.Add,
									-1, VariableRemoveType.Int);
								this.editIntList.Remove(keys[i]);
								return;
							}

							isEdit = GUILayout.Toggle(isEdit,
								new GUIContent("Edit List", EditorContent.Instance.EditIcon),
								"button", EditorTool.W_EXPAND);
							if(!isEdit)
							{
								handler.Lists.SetList(keys[i], this.editIntList[keys[i]]);
								this.editIntList.Remove(keys[i]);
								return;
							}

							EditorGUILayout.EndHorizontal();

							if(EditorTool.Button(new GUIContent("Add Int", EditorContent.Instance.AddIcon)))
							{
								this.editIntList[keys[i]].Add(0);
							}

							for(int j = 0; j < this.editIntList[keys[i]].Count; j++)
							{
								EditorGUILayout.BeginHorizontal();
								if(EditorTool.Button(new GUIContent(EditorContent.Instance.RemoveIcon),
									EditorTool.WIDTH_30))
								{
									this.editIntList[keys[i]].RemoveAt(j);
									return;
								}

								GUILayout.Label(j.ToString() + ": ");
								this.editIntList[keys[i]][j] = EditorGUILayout.IntField(
									this.editIntList[keys[i]][j]);

								EditorGUILayout.EndHorizontal();
							}
						}
						// show
						else
						{
							isEdit = GUILayout.Toggle(isEdit,
								new GUIContent("Edit List", EditorContent.Instance.EditIcon),
								"button", EditorTool.W_EXPAND);
							if(isEdit)
							{
								this.editIntList.Add(keys[i], handler.Lists.GetInt(keys[i]));
							}

							List<int> list = handler.Lists.GetInt(keys[i]);
							for(int j = 0; j < list.Count; j++)
							{
								GUILayout.Label(j + ": " + list[j]);
							}
						}
					}
				}
			}
			this.baseEditor.EndFoldout();
		}

		public void ShowFloatListVariables(VariableHandler handler)
		{
			if(this.baseEditor.BeginFoldout("Float List Variables", "Show float variable lists and their current values.", "", false))
			{
				if(this.addFloatList)
				{
					this.addFloatListKey = EditorGUILayout.TextField("Variable Key", this.addFloatListKey);
					EditorGUILayout.BeginHorizontal();
					if(this.addFloatListKey != "" &&
						!handler.Lists.KeyExistsFloat(this.addFloatListKey) &&
						EditorTool.Button("Ok"))
					{
						handler.Lists.SetList(this.addFloatListKey, new List<float>());
						this.addFloatList = false;
					}
					if(EditorTool.Button("Cancel"))
					{
						this.addFloatList = false;
					}
					EditorGUILayout.EndHorizontal();
				}
				else
				{
					if(EditorTool.Button(new GUIContent("Add Float List", EditorContent.Instance.AddIcon)))
					{
						this.addFloatList = true;
					}
				}

				if(handler.HasLists)
				{
					List<string> keys = handler.Lists.GetFloatKeys();
					for(int i = 0; i < keys.Count; i++)
					{
						EditorTool.BoldLabel(keys[i]);

						bool isEdit = this.editFloatList.ContainsKey(keys[i]);

						// edit
						if(isEdit)
						{
							EditorGUILayout.BeginHorizontal();
							if(EditorTool.Button(new GUIContent("Remove List", EditorContent.Instance.RemoveIcon)))
							{
								handler.Lists.Remove(keys[i], VariableListChangeType.Add,
									-1, VariableRemoveType.Float);
								this.editFloatList.Remove(keys[i]);
								return;
							}

							isEdit = GUILayout.Toggle(isEdit,
								new GUIContent("Edit List", EditorContent.Instance.EditIcon),
								"button", EditorTool.W_EXPAND);
							if(!isEdit)
							{
								handler.Lists.SetList(keys[i], this.editFloatList[keys[i]]);
								this.editFloatList.Remove(keys[i]);
								return;
							}

							EditorGUILayout.EndHorizontal();

							if(EditorTool.Button(new GUIContent("Add Float", EditorContent.Instance.AddIcon)))
							{
								this.editFloatList[keys[i]].Add(0.0f);
							}

							for(int j = 0; j < this.editFloatList[keys[i]].Count; j++)
							{
								EditorGUILayout.BeginHorizontal();
								if(EditorTool.Button(new GUIContent(EditorContent.Instance.RemoveIcon),
									EditorTool.WIDTH_30))
								{
									this.editFloatList[keys[i]].RemoveAt(j);
									return;
								}

								GUILayout.Label(j.ToString() + ": ");
								this.editFloatList[keys[i]][j] = EditorGUILayout.FloatField(
									this.editFloatList[keys[i]][j]);

								EditorGUILayout.EndHorizontal();
							}
						}
						// show
						else
						{
							isEdit = GUILayout.Toggle(isEdit,
								new GUIContent("Edit List", EditorContent.Instance.EditIcon),
								"button", EditorTool.W_EXPAND);
							if(isEdit)
							{
								this.editFloatList.Add(keys[i], handler.Lists.GetFloat(keys[i]));
							}

							List<float> list = handler.Lists.GetFloat(keys[i]);
							for(int j = 0; j < list.Count; j++)
							{
								GUILayout.Label(j + ": " + list[j]);
							}
						}
					}
				}
			}
			this.baseEditor.EndFoldout();
		}

		public void ShowVector3ListVariables(VariableHandler handler)
		{
			if(this.baseEditor.BeginFoldout("Vector3 List Variables", "Show Vector3 variable lists and their current values.", "", false))
			{
				if(this.addVector3List)
				{
					this.addVector3ListKey = EditorGUILayout.TextField("Variable Key", this.addVector3ListKey);
					EditorGUILayout.BeginHorizontal();
					if(this.addVector3ListKey != "" &&
						!handler.Lists.KeyExistsVector3(this.addVector3ListKey) &&
						EditorTool.Button("Ok"))
					{
						handler.Lists.SetList(this.addVector3ListKey, new List<Vector3>());
						this.addVector3List = false;
					}
					if(EditorTool.Button("Cancel"))
					{
						this.addVector3List = false;
					}
					EditorGUILayout.EndHorizontal();
				}
				else
				{
					if(EditorTool.Button(new GUIContent("Add Vector3 List", EditorContent.Instance.AddIcon)))
					{
						this.addVector3List = true;
					}
				}

				if(handler.HasLists)
				{
					List<string> keys = handler.Lists.GetVector3Keys();
					for(int i = 0; i < keys.Count; i++)
					{
						EditorTool.BoldLabel(keys[i]);

						bool isEdit = this.editVector3List.ContainsKey(keys[i]);

						// edit
						if(isEdit)
						{
							EditorGUILayout.BeginHorizontal();
							if(EditorTool.Button(new GUIContent("Remove List", EditorContent.Instance.RemoveIcon)))
							{
								handler.Lists.Remove(keys[i], VariableListChangeType.Add,
									-1, VariableRemoveType.Vector3);
								this.editVector3List.Remove(keys[i]);
								return;
							}

							isEdit = GUILayout.Toggle(isEdit,
								new GUIContent("Edit List", EditorContent.Instance.EditIcon),
								"button", EditorTool.W_EXPAND);
							if(!isEdit)
							{
								handler.Lists.SetList(keys[i], this.editVector3List[keys[i]]);
								this.editVector3List.Remove(keys[i]);
								return;
							}

							EditorGUILayout.EndHorizontal();

							if(EditorTool.Button(new GUIContent("Add Vector3", EditorContent.Instance.AddIcon)))
							{
								this.editVector3List[keys[i]].Add(Vector3.zero);
							}

							for(int j = 0; j < this.editVector3List[keys[i]].Count; j++)
							{
								EditorGUILayout.BeginHorizontal();
								if(EditorTool.Button(new GUIContent(EditorContent.Instance.RemoveIcon),
									EditorTool.WIDTH_30))
								{
									this.editVector3List[keys[i]].RemoveAt(j);
									return;
								}

								GUILayout.Label(j.ToString() + ": ");
								this.editVector3List[keys[i]][j] = EditorGUILayout.Vector3Field("",
									this.editVector3List[keys[i]][j]);

								EditorGUILayout.EndHorizontal();
							}
						}
						// show
						else
						{
							isEdit = GUILayout.Toggle(isEdit,
								new GUIContent("Edit List", EditorContent.Instance.EditIcon),
								"button", EditorTool.W_EXPAND);
							if(isEdit)
							{
								this.editVector3List.Add(keys[i], handler.Lists.GetVector3(keys[i]));
							}

							List<Vector3> list = handler.Lists.GetVector3(keys[i]);
							for(int j = 0; j < list.Count; j++)
							{
								GUILayout.Label(j + ": " + list[j]);
							}
						}
					}
				}
			}
			this.baseEditor.EndFoldout();
		}
	}
}
