
namespace GamingIsLove.Makinom
{
	public enum Needed { All, One }
	public enum DebugType { Log, Warning, Error };


	// game
	public enum ActiveType { Active, Inactive }
	public enum RangeCheckType { None, InRange, OutOfRange }
	public enum SaveOption { None, Game, Save }
	public enum SceneSaveOption { None, Current, All }
	public enum TimeOriginType { Unity, Makinom, Local }


	// input/control
	public enum InputHandling { Down, Hold, Up, Any }
	public enum Orientation { None, Front, Back, Left, Right }
	public enum CollisionCameraType { Center, Horizontal, Vertical, Cross }
	public enum ControlBlockType { None, Player, Camera, Both }
	public enum ControlPlaceType { Player, Camera, Game }
	public enum MouseTouchMode { Start, Move, End, Hold }
	public enum MouseTouchType { None, Mouse, Touch, Both }
	public enum MoveSpeedType { Walk, Run, Sprint, Value };


	// formula
	public enum FloatSmoothing { None, Lerp, SmoothStep }
	public enum MultiFloatValueUse { First, Lowest, Highest, Average, Add, Sub, Multiply, Divide }


	// schematics
	public enum GlobalMachineType { Call, Auto, Key, Scene }
	public enum GlobalMachineSceneChangeType { All, SceneChange, LoadGame, Custom };
	public enum SpawnTarget { Object, SpawnPoint, Position }
	public enum AnimationClipValue { Length, Speed, NormalizedSpeed, Time, NormalizedTime, Weight }
	public enum SpawnAtType { First, All, Center, Random }
	public enum ResourceOrderType { InSequence, InReversedSequence, Random }
	public enum ComponentScope
	{
		Single, InChildren, InParent, FromRoot,
		All, AllInChildren, AllInParent, AllFromRoot
	}
	public enum ComponentScopeSingle { InObject, InChildren, InParent, FromRoot }


	// variables
	// origin
	public enum VariableOrigin { Local, Global, Object, ObjectID, SelectedData }
	public enum ListVariableOrigin
	{
		Local, Global, Object, ObjectID,
		LocalList, GlobalList, ObjectList, ObjectIDList,
		SelectedData, SelectedDataList
	}
	public enum SelectedDataOriginType { Local, Global, Object, ObjectID }

	// types
	public enum VariableBaseType { String, Bool, Int, Float, Vector3 }
	public enum VariableType { String, Bool, Int, Float, Vector3, AxisVector3 }
	public enum VariableRemoveType { All, String, Bool, Int, Float, Vector3 }
	public enum VariableChangeType { Variable, Template }
	public enum VariableInputType { String, Bool, Float, Int }
	public enum StringValueCheck { IsEqual, StartsWith, EndsWith, Contains }

	// variable lists
	public enum VariableListChangeType { Add, Insert, Set, Random, Last }
	public enum VariableListGetType { Index, Random, Last, Lowest, Highest }
	public enum ListSelectionType { First, Last, Random, All };

	// sort types
	public enum ListSortType { Ascending, Descending, Reverse, Random }
	public enum Vector3ListSortType { XYZ, XZY, YXZ, YZX, ZXY, ZYX, SquareMagnitude }
	public enum AxisSortType { XYZ, XZY, YXZ, YZX, ZXY, ZYX }

	// values
	public enum EnableSelection { Enable, Disable, Toggle };
	public enum RoundingDefault { None, Ceil, Floor, Round };
	public enum Rounding { Default, Ceil, Floor, Round, None };
	public enum SimpleOperator { Add, Sub, Set };

	// value types
	// vector3
	public enum Vector3Direction { Up, Down, Forward, Back, Right, Left }
	public enum BoundsValueType { Center, Extents, Min, Max, Size, RandomPosition }
	// timer
	public enum TimerType { CountDown, CountUp }
	public enum TimerEndType { None, Fixed, Relative }
	// date and time
	public enum DateTimeCheck
	{
		IsEqual, NotEqual,
		IsLess, IsLessEqual, IsGreater, IsGreaterEqual,
		RangeInclusive, RangeExclusive
	}
	public enum DateTimePartType { Tick, Millisecond, Second, Minute, Hour, Day, Month, Year }
	public enum TimeSpanPartType
	{
		Tick, Millisecond, Second, Minute, Hour, Day,
		TotalMilliseconds, TotalSeconds, TotalMinutes, TotalHours, TotalDays
	}
	public enum DateTimeOperator { Add, Sub, Set }


	// game objects
	public enum FindObjectTypeSimple { Name, Tag, Component }
	public enum FindObjectType { Name, Tag, Component, Filter }
	public enum HierarchyCheckType { Parent, Child, ParentAndChild }


	// grids
	public enum GridIndexType { WholeGrid, SingleIndex, LimitedArea, ExcludedArea }
	public enum GridCellMode { All, Empty, Assigned }
	public enum GridMoveRepeat { No, Yes, UntilOneUnmovable, UntilAllUnmovable }
	public enum GridAnimateType { None, Interpolate, Machine }


	// movement
	public enum RigidbodyMoveType { Set, MovePosition, Velocity }
	public enum TransformVectorOrigin
	{
		Position, Rotation, Scale,
		[EditorName("Direction/Up")]
		Up,
		[EditorName("Direction/Down")]
		Down,
		[EditorName("Direction/Forward")]
		Forward,
		[EditorName("Direction/Back")]
		Back,
		[EditorName("Direction/Right")]
		Right,
		[EditorName("Direction/Left")]
		Left,
		Velocity, LocalPosition, LocalRotation, LastMoveDirection
	}
	public enum AxisType { X, Y, Z }
	public enum Axis2Type { X, Y }
	public enum TransformChange
	{
		None, TransformPoint, TransformDirection, InverseTransformPoint, InverseTransformDirection
	}
	public enum NavMeshValueType
	{
		Acceleration, AngularSpeed, AvoidancePriority,
		BaseOffset, Height, Radius, Speed, StoppingDistance, AreaMask
	}
	public enum GravityType { None, Physics, Physics2D }
	public enum BoundsExpansionType { Once, Time, Start, Stop }

	// rotation
	public enum RotateToType { Position, GameObject, MousePosition }

	// path
	public enum PathFollowType { Time, Speed }
	public enum PathRotationType { None, Value, MoveDirection, LookAtObject }
	public enum PathStartType { Start, End, Nearest, PathPoint }
	public enum PathEndType { Stop, Loop, Reverse }


	// animation
	public enum LegacyAnimationPlayMode { Play, PlayQueued, CrossFade, CrossFadeQueued, Blend, Stop, Sample }
	public enum AnimationSystem { Legacy, Mecanim, Custom }
	public enum MecanimParameterType { Bool, Int, Float, Trigger }
	public enum MecanimGetParameterType { Bool, Int, Float }
	public enum MecanimPlayMode { None, Play, CrossFade }
	public enum MecanimDurationType { Fixed, AnimationClip };
	public enum MecanimVector3Type
	{
		BodyPosition, BodyRotation, RootPosition, RootRotation,
		IKPosition, IKRotation, LookAtPosition
	}
	public enum MecanimGetVector3Type
	{
		BodyPosition, BodyRotation, RootPosition, RootRotation, DeltaPosition, DeltaRotation,
		PivotPosition, TargetPosition, TargetRotation, IKPosition, IKRotation
	}
	public enum MecanimWeightType { Layer, IKPosition, IKRotation, LookAt }


	// fade, renderer, light, etc.
	public enum FadeType { None, Stop, Blink, Fade, Flash }
	public enum LightModeType { LightType, LightmapBakeType, RenderMode, ShadowResolution, LightShadows }
	public enum LightFloatType
	{
		BounceIntensity, CookieSize, Intensity, Range,
		ShadowBias, ShadowCustomResolution, ShadowNearPlane, ShadowNormalBias, ShadowStrength, SpotAngle
	}
	public enum ColorChangeType { Renderer, Light, Field }


	// machines
	public enum MachineExecutionType { Single, Multi, Blocking }
	public enum MachineUpdateType { Update, LateUpdate, FixedUpdate }
	public enum MachineConditionFailType { None, Disable, Destroy }
	public enum ConditionAutoCheckType { None, Start, Enable }
	public enum AutoCheckType { Always, Auto, Start, Never }
	public enum SaveMenuType { Save, Load, SavePoint }


	// scene
	public enum SceneTargetType { None, SpawnID, Position, ScenePosition }
	public enum SceneLoadType { LoadLevel, LoadLevelAdditive, LoadAsync, LoadAsyncAdditive }
	public enum SceneOrigin { Define, Stored }

	// terrain
	public enum TerrainPositionType { WorldSpace, TerrainSpace, AlphaMap, HeightMap }


	// UI
	public enum VerticalAlignment { Top, Middle, Bottom }
	public enum AddButtonType { None, First, Last }
	public enum InPauseMode { Auto, No, Yes }

	// HUD
	public enum HUDUser { None, Player, SelectedData, FindObjects, SelectedObject }
	public enum ToggleType { Toggle, On, Off }


	// reflection
	public enum ReflectionClassOrigin { Component, Static, SelectedData };
	public enum SendMessageType { SendMessage, SendMessageUpwards, BroadcastMessage }
	public enum ParameterTypeSimple { String, Bool, Int, Float, Vector2, Vector3, Quaternion }


	// game settings
	public enum Selector { None, Select, All }
	public enum VolumeChangeType { Set, Fade, Mute, Unmute }


	// playable
	public enum PlayableDirectorStateType { Play, Pause, Resume, Stop }
	public enum PlayableDirectorTimeType { Time, Duration, InitialTime }


	// div
	public enum ColumnFill { Vertical, Horizontal }
	public enum ListChangeType { Add, Remove, Set, Clear }
	public enum RectChangeType { Bounds, Position, Size }
	public enum UsedObjectChange { None, SelectedData, SelectedObject }
	public enum AudioSourceOrigin { MusicChannel, SoundChannel, GameObject };
}
