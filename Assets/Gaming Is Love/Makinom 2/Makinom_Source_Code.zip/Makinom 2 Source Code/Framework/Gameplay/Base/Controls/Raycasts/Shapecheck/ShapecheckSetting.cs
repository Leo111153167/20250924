﻿
using UnityEngine;
using System.Collections.Generic;

namespace GamingIsLove.Makinom
{
	public class ShapecheckSetting<T> : BaseData where T : IObjectSelection, new()
	{
		[EditorHelp("Shape Type", "Select the shape that will be used:", "")]
		[EditorInfo(settingBaseType=typeof(BaseShapecheckType), settingAutoSetup="settings")]
		public string type = "";


		// settings
		[EditorSeparator]
		public BaseShapecheckType<T> settings = new Box3DShapecheckType<T>();


		// general
		[EditorHelp("Layer Mask", "The layer mask used for the check.", "")]
		[EditorSeparator]
		[EditorTitleLabel("Layer Mask")]
		public FloatValue<T> layerMask = new FloatValue<T>(typeof(FloatValue_LayerMaskType<T>));

		public ShapecheckSetting()
		{
			this.type = this.settings.GetGenericTypeName();
		}

		public override void EditorAutoSetup(string fieldName)
		{
			if(!this.settings.IsType(this.type))
			{
				DataObject data = this.settings.GetData();
				System.Type tmpType = ReflectionTypeHandler.Instance.GetType(this.type, typeof(BaseShapecheckType));
				if(tmpType != null)
				{
					object tmpSettings = ReflectionTypeHandler.Instance.CreateInstance(
						tmpType.MakeGenericType(typeof(T)));
					if(tmpSettings is BaseShapecheckType<T>)
					{
						this.settings = (BaseShapecheckType<T>)tmpSettings;
						this.settings.SetData(data);
					}
					else
					{
						this.settings = new Box3DShapecheckType<T>();
						this.settings.SetData(data);
						this.type = this.settings.GetGenericTypeName();
					}
				}
				else
				{
					this.settings = new Box3DShapecheckType<T>();
					this.settings.SetData(data);
					this.type = this.settings.GetGenericTypeName();
				}
			}
		}

		public override string ToString()
		{
			return this.settings.ToString();
		}


		/*
		============================================================================
		Cast functions
		============================================================================
		*/
		public virtual bool Is2D
		{
			get { return this.settings.Is2D; }
		}

		public virtual bool Check(IDataCall call)
		{
			return this.settings.Check(call, (int)this.layerMask.GetValue(call));
		}

		public virtual Collider Overlap(IDataCall call)
		{
			return this.settings.Overlap(call, (int)this.layerMask.GetValue(call));
		}

		public virtual Collider[] OverlapAll(IDataCall call)
		{
			return this.settings.OverlapAll(call, (int)this.layerMask.GetValue(call));
		}

		public virtual Collider2D Overlap2D(IDataCall call)
		{
			return this.settings.Overlap2D(call, (int)this.layerMask.GetValue(call));
		}

		public virtual Collider2D[] OverlapAll2D(IDataCall call)
		{
			return this.settings.OverlapAll2D(call, (int)this.layerMask.GetValue(call));
		}
	}
}
