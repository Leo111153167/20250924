﻿
using UnityEngine;
using System.Collections.Generic;

namespace GamingIsLove.Makinom
{
	public class NegateInputKey : BaseData
	{
		[EditorHelp("Input Key", "Select the input key that will be used as input for this input key.", "")]
		public AssetSelection<InputKeyAsset> inputKey = new AssetSelection<InputKeyAsset>();

		[EditorHelp("Negate Input", "Negate the input key's input when checking if the input has occured.\n" +
			"E.g. when using an input key that has valid input when 'Shift' is held, " +
			"this can be used to allow this input to only be used when 'Shift' isn't held.", "")]
		public bool negate = false;

		public NegateInputKey()
		{

		}

		public bool CheckInput(int inputID)
		{
			return this.negate ?
				!InputKey.GetButton(this.inputKey.StoredAsset, inputID) :
				InputKey.GetButton(this.inputKey.StoredAsset, inputID);
		}

		public float GetAxis(int inputID)
		{
			return InputKey.GetAxis(this.inputKey.StoredAsset, inputID);
		}
	}
}
