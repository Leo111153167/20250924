﻿
using UnityEngine;
using System.Collections.Generic;

namespace GamingIsLove.Makinom
{
	[EditorSettingInfo("Resources", "Select the asset stored in a 'Resources' folder that will be used.\n" +
		"This only saves the path within the 'Resources' folder.")]
	public class ResourcesAssetSource<T> : BaseAssetSource<T> where T : UnityEngine.Object
	{
		[EditorHelp("Asset", "Select the asset that will be used.\n" +
			"The asset has to be placed in a 'Resources' folder.\n" +
			"Only the asset's path within the 'Resources' folder will be saved, not a reference to the actual asset.", "")]
		[EditorHide]
		[EditorWidth(150, true)]
		public T asset;

		[EditorHide]
		public string resourcePath = "";

		public ResourcesAssetSource()
		{

		}

		public override DataObject GetData()
		{
			DataObject data = new DataObject();
			data.Set("resourcePath", this.resourcePath);
			data.Set(DataSerializer.TYPE, this.GetGenericTypeName());
			return data;
		}

		public override T Get()
		{
			return AssetSourceCache.Instance.GetFromResources<T>(this.resourcePath);
		}


		/*
		============================================================================
		Editor functions
		============================================================================
		*/
		public override bool EditorHasAssetField
		{
			get { return true; }
		}

		public override Object EditorAsset
		{
			get { return this.asset; }
			set { this.asset = value as T; }
		}

		public override bool HasAsset
		{
			get { return !string.IsNullOrEmpty(this.resourcePath); }
		}

		public override void EditorBefore()
		{
			if(this.asset == null &&
				!string.IsNullOrEmpty(this.resourcePath))
			{
				this.asset = Resources.Load<T>(this.resourcePath);
				if(this.asset == null)
				{
					this.resourcePath = "";
				}
			}
		}

		public override bool EditorAfter(bool assetChanged, string assetPath)
		{
			if(assetChanged)
			{
				if(!string.IsNullOrEmpty(assetPath))
				{
					int index = assetPath.IndexOf("/Resources/", System.StringComparison.Ordinal);
					if(index > 0)
					{
						index += 11;
						this.resourcePath = assetPath.Substring(index,
							assetPath.LastIndexOf('.') - index);
					}
					else
					{
						this.asset = null;
						this.resourcePath = "";
						return true;
					}
				}
				else
				{
					this.asset = null;
					this.resourcePath = "";
					return true;
				}
			}
			return false;
		}

		public override string ToString()
		{
			return this.resourcePath;
		}
	}
}
