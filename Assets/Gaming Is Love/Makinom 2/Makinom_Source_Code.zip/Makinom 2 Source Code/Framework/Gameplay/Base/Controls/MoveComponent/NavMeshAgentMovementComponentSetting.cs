﻿
using UnityEngine;
using UnityEngine.AI;
using System.Collections.Generic;

namespace GamingIsLove.Makinom
{
	[EditorSettingInfo("Nav Mesh Agent", "Unity's built in NavMesh is used.")]
	public class NavMeshAgentMovementComponentSetting : BaseMovementComponentSetting
	{
		[EditorHelp("Add Component", "A 'Nav Mesh Agent' component will be added to the game object, if it isn't added already.\n" +
			"If disabled, the component must already be attached to the game object.", "")]
		public bool compAdd = false;

		[EditorHelp("Sample Distance", "Define the distance in which the nearest position on the NavMesh will be searched.", "")]
		public float sampleDistance = 5;

		[EditorHelp("Area Mask", "A mask specifying which NavMesh areas are allowed when finding the nearest point.\n" +
			"Defaults to all areas (-1).", "")]
		public int sampleAreaMask = NavMesh.AllAreas;

		[EditorHelp("Stop Immediately", "Stops the agent immediately when stop is called.\n" +
			"Sets the agent's velocity to 0.")]
		public bool stopImmediately = false;


		// root motion settings
		[EditorHelp("Use Root Motion", "Enable this if you use an 'Animator' component's root motion in combination with moving by NavMesh agent.\n" +
			"This'll synchronize root motion and the NavMesh agent using a component implementing the 'OnAnimatorMove' function, handling root motion via script.\n" +
			"Only used if the 'Animator' component has using root motion enabled.\n" +
			"Please note that you might need to set animator's 'Update Mode' to 'Animate Physics' if this impacts movement speed.")]
		[EditorSeparator]
		public bool useRootMotion = false;

		[EditorHelp("Move Bool Parameter", "Root motion movement will set this bool parameter of the 'Animator' component's animator controller.\n" +
			"If movement should occur, the parameter is set to 'true', otherwise 'false'.\n" +
			"Leave empty (no value) to not use this parameter.")]
		[EditorWidth(true)]
		[EditorCondition("useRootMotion", true)]
		public string rootMotionMoveBoolParameter = "";

		[EditorHelp("Speed/X Float Parameter", "Root motion movement will set this float parameter of the 'Animator' component's animator controller.\n" +
			"Sets the movement speed (1D) or the X-axis speed for 2-dimensional blend trees (when using the 'Speed Y Float Parameter').\n" +
			"Leave empty (no value) to not use this parameter.")]
		[EditorWidth(true)]
		public string rootMotionSpeedXParameter = "";

		[EditorHelp("Speed Y Float Parameter", "Root motion movement will set this float parameter of the 'Animator' component's animator controller.\n" +
			"Sets the Y-axis speed for 2-dimensional blend trees.\n" +
			"Leave empty (no value) to not use this parameter or when only using 1-dimensional blend trees.")]
		[EditorWidth(true)]
		[EditorEndCondition]
		public string rootMotionSpeedYParameter = "";

		public NavMeshAgentMovementComponentSetting()
		{

		}

		public override IMovementComponent Init(GameObject gameObject)
		{
			return new MoveComponent(gameObject, this);
		}


		/*
		============================================================================
		Move component class
		============================================================================
		*/
		public class MoveComponent : IMovementComponent
		{
			private NavMeshAgentMovementComponentSetting setting;

			private NavMeshAgent navMeshAgent;


			// root motion
			private Animator animator;

			private Vector2 rootMotionVelocity = Vector2.zero;

			private Vector2 rootMotionSmoothDeltaPosition = Vector2.zero;

			public MoveComponent(GameObject gameObject, NavMeshAgentMovementComponentSetting setting)
			{
				this.setting = setting;

				this.navMeshAgent = gameObject.GetComponentInChildren<NavMeshAgent>();
				if(this.navMeshAgent == null)
				{
					this.navMeshAgent = gameObject.GetComponentInParent<NavMeshAgent>();
				}
				if(this.navMeshAgent == null &&
					this.setting.compAdd)
				{
					this.navMeshAgent = gameObject.AddComponent<NavMeshAgent>();
				}

				if(this.navMeshAgent != null)
				{
					if(!this.navMeshAgent.isOnNavMesh)
					{
						this.navMeshAgent.enabled = false;
						this.navMeshAgent.enabled = true;
					}
				}

				if(this.setting.useRootMotion)
				{
					this.animator = gameObject.GetComponentInChildren<Animator>();
					if(this.animator != null &&
						this.animator.applyRootMotion)
					{
						ComponentHelper.Get<AnimatorMoveForward>(this.animator.gameObject).SetMover(this);

						this.navMeshAgent.updatePosition = false;
						this.navMeshAgent.updateRotation = true;
					}
				}
			}

			public virtual void Move(Vector3 change)
			{
				if(this.navMeshAgent != null &&
					this.navMeshAgent.isOnNavMesh)
				{
					this.navMeshAgent.Move(change);
				}
			}

			public virtual bool MoveTo(ref Vector3 position, float speed)
			{
				if(this.navMeshAgent != null &&
					this.navMeshAgent.isOnNavMesh)
				{
					// get nearest NavMesh position
					NavMeshHit hit;
					if(NavMesh.SamplePosition(position, out hit,
						this.setting.sampleDistance,
						this.setting.sampleAreaMask))
					{
						position = hit.position;
					}
					this.navMeshAgent.speed = speed;

					NavMeshPath path = new NavMeshPath();
					this.navMeshAgent.CalculatePath(position, path);
					this.navMeshAgent.path = path;
					position = this.navMeshAgent.pathEndPosition;

					//this.navMeshAgent.SetDestination(position);
					this.navMeshAgent.isStopped = false;
					return true;
				}
				return false;
			}

			public virtual void SetPosition(Vector3 position)
			{
				if(this.navMeshAgent != null &&
					this.navMeshAgent.isOnNavMesh)
				{
					this.navMeshAgent.Warp(position);
				}
			}

			public virtual void Stop()
			{
				if(this.navMeshAgent != null &&
					this.navMeshAgent.isOnNavMesh)
				{
					if(this.setting.stopImmediately)
					{
						this.navMeshAgent.velocity = Vector3.zero;
					}
					this.navMeshAgent.isStopped = true;
				}
			}


			/*
			============================================================================
			Root motion functions
			============================================================================
			*/
			public virtual void AnimatorMove()
			{
				if(this.animator != null &&
					this.navMeshAgent != null)
				{
					Vector3 position = this.animator.rootPosition;
					if(this.navMeshAgent.enabled &&
						this.navMeshAgent.isOnNavMesh &&
						!this.navMeshAgent.isStopped)
					{
						position.y = this.navMeshAgent.nextPosition.y;
						this.navMeshAgent.transform.position = position;
						this.navMeshAgent.nextPosition = position;
					}
					else
					{
						this.navMeshAgent.transform.position = position;
					}
				}
			}

			public virtual void AnimatorUpdate()
			{
				if(this.animator != null &&
					this.navMeshAgent != null &&
					this.navMeshAgent.enabled &&
					this.navMeshAgent.isOnNavMesh &&
					!this.navMeshAgent.isStopped)
				{
					Vector3 worldDeltaPosition = this.navMeshAgent.nextPosition - this.navMeshAgent.transform.position;
					worldDeltaPosition.y = 0;

					float dx = Vector3.Dot(this.navMeshAgent.transform.right, worldDeltaPosition);
					float dy = Vector3.Dot(this.navMeshAgent.transform.forward, worldDeltaPosition);
					Vector2 deltaPosition = new Vector2(dx, dy);

					float smooth = Mathf.Min(1, Time.deltaTime / 0.1f);
					this.rootMotionSmoothDeltaPosition = Vector2.Lerp(this.rootMotionSmoothDeltaPosition, deltaPosition, smooth);

					this.rootMotionVelocity = this.rootMotionSmoothDeltaPosition / Time.deltaTime;
					if(this.navMeshAgent.remainingDistance <= this.navMeshAgent.stoppingDistance)
					{
						this.rootMotionVelocity = Vector2.Lerp(
							Vector2.zero,
							this.rootMotionVelocity,
							this.navMeshAgent.remainingDistance / this.navMeshAgent.stoppingDistance
						);
					}

					if(this.setting.rootMotionMoveBoolParameter != "")
					{
						this.animator.SetBool(this.setting.rootMotionMoveBoolParameter,
							this.rootMotionVelocity.magnitude > 0.5f &&
								this.navMeshAgent.remainingDistance > this.navMeshAgent.stoppingDistance);
					}
					if(this.setting.rootMotionSpeedXParameter != "")
					{
						// 2-dimensional
						if(this.setting.rootMotionSpeedYParameter != "")
						{
							this.animator.SetFloat(this.setting.rootMotionSpeedXParameter, this.rootMotionVelocity.x);
							this.animator.SetFloat(this.setting.rootMotionSpeedYParameter, this.rootMotionVelocity.y);
						}
						// 1-dimensional
						else
						{
							this.animator.SetFloat(this.setting.rootMotionSpeedXParameter, this.rootMotionVelocity.magnitude);
						}
					}

					float deltaMagnitude = worldDeltaPosition.magnitude;
					if(deltaMagnitude > this.navMeshAgent.radius / 2f)
					{
						this.navMeshAgent.transform.position = Vector3.Lerp(
							this.animator.rootPosition,
							this.navMeshAgent.nextPosition,
							smooth
						);
					}
				}
			}
		}


		/*
		============================================================================
		Animator move forward class
		============================================================================
		*/
		[AddComponentMenu("")]
		public class AnimatorMoveForward : MonoBehaviour
		{
			protected NavMeshAgentMovementComponentSetting.MoveComponent mover;

			public virtual void SetMover(NavMeshAgentMovementComponentSetting.MoveComponent mover)
			{
				this.mover = mover;
			}

			protected virtual void OnAnimatorMove()
			{
				if(this.mover != null)
				{
					this.mover.AnimatorMove();
				}
			}

			protected virtual void Update()
			{
				if(this.mover != null)
				{
					this.mover.AnimatorUpdate();
				}
			}
		}
	}
}
