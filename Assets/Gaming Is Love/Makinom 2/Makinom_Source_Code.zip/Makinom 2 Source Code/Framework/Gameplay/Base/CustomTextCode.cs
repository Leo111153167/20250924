﻿
using UnityEngine;
using System.Collections.Generic;

namespace GamingIsLove.Makinom
{
	public class CustomTextCode : BaseData, IFoldoutInfo
	{
		[EditorHelp("Text Code", "Define the custom text code that will be used.\n" +
			"It's recommended to enclose a text code with '<' and '>' strings (e.g. '<customcode>') or " +
			"start a text code with a '%'-sign (e.g. '%customcode').", "")]
		[EditorWidth(true)]
		public string textCode = "";

		[EditorHelp("Text", "The text used to replace the defined text code.", "")]
		[EditorLanguageExport("CustomTextCode")]
		public LanguageData<TextContent> value = new LanguageData<TextContent>();

		public CustomTextCode()
		{

		}

		public virtual string GetFoldoutInfo()
		{
			return this.textCode;
		}

		public void Replace(UIText text, VariableHandler handler)
		{
			if(text.text.Contains(this.textCode))
			{
				UIText newText = this.value.Current;
				newText.ReplaceSpecials(handler);
				text.Replace(this.textCode, newText.text);
			}
		}

		public void Replace(ref string text, VariableHandler handler)
		{
			if(text.Contains(this.textCode))
			{
				UIText newText = this.value.Current;
				newText.ReplaceSpecials(handler);
				text = text.Replace(this.textCode, newText.text);
			}
		}
	}
}
