﻿
using UnityEngine;
using System.Collections.Generic;

namespace GamingIsLove.Makinom
{
	[EditorSettingInfo("Box 3D", "Checks if colliders are within a box shape (uses 'Collider')..")]
	public class Box3DShapecheckType<T> : BaseShapecheckType<T> where T : IObjectSelection, new()
	{
		[EditorTitleLabel("Center")]
		[EditorLabel("The centre of the box.")]
		public Vector3Value<T> origin = new Vector3Value<T>();

		[EditorSeparator]
		[EditorTitleLabel("Half Extents")]
		[EditorLabel("The extents of the box into each direction (i.e. half size of the box).")]
		public Vector3Value<T> size = new Vector3Value<T>();

		[EditorSeparator]
		[EditorTitleLabel("Orientation")]
		[EditorLabel("The orientation of the box.")]
		public Vector3Value<T> orientation = new Vector3Value<T>();

		public Box3DShapecheckType()
		{

		}

		public override string ToString()
		{
			return "Box 3D";
		}

		public override bool Check(IDataCall call, int layerMask)
		{
			return Physics.CheckBox(
				this.origin.GetValue(call), this.size.GetValue(call),
				Quaternion.Euler(this.orientation.GetValue(call)), layerMask);
		}

		public override Collider Overlap(IDataCall call, int layerMask)
		{
			Collider[] collider = Physics.OverlapBox(
				this.origin.GetValue(call), this.size.GetValue(call),
				Quaternion.Euler(this.orientation.GetValue(call)), layerMask);

			return collider != null && collider.Length > 0 ? collider[0] : null;
		}

		public override Collider[] OverlapAll(IDataCall call, int layerMask)
		{
			return Physics.OverlapBox(
				this.origin.GetValue(call), this.size.GetValue(call),
				Quaternion.Euler(this.orientation.GetValue(call)), layerMask);
		}

		public override Collider2D Overlap2D(IDataCall call, int layerMask)
		{
			return null;
		}

		public override Collider2D[] OverlapAll2D(IDataCall call, int layerMask)
		{
			return null;
		}
	}
}
