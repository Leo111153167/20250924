﻿
using UnityEngine;
using System.Collections.Generic;
using System.IO;

namespace GamingIsLove.Makinom
{
	public enum ApplicationPathType { None, DataPath, PersistentDataPath, StreamingAssetsPath, TemporaryCachePath };

	[EditorCombinedField("pathOrigin", "path", flexibleSpace=true)]
	public class ApplicationPath : BaseData, ICustomVisualization
	{
		[EditorHelp("Path Origin", "Select where the path is located:\n" +
			"- None: Only uses the defined path.\n" +
			"- Data Path: Uses 'Application.dataPath'.\n" +
			"- Persistent Data Path: Uses 'Application.persistentDataPath'.\n" +
			"- Streaming Asset Path: Uses 'Application.streamingAssetsPath', " +
			"usually located at 'Assets/StreamingAssets/' in your Unity project.\n" +
			"- Temporary Cache Path: Uses 'Application.temporaryCachePath'.", "")]
		[EditorHide]
		[EditorWidth(150, true, noHorizontal=true)]
		public ApplicationPathType pathOrigin = ApplicationPathType.DataPath;

		[EditorHelp("Path", "Define the path within the path origin.", "")]
		[EditorHide]
		[EditorWidth(true, hideName=true, noHorizontal=true)]
		public string path = "";

		public ApplicationPath()
		{

		}

		public ApplicationPath(ApplicationPathType pathOrigin)
		{
			this.pathOrigin = pathOrigin;
		}

		public string Get()
		{
			return ApplicationPath.GetPath(this.pathOrigin, this.path);
		}

		public static string GetPath(ApplicationPathType pathOrigin, string path)
		{
			if(ApplicationPathType.None == pathOrigin)
			{
				return path;
			}
			else if(ApplicationPathType.DataPath == pathOrigin)
			{
				return Path.Combine(Application.dataPath, path);
			}
			else if(ApplicationPathType.PersistentDataPath == pathOrigin)
			{
				return Path.Combine(Application.persistentDataPath, path);
			}
			else if(ApplicationPathType.StreamingAssetsPath == pathOrigin)
			{
				return Path.Combine(Application.streamingAssetsPath, path);
			}
			else if(ApplicationPathType.TemporaryCachePath == pathOrigin)
			{
				return Path.Combine(Application.temporaryCachePath, path);
			}
			return path;
		}
	}
}
