﻿
using UnityEngine;
using System.Collections.Generic;

namespace GamingIsLove.Makinom
{
	public interface IInteractionBehaviour
	{
		/*
		============================================================================
		Properties
		============================================================================
		*/
		bool enabled
		{
			get;
			set;
		}

		bool isActiveAndEnabled
		{
			get;
		}

		GameObject gameObject
		{
			get;
		}

		Transform transform
		{
			get;
		}

		MachineTypeAsset MachineType
		{
			get;
		}
		
		
		/*
		============================================================================
		Condition functions
		============================================================================
		*/
		bool CheckConditions(GameObject startingObject, bool isAutoCheck);


		/*
		============================================================================
		Interact functions
		============================================================================
		*/
		bool IsInteract
		{
			get;
		}

		bool CanInteract(GameObject startingObject);

		bool Interact(GameObject startingObject);

		void StartInteraction(GameObject startingObject);

		void AutoStopInteraction();


		/*
		============================================================================
		Move to interaction functions
		============================================================================
		*/
		float MoveDestinationOffset
		{
			get;
		}

		MoveToInteractionComponentSettings MoveToInteractionSettings
		{
			get;
		}
	}
}
