﻿
using UnityEngine;
using System.Collections.Generic;

namespace GamingIsLove.Makinom
{
	[EditorSettingInfo("Direction", "The start position and direction are defined by values.")]
	public class DirectionRaycastType<T> : BaseRaycastType<T> where T : IObjectSelection, new()
	{
		[EditorHelp("Distance", "The distance the raycast will use.\n" +
			"If nothing is hit within this distance, no target will be found.", "")]
		public FloatValue<T> distance = new FloatValue<T>(100.0f);

		[EditorTitleLabel("Start Position")]
		public Vector3Value<T> startPosition = new Vector3Value<T>();

		[EditorSeparator]
		[EditorTitleLabel("Direction")]
		public Vector3Value<T> direction = new Vector3Value<T>(Vector3Direction.Forward);

		public DirectionRaycastType()
		{

		}

		public override string ToString()
		{
			return "Direction";
		}

		public override RaycastOutput Raycast(IDataCall call, RaycastType raycastType,
			int layerMask, Vector3 originOffset, bool storeCoords, Camera camera)
		{
			RaycastOutput hit = null;
			if(RaycastHelper.Raycast(raycastType,
				this.startPosition.GetValue(call) + originOffset,
				this.direction.GetValue(call), out hit, this.distance.GetValue(call), layerMask, storeCoords))
			{
				return hit;
			}
			return null;
		}

		public override List<RaycastOutput> RaycastAll(IDataCall call, RaycastType raycastType,
			int layerMask, Vector3 originOffset, bool storeCoords, Camera camera)
		{
			return RaycastHelper.RaycastAll(raycastType,
				this.startPosition.GetValue(call) + originOffset,
				this.direction.GetValue(call), this.distance.GetValue(call), layerMask, storeCoords);
		}
	}
}
