﻿
using UnityEngine;
using System.Collections.Generic;

namespace GamingIsLove.Makinom
{
	[EditorSettingInfo("Capsule 2D", "Casts a capsule into the scene (uses 'Collider2D').")]
	public class Capsule2DShapecastType<T> : BaseShapecastType<T> where T : IObjectSelection, new()
	{
		[EditorHelp("Capsule Direction", "Select the direction of the shape cast.")]
		public CapsuleDirection2D direction = CapsuleDirection2D.Vertical;

		[EditorSeparator]
		[EditorTitleLabel("Origin")]
		[EditorLabel("The point in 2D space where the shape originates.\n" +
			"Ignores the Z-axis.")]
		public Vector3Value<T> origin = new Vector3Value<T>();

		[EditorSeparator]
		[EditorTitleLabel("Size")]
		[EditorLabel("The size of the shape.\n" +
			"Ignores the Z-axis.")]
		public Vector3Value<T> size = new Vector3Value<T>();

		[EditorHelp("Angle", "The angle of the shape (in degrees).", "")]
		[EditorSeparator]
		[EditorTitleLabel("Angle")]
		public FloatValue<T> angle = new FloatValue<T>();


		// depth
		[EditorHelp("Minimum Depth", "Only include objects with a Z coordinate (depth) greater than this value.", "")]
		[EditorSeparator]
		[EditorTitleLabel("Minimum Depth")]
		public FloatValue<T> minDepth = new FloatValue<T>(typeof(FloatValue_NegativeInfinityType<T>));

		[EditorHelp("Maximum Depth", "Only include objects with a Z coordinate (depth) less than this value.", "")]
		[EditorSeparator]
		[EditorTitleLabel("Maximum Depth")]
		public FloatValue<T> maxDepth = new FloatValue<T>(typeof(FloatValue_InfinityType<T>));

		public Capsule2DShapecastType()
		{

		}

		public override string ToString()
		{
			return "Capsule 2D";
		}

		public override bool CastSingle(out RaycastOutput hit, IDataCall call, Vector3 direction, float maxDistance, int layerMask, bool storeCoords)
		{
			RaycastHit2D tmpHit = Physics2D.CapsuleCast(
				this.origin.GetValue(call), this.size.GetValue(call), this.direction,
				this.angle.GetValue(call), direction, maxDistance, layerMask,
				this.minDepth.GetValue(call), this.maxDepth.GetValue(call));

			if(tmpHit.collider != null)
			{
				hit = new RaycastOutput(tmpHit);
				return true;
			}
			else
			{
				hit = null;
				return false;
			}
		}

		public override RaycastOutput[] CastAll(IDataCall call, Vector3 direction, float maxDistance, int layerMask, bool storeCoords)
		{
			RaycastHit2D[] tmpHit = Physics2D.CapsuleCastAll(
				this.origin.GetValue(call), this.size.GetValue(call), this.direction,
				this.angle.GetValue(call), direction, maxDistance, layerMask,
				this.minDepth.GetValue(call), this.maxDepth.GetValue(call));

			if(tmpHit != null)
			{
				RaycastOutput[] hit = new RaycastOutput[tmpHit.Length];
				for(int i = 0; i < tmpHit.Length; i++)
				{
					hit[i] = new RaycastOutput(tmpHit[i]);
				}
				return hit;
			}
			return null;
		}
	}
}
