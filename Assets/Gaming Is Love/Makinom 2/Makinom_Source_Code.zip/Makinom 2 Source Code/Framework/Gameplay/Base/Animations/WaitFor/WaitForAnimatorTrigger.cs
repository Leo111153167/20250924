﻿
using UnityEngine;
using System.Collections;
using System.Collections.Generic;

namespace GamingIsLove.Makinom
{
	public class WaitForAnimatorTrigger : BaseWaitForAnim
	{
		private Animator animator;

		public WaitForAnimatorTrigger(Animator animator)
		{
			this.animator = animator;
		}

		public Animator Animator
		{
			get { return this.animator; }
		}

		public override void Reset()
		{
			if(this.animator != null)
			{
				this.animator.Rebind();
			}
		}

		public override void Play(string name, Notify callback, bool wait, float maxWaitTime)
		{
			this.Cancel();

			if(this.animator != null &&
				!string.IsNullOrEmpty(name))
			{
				this.maxWaitTime = maxWaitTime;
				this.animator.SetTrigger(name);

				if(wait &&
					this.maxWaitTime > 0)
				{
					this.coroutine = Maki.StartCoroutine(this.Wait(name, callback, wait));
				}
				else if(callback != null)
				{
					callback();
				}
			}
		}

		private IEnumerator Wait(string name, Notify callback, bool wait)
		{
			if(this.animator != null)
			{
				float timeout = Time.realtimeSinceStartup + Mathf.Min(this.maxWaitTime,
					this.animator.GetCurrentAnimatorStateInfo(0).length);
				while(Time.realtimeSinceStartup < timeout)
				{
					yield return null;
				}

				/*yield return new WaitForSeconds(Mathf.Min(this.maxWaitTime,
					this.animator.GetCurrentAnimatorStateInfo(0).length));*/
				/*float timeout = Time.realtimeSinceStartup + this.maxWaitTime;

				int hashID = Animator.StringToHash(name);
				int currentHashID = this.animator.GetCurrentAnimatorStateInfo(0).fullPathHash;
				int nextHashID = currentHashID;

				while(nextHashID != hashID &&
					nextHashID == currentHashID &&
					Time.realtimeSinceStartup < timeout)
				{
					yield return null;
					if(this.animator != null)
					{
						nextHashID = this.animator.GetCurrentAnimatorStateInfo(0).fullPathHash;
					}
					else
					{
						break;
					}
				}

				if(Time.realtimeSinceStartup < timeout)
				{
					if(this.animator != null)
					{
						timeout = Time.realtimeSinceStartup + Mathf.Min(timeout,
							this.animator.GetCurrentAnimatorStateInfo(0).length);
					}
					else
					{
						timeout = 0;
					}

					while(Time.realtimeSinceStartup < timeout)
					{
						yield return (object)null;
					}
				}*/
			}
			else
			{
				yield return null;
			}

			this.coroutine = null;
			if(callback != null)
			{
				callback();
			}
		}
	}
}
