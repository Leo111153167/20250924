﻿
using UnityEngine;
using UnityEngine.Audio;
using System.Collections.Generic;

namespace GamingIsLove.Makinom
{
	public class MusicAudioSource
	{
		protected AudioSource source1;

		protected AudioSource source2;

		protected int playing = 0;

		protected double nextLoopCheck = 0;

		public MusicAudioSource(AudioSource source1, AudioSource source2)
		{
			this.source1 = source1;
			this.source2 = source2;
		}

		public bool IsInitialized
		{
			get { return this.source1 != null && this.source2 != null; }
		}

		public virtual AudioSource Source1
		{
			get { return this.source1; }
		}

		public virtual AudioSource Source2
		{
			get { return this.source2; }
		}


		/*
		============================================================================
		Properties
		============================================================================
		*/
		public virtual bool isPlaying
		{
			get { return this.source1.isPlaying || this.source2.isPlaying; }
		}

		public virtual bool loop
		{
			get { return this.source1.loop; }
			set
			{
				this.source1.loop = value;
				this.source2.loop = value;
			}
		}

		public virtual float volume
		{
			get { return this.source1.volume; }
			set
			{
				this.source1.volume = value;
				this.source2.volume = value;
			}
		}

		public virtual float time
		{
			get
			{
				if(this.playing == 1)
				{
					return this.source1.time;
				}
				else if(this.playing == 2)
				{
					return this.source2.time;
				}
				return 0;
			}
			set
			{
				this.source1.time = value;
				this.source2.time = value;
			}
		}

		public virtual int timeSamples
		{
			get
			{
				if(this.playing == 1)
				{
					return this.source1.timeSamples;
				}
				else if(this.playing == 2)
				{
					return this.source2.timeSamples;
				}
				return 0;
			}
			set
			{
				this.source1.timeSamples = value;
				this.source2.timeSamples = value;
			}
		}

		public virtual AudioClip clip
		{
			get { return this.source1.clip; }
			set
			{
				this.source1.clip = value;
				this.source2.clip = value;
			}
		}

		public virtual AudioMixerGroup outputAudioMixerGroup
		{
			get { return this.source1.outputAudioMixerGroup; }
			set
			{
				this.source1.outputAudioMixerGroup = value;
				this.source2.outputAudioMixerGroup = value;
			}
		}


		/*
		============================================================================
		Play functions
		============================================================================
		*/
		public virtual void Stop()
		{
			this.source1.Stop();
			this.source2.Stop();
			this.playing = 0;
		}

		public virtual void Play(MusicClip music)
		{
			this.clip = music.GetClip();
			if(music.Settings.useStartPCM)
			{
				this.timeSamples = music.Settings.startPCM;
			}
			else
			{
				this.time = music.Settings.startTime;
			}
			this.loop = music.Settings.doLoop;

			this.source1.Play();
			this.source1.PlayScheduled(AudioSettings.dspTime);
			this.playing = 1;
			this.ScheduleLoop(music);
		}

		public virtual void ScheduleLoop(MusicClip music)
		{
			if(this.playing > 0)
			{
				MusicClipLoop currentLoop = music.GetCurrentLoop();

				if(currentLoop != null)
				{
					AudioSource audioPlaying = this.source1;
					AudioSource audioLoop = this.source2;
					if(this.playing == 2)
					{
						audioPlaying = this.source2;
						audioLoop = this.source1;
					}

					double duration = AudioSettings.dspTime;

					// end loop
					if(currentLoop.endLoop)
					{
						duration += (double)(audioPlaying.clip.samples - audioPlaying.timeSamples) / audioPlaying.clip.frequency;
						audioLoop.time = 0;
					}
					// pcm
					else if(currentLoop.usePCM)
					{
						duration += (double)(currentLoop.checkPCM - audioPlaying.timeSamples) / audioPlaying.clip.frequency;
						audioLoop.timeSamples = currentLoop.setPCM;
					}
					// time
					else
					{
						duration += currentLoop.checkTime - audioPlaying.time;
						audioLoop.time = currentLoop.setTime;
					}

					audioPlaying.SetScheduledEndTime(duration);
					audioLoop.Stop();
					audioLoop.PlayScheduled(duration);
					this.nextLoopCheck = duration + 0.01;
				}
			}
		}

		public virtual void CheckNextLoop(MusicClip music)
		{
			if(this.playing > 0 &&
				AudioSettings.dspTime >= this.nextLoopCheck)
			{
				this.playing = this.playing == 1 ? 2 : 1;
				music.NextLoop();
				this.ScheduleLoop(music);
			}
		}
	}
}
