
using UnityEngine;
using System.Collections.Generic;

namespace GamingIsLove.Makinom.Components
{
	[AddComponentMenu("")]
	public class ScalerComponent : MonoBehaviour
	{
		protected Transform actor;

		protected GetFloat deltaTime;

		protected bool inPause = false;

		protected Interpolation.Vector3Instance interpolation;

		protected bool scale = false;

		public virtual void StopMoving()
		{
			this.actor = null;
			this.scale = false;
			this.interpolation = null;
			this.deltaTime = null;
			this.inPause = false;
		}


		/*
		============================================================================
		Scale functions
		============================================================================
		*/
		public virtual void Scale(Transform a, float time, Vector3 scale, Interpolation interpolation, GetFloat deltaTime, bool inPause)
		{
			this.StopMoving();

			this.deltaTime = deltaTime;
			this.inPause = inPause;
			this.actor = a;
			this.interpolation = interpolation.CreateVector3(this.actor.localScale, scale, time);

			this.scale = true;
			this.enabled = true;
		}


		/*
		============================================================================
		Update functions
		============================================================================
		*/
		protected virtual void Update()
		{
			if(this.scale &&
				(this.inPause || !Maki.Game.Paused))
			{
				this.actor.localScale = this.interpolation.Tick(this.deltaTime == null ? Maki.Game.DeltaTime : this.deltaTime());
				if(this.interpolation.Finished)
				{
					this.scale = false;
					this.enabled = false;
				}
			}
		}
	}
}
