
using UnityEngine;
using GamingIsLove.Makinom.Schematics;
using System.Collections;
using System.Collections.Generic;

namespace GamingIsLove.Makinom.Components
{
	[AddComponentMenu("")]
	public abstract class BaseMachineComponent : BaseConditionComponent, ISchematicStarter, ISerializationCallbackReceiver
	{
		[SerializeField]
		[HideInInspector]
		protected ComponentDataFile serialize_baseSettings;

		[System.NonSerialized]
		public MachineAssetSetting assetSetting = new MachineAssetSetting();

		[System.NonSerialized]
		public MachineStartVariableSetting startVariableSetting = new MachineStartVariableSetting();

		[System.NonSerialized]
		public MachineChangeAfterSetting changeAfterSetting = new MachineChangeAfterSetting();


		// objects
		public MachineActor[] actor = new MachineActor[0];

		public MachineResourcesSetting resources = new MachineResourcesSetting();


		// ingame
		protected Schematic schematic;

		protected bool machineStarted = false;

		protected bool isDestroyed = false;

		protected Quaternion storedRotation = Quaternion.identity;

		protected List<MachineEnded> notifyEnd;


		/*
		============================================================================
		Notify functions
		============================================================================
		*/
		public virtual void NotifyEnd(MachineEnded notify)
		{
			if(notify != null)
			{
				if(this.notifyEnd == null)
				{
					this.notifyEnd = new List<MachineEnded>();
				}
				this.notifyEnd.Add(notify);
			}
		}

		public virtual void ClearNotifyEnd()
		{
			if(this.notifyEnd != null &&
				this.notifyEnd.Count > 0)
			{
				this.notifyEnd.Clear();
			}
		}


		/*
		============================================================================
		Getters functions
		============================================================================
		*/
		public virtual MachineTypeAsset MachineType
		{
			get { return this.assetSetting.machineType.StoredAsset; }
		}

		public virtual bool CanRestart(GameObject startingObject)
		{
			return this.CheckConditions(startingObject, false);
		}


		/*
		============================================================================
		Editor functions
		============================================================================
		*/
		public virtual bool DisplayActor()
		{
			if(this.assetSetting.schematicAsset != null)
			{
				this.CheckActors(this.assetSetting.schematicAsset.Settings);

				for(int i = 0; i < this.assetSetting.schematicAsset.Settings.actor.Length; i++)
				{
					if(this.assetSetting.schematicAsset.Settings.actor[i].settings.EditorSelectGameObject)
					{
						return true;
					}
				}
			}
			return false;
		}

		public virtual void CheckActors(SchematicSettings settings)
		{
			if(this.actor.Length != settings.actor.Length)
			{
				MachineActor[] tmp2 = this.actor;
				this.actor = new MachineActor[settings.actor.Length];
				for(int i = 0; i < this.actor.Length; i++)
				{
					if(i < tmp2.Length)
					{
						this.actor[i] = tmp2[i];
					}
					else
					{
						this.actor[i] = new MachineActor();
					}
				}
			}
		}


		/*
		============================================================================
		Register functions
		============================================================================
		*/
		public virtual void Register()
		{
			
		}

		public virtual void Unregister()
		{
			
		}

		protected override void OnEnable()
		{
			bool destroyed = false;
			if(ConditionAutoCheckType.Enable == this.conditionSetting.autoCheckType)
			{
				destroyed = this.CheckAutoDestroy();
			}

			if(!destroyed)
			{
				this.Register();
			}
		}

		protected virtual void OnDisable()
		{
			this.Unregister();

			if(this.assetSetting.stopOnDestroy)
			{
				this.StopMachine();
			}
		}

		protected virtual void OnDestroy()
		{
			this.isDestroyed = true;
			if(this.assetSetting.stopOnDestroy)
			{
				this.StopMachine();
			}
		}


		/*
		============================================================================
		Schematic asset functions
		============================================================================
		*/
		protected virtual void Awake()
		{
			this.LoadSchematic();
		}

		public virtual bool SchematicFound
		{
			get
			{
				if(this.schematic == null)
				{
					this.LoadSchematic();
				}
				return this.schematic != null;
			}
		}

		public virtual Schematic RuntimeSchematic
		{
			get { return this.schematic; }
		}

		public virtual void LoadSchematic()
		{
			if(this.schematic == null &&
				this.assetSetting.schematicAsset != null)
			{
				this.schematic = new Schematic(this.assetSetting.schematicAsset);

				if(this.assetSetting.autoStop)
				{
					this.schematic.AutoStopCheckTime = this.assetSetting.autoStopCheckTime;
				}
			}
		}

		public virtual void LoadSchematicEditor()
		{
			if(Application.isEditor &&
				!Application.isPlaying &&
				this.assetSetting.schematicAsset != null)
			{
				this.CheckActors(this.assetSetting.schematicAsset.Settings);
				this.startVariableSetting.CheckStartVariables(this.assetSetting.schematicAsset.Settings);
				this.resources.CheckSchematic(this.assetSetting.schematicAsset.Settings);
			}
		}


		/*
		============================================================================
		Start machine functions
		============================================================================
		*/
		public virtual IEnumerator StartMachine(GameObject startingObject, VariableHandler startVariables, float delay)
		{
			yield return new WaitForSeconds(delay);
			this.StartMachine(startingObject, startVariables);
		}

		public virtual void StartMachine(GameObject startingObject, VariableHandler startVariables)
		{
			if(!this.machineStarted)
			{
				if(this.SchematicFound &&
					(Maki.Control.CanInteract ||
						MachineExecutionType.Blocking != this.assetSetting.executionType))
				{
					this.CancelAutoDestroy();

					// do turns
					TransformHelper.InteractionTurns(this.assetSetting.turnStartingObject, startingObject,
						this.assetSetting.turnMachineObject, this.gameObject, ref this.storedRotation);

					if(MachineExecutionType.Multi == this.assetSetting.executionType)
					{
						Schematic tmpSchematic = null;
						if(this.schematic.Executing)
						{
							tmpSchematic = new Schematic(this.assetSetting.schematicAsset);
						}
						else
						{
							this.schematic.Clear();
							tmpSchematic = this.schematic;
						}

						if(tmpSchematic != null)
						{
							if(startVariables != null)
							{
								tmpSchematic.Variables = startVariables;
							}
							tmpSchematic.InPause = this.assetSetting.inPause;
							this.StartMachine(tmpSchematic, startingObject);
						}
					}
					else
					{
						this.machineStarted = true;
						if(startVariables != null)
						{
							this.schematic.Variables = startVariables;
						}
						this.schematic.InPause = this.assetSetting.inPause;
						this.StartMachine(this.schematic, startingObject);
					}
				}
			}
		}

		protected virtual void StartMachine(Schematic tmpSchematic, GameObject startingObject)
		{
			if(this.assetSetting.startDelayTime > 0)
			{
				this.StartCoroutine(this.StartAfter(tmpSchematic, startingObject));
			}
			else
			{
				if(this.assetSetting.setPriority)
				{
					tmpSchematic.PlaySchematic(this.assetSetting.priority, this, this,
						this.gameObject, startingObject,
						MachineExecutionType.Blocking == this.assetSetting.executionType,
						this.assetSetting.updateType,
						this.assetSetting.inputID.GetInputID(this.gameObject, startingObject));
				}
				else
				{
					tmpSchematic.PlaySchematic(this, this,
						this.gameObject, startingObject,
						MachineExecutionType.Blocking == this.assetSetting.executionType,
						this.assetSetting.updateType,
						this.assetSetting.inputID.GetInputID(this.gameObject, startingObject));
				}
			}
		}

		protected virtual IEnumerator StartAfter(Schematic tmpSchematic, GameObject startingObject)
		{
			yield return new WaitForSeconds(this.assetSetting.startDelayTime);
			if(this.assetSetting.setPriority)
			{
				tmpSchematic.PlaySchematic(this.assetSetting.priority, this, this,
					this.gameObject, startingObject,
					MachineExecutionType.Blocking == this.assetSetting.executionType,
					this.assetSetting.updateType,
					this.assetSetting.inputID.GetInputID(this.gameObject, startingObject));
			}
			else
			{
				tmpSchematic.PlaySchematic(this, this,
					this.gameObject, startingObject,
					MachineExecutionType.Blocking == this.assetSetting.executionType,
					this.assetSetting.updateType,
					this.assetSetting.inputID.GetInputID(this.gameObject, startingObject));
			}
		}


		/*
		============================================================================
		End machine functions
		============================================================================
		*/
		public virtual void StopMachine()
		{
			if(this.machineStarted)
			{
				if(this.schematic != null)
				{
					this.schematic.Stop();
				}
			}
		}

		public virtual void SchematicFinished(Schematic schematic)
		{
			if(this.assetSetting.endDelayTime > 0 &&
				!this.isDestroyed && this.isActiveAndEnabled)
			{
				this.StartCoroutine(this.EndAfter(schematic));
			}
			else
			{
				this.SchematicFinished2(schematic);
			}
		}

		protected virtual IEnumerator EndAfter(Schematic schematic)
		{
			yield return new WaitForSeconds(this.assetSetting.endDelayTime);
			this.SchematicFinished2(schematic);
		}

		protected virtual void SchematicFinished2(Schematic schematic)
		{
			if(this != null && this.gameObject != null && !this.isDestroyed)
			{
				if(this.changeAfterSetting.HasVariables)
				{
					GameObject startingObject = schematic != null && schematic.StartingObject != null ?
						schematic.StartingObject.GetFirst(schematic) : this.gameObject;
					this.changeAfterSetting.SetVariables(
						new DataCall(this.gameObject, startingObject,
							this.assetSetting.inputID.GetInputID(this.gameObject, startingObject)));
				}
				this.machineStarted = false;

				if(this.notifyEnd != null &&
					this.notifyEnd.Count > 0)
				{
					for(int i = 0; i < this.notifyEnd.Count; i++)
					{
						if(this.notifyEnd[i] != null)
						{
							this.notifyEnd[i](this);
						}
					}
					this.notifyEnd.Clear();
				}

				if(MachineConditionFailType.Destroy == this.assetSetting.endAction)
				{
					UnityWrapper.Destroy(this.gameObject);
				}
				else if(MachineConditionFailType.Disable == this.assetSetting.endAction)
				{
					this.gameObject.SetActive(false);
				}
				else
				{
					this.EndCheck();
				}
			}
		}

		protected override void EndCheck()
		{
			if(this.assetSetting.turnMachineObject &&
				this.assetSetting.turnRestoreMachineObject)
			{
				this.transform.rotation = this.storedRotation;
			}
			base.EndCheck();
		}


		/*
		============================================================================
		Serialization functions
		============================================================================
		*/
		public override void OnBeforeSerialize()
		{
			base.OnBeforeSerialize();

			DataObject data = new DataObject();

			data.Set("assetSetting", this.assetSetting.GetData());
			data.Set("changeAfterSetting", this.changeAfterSetting.GetData());
			data.Set("startVariableSetting", this.startVariableSetting.GetData());

			this.serialize_baseSettings = data.GetComponentDataFile("settings", false);
		}

		public override void OnAfterDeserialize()
		{
			base.OnAfterDeserialize();

			if(this.serialize_baseSettings != null)
			{
				DataObject data = this.serialize_baseSettings.ToDataObject();

				this.assetSetting.SetData(data.GetFile("assetSetting"));
				this.changeAfterSetting.SetData(data.GetFile("changeAfterSetting"));
				this.startVariableSetting.SetData(data.GetFile("startVariableSetting"));

				this.serialize_baseSettings = null;
			}
		}
	}
}
