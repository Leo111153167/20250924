
using UnityEngine;
using GamingIsLove.Makinom.Schematics;
using System.Collections;

namespace GamingIsLove.Makinom.Components
{
	[AddComponentMenu("Makinom/Machines/Auto Machine")]
	public class AutoMachineComponent : BaseMachineComponent, ISerializationCallbackReceiver
	{
		[System.NonSerialized]
		public Settings settings = new Settings();

		[SerializeField]
		[HideInInspector]
		protected ComponentDataFile serialize_setting;


		// in-game
		protected bool registered = false;

		protected bool initialized = false;

		public override bool CanRestart(GameObject startingObject)
		{
			return this.settings.startSetting.CanStart(this, startingObject);
		}


		/*
		============================================================================
		Register functions
		============================================================================
		*/
		public override void Register()
		{
			if(!this.registered && Maki.Instantiated)
			{
				base.Register();

				if(this.settings.startSetting.HasNotifyStart)
				{
					this.settings.startSetting.Register(this.gameObject, this.StartByNotification);
				}
				this.registered = true;
			}
		}

		public override void Unregister()
		{
			if(this.registered && Maki.Instantiated)
			{
				base.Unregister();

				if(this.settings.startSetting.HasNotifyStart)
				{
					this.settings.startSetting.Unregister(this.gameObject, this.StartByNotification);
				}
				this.registered = false;
			}
		}

		public virtual void StartByNotification()
		{
			if(this.settings.startSetting.CanStart(this, Maki.Game.Player.GameObject))
			{
				this.StartMachine(Maki.Game.Player.GameObject,
					this.startVariableSetting.HasStartVariables ?
						this.startVariableSetting.GetStartVariables(
							this.startVariableSetting.NeedsCall ? 
								new DataCall(this.gameObject, Maki.Game.Player.GameObject,
									this.assetSetting.inputID.GetInputID(this.gameObject, Maki.Game.Player.GameObject)) : null) :
						null);
			}
		}


		/*
		============================================================================
		Start functions
		============================================================================
		*/
		protected override void Start()
		{
			bool destroyed = false;

			if(ConditionAutoCheckType.Start == this.conditionSetting.autoCheckType)
			{
				destroyed = this.CheckAutoDestroy();
			}

			if(!destroyed)
			{
				this.initialized = true;
				this.Register();

				if(this.settings.startSetting.isStart)
				{
					this.AutoStartCheck();
				}
			}
		}

		protected override void OnEnable()
		{
			Maki.Instance.SceneLoaded += this.OnAutoSceneLoaded;
			bool destroyed = false;

			if(ConditionAutoCheckType.Enable == this.conditionSetting.autoCheckType)
			{
				destroyed = this.CheckAutoDestroy();
			}

			if(!destroyed)
			{
				if(this.initialized)
				{
					this.Register();
				}

				if(this.settings.startSetting.isEnable)
				{
					this.AutoStartCheck();
				}
			}
		}

		protected override void OnDisable()
		{
			Maki.Instance.SceneLoaded -= this.OnAutoSceneLoaded;
			this.Unregister();

			if(this.settings.startSetting.isDisable &&
				this.settings.startSetting.CanStartDisabled(this, Maki.Game.Player.GameObject))
			{
				this.StartMachine(Maki.Game.Player.GameObject,
					this.startVariableSetting.HasStartVariables ?
						this.startVariableSetting.GetStartVariables(
							this.startVariableSetting.NeedsCall ?
								new DataCall(this.gameObject, Maki.Game.Player.GameObject,
									this.assetSetting.inputID.GetInputID(this.gameObject, Maki.Game.Player.GameObject)) : null) :
						null);
			}
			else if(this.assetSetting.stopOnDestroy)
			{
				this.StopMachine();
			}
		}

		protected override void OnDestroy()
		{
			Maki.Instance.SceneLoaded -= this.OnAutoSceneLoaded;

			if(this.settings.startSetting.isDestroy &&
				this.settings.startSetting.CanStartDisabled(this, Maki.Game.Player.GameObject))
			{
				this.StartMachine(Maki.Game.Player.GameObject,
					this.startVariableSetting.HasStartVariables ?
						this.startVariableSetting.GetStartVariables(
							this.startVariableSetting.NeedsCall ? 
								new DataCall(this.gameObject, Maki.Game.Player.GameObject,
									this.assetSetting.inputID.GetInputID(this.gameObject, Maki.Game.Player.GameObject)) : null) :
						null);
			}
			else if(this.assetSetting.stopOnDestroy)
			{
				this.StopMachine();
			}
		}

		public virtual void OnAutoSceneLoaded()
		{
			if(this.settings.startSetting.isLevelWasLoaded)
			{
				this.AutoStartCheck();
			}
		}

		protected virtual void AutoStartCheck()
		{
			if(!this.CheckAutoDestroy())
			{
				if(this.schematic != null)
				{
					this.schematic.Clear();
				}
				else
				{
					this.LoadSchematic();
				}

				this.CheckAutoStart();
			}
		}

		protected virtual void CheckAutoStart()
		{
			if(this.settings.startSetting.CanStart(this, Maki.Game.Player.GameObject))
			{
				if(this.settings.startSetting.autoStartDelay > 0)
				{
					this.StartCoroutine(this.StartMachine(Maki.Game.Player.GameObject,
						this.startVariableSetting.HasStartVariables ?
							this.startVariableSetting.GetStartVariables(
								this.startVariableSetting.NeedsCall ? 
									new DataCall(this.gameObject, Maki.Game.Player.GameObject,
										this.assetSetting.inputID.GetInputID(this.gameObject, Maki.Game.Player.GameObject)) : null) :
							null,
						this.settings.startSetting.autoStartDelay));
				}
				else
				{
					this.StartMachine(Maki.Game.Player.GameObject,
						this.startVariableSetting.HasStartVariables ?
							this.startVariableSetting.GetStartVariables(
								this.startVariableSetting.NeedsCall ? 
									new DataCall(this.gameObject, Maki.Game.Player.GameObject,
										this.assetSetting.inputID.GetInputID(this.gameObject, Maki.Game.Player.GameObject)) : null) :
							null);
				}
			}
			else if(this.settings.startSetting.repeatExecution)
			{
				this.StartCoroutine(this.CheckAutoStart2());
			}
		}

		protected virtual IEnumerator CheckAutoStart2()
		{
			if(this.settings.startSetting.repeatDelay > 0)
			{
				yield return new WaitForSeconds(this.settings.startSetting.repeatDelay);
			}
			else
			{
				yield return null;
			}
			this.CheckAutoStart();
		}

		protected override void EndCheck()
		{
			if(this.settings.startSetting.IsStartCheck &&
				this.settings.startSetting.repeatExecution &&
				this.isActiveAndEnabled)
			{
				this.StartCoroutine(this.CheckAutoStart2());
			}
			base.EndCheck();
		}


		/*
		============================================================================
		Editor functions
		============================================================================
		*/
		protected virtual void OnDrawGizmos()
		{
			Gizmos.DrawIcon(transform.position, "/GamingIsLove/Makinom/Components/AutoMachineComponent Icon.png");
		}


		/*
		============================================================================
		Serialization functions
		============================================================================
		*/
		public override void OnBeforeSerialize()
		{
			base.OnBeforeSerialize();
			this.serialize_setting = this.settings.GetData().GetComponentDataFile("settings", false);
		}

		public override void OnAfterDeserialize()
		{
			base.OnAfterDeserialize();
			if(this.serialize_setting != null)
			{
				this.settings.SetData(this.serialize_setting.ToDataObject());
				this.serialize_setting = null;
			}
		}


		/*
		============================================================================
		Settings class
		============================================================================
		*/
		public class Settings : BaseData
		{
			[EditorFoldout("Start Settings", "Define the start settings of this machine.", "")]
			[EditorEndFoldout]
			public AutoMachineStartSetting startSetting = new AutoMachineStartSetting();

			public Settings()
			{

			}
		}
	}
}
