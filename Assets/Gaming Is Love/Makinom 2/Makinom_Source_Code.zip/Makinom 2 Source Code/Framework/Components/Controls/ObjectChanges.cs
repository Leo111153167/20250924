
using UnityEngine;
using GamingIsLove.Makinom;
using System.Collections.Generic;

namespace GamingIsLove.Makinom.Components
{
	[AddComponentMenu("Makinom/Controls/Object Changes")]
	public class ObjectChanges : SerializedBehaviour<ObjectChanges.Settings>
	{
		public enum UpdateMode { Auto, Update, LateUpdate, FixedUpdate };

		protected Changes updateChanges;

		protected Changes lateUpdateChanges;

		protected Changes fixedUpdateChanges;

		protected Vector3 lastPosition = Vector3.zero;

		protected float lastMoveTime = 0;

		protected virtual void Awake()
		{
			if(this.IsUpdate)
			{
				this.updateChanges = new Changes();
				this.updateChanges.Start(this.transform);
			}
			if(this.IsLateUpdate)
			{
				this.lateUpdateChanges = new Changes();
				this.lateUpdateChanges.Start(this.transform);
			}
			if(this.IsFixedUpdate)
			{
				this.fixedUpdateChanges = new Changes();
				this.fixedUpdateChanges.Start(this.transform);
			}
			this.lastPosition = this.transform.position;
		}

		public virtual bool IsUpdate
		{
			get
			{
				return UpdateMode.Auto == this.settings.mode ||
					UpdateMode.Update == this.settings.mode;
			}
		}

		public virtual bool IsLateUpdate
		{
			get
			{
				return UpdateMode.Auto == this.settings.mode ||
					UpdateMode.LateUpdate == this.settings.mode;
			}
		}

		public virtual bool IsFixedUpdate
		{
			get
			{
				return UpdateMode.Auto == this.settings.mode ||
					UpdateMode.FixedUpdate == this.settings.mode;
			}
		}


		/*
		============================================================================
		Update functions
		============================================================================
		*/
		protected virtual void Update()
		{
			if(this.IsUpdate)
			{
				this.updateChanges.Update(this.transform);
			}
		}

		protected virtual void LateUpdate()
		{
			if(this.IsLateUpdate)
			{
				this.lateUpdateChanges.Update(this.transform);
			}

			if(this.transform.position != this.lastPosition)
			{
				this.lastPosition = this.transform.position;
				this.lastMoveTime = Time.time;
			}
		}

		protected virtual void FixedUpdate()
		{
			if(this.IsFixedUpdate)
			{
				this.fixedUpdateChanges.Update(this.transform);
			}
		}

		public virtual Changes GetChanges(MachineUpdateType updateType)
		{
			if(UpdateMode.Auto == this.settings.mode)
			{
				if(MachineUpdateType.Update == updateType)
				{
					return this.updateChanges;
				}
				else if(MachineUpdateType.LateUpdate == updateType)
				{
					return this.lateUpdateChanges;
				}
				else if(MachineUpdateType.FixedUpdate == updateType)
				{
					return this.fixedUpdateChanges;
				}
			}
			else if(UpdateMode.Update == this.settings.mode)
			{
				return this.updateChanges;
			}
			else if(UpdateMode.LateUpdate == this.settings.mode)
			{
				return this.lateUpdateChanges;
			}
			else if(UpdateMode.FixedUpdate == this.settings.mode)
			{
				return this.fixedUpdateChanges;
			}
			return this.lateUpdateChanges;
		}

		public virtual Changes GetChanges()
		{
			return this.GetChanges(Time.inFixedTimeStep ?
				MachineUpdateType.FixedUpdate :
				MachineUpdateType.LateUpdate);
		}


		/*
		============================================================================
		Get functions
		============================================================================
		*/
		public virtual float HorizontalSpeed
		{
			get
			{
				return this.GetChanges().horizontalSpeed;
			}
		}

		public virtual float VerticalSpeed
		{
			get
			{
				return this.GetChanges().verticalSpeed;
			}
		}

		public virtual Vector3 Velocity
		{
			get
			{
				return this.GetChanges().velocity;
			}
		}

		public virtual float LastMoveTime
		{
			get { return this.lastMoveTime; }
			set { this.lastMoveTime = value; }
		}

		public virtual Vector3 PositionChange
		{
			get
			{
				return this.GetChanges().positionChange;
			}
		}

		public virtual Vector3 LocalPositionChange
		{
			get
			{
				return this.GetChanges().localPositionChange;
			}
		}

		public virtual Vector3 LocalLastDirection
		{
			get
			{
				return this.GetChanges().localLastDirection;
			}
			set
			{
				this.GetChanges().localLastDirection = value;
			}
		}

		public virtual Vector3 RotationChange
		{
			get
			{
				return this.GetChanges().rotationChange;
			}
		}

		public virtual Vector3 LocalRotationChange
		{
			get
			{
				return this.GetChanges().localRotationChange;
			}
		}

		public virtual Vector3 ScaleChange
		{
			get
			{
				return this.GetChanges().scaleChange;
			}
		}


		/*
		============================================================================
		Settings class
		============================================================================
		*/
		public class Settings : BaseData
		{
			[EditorHelp("Update Mode", "Select when the object changes (e.g. movement speed) will be updated:\n" +
				"- Auto: Separate updates for 'Update', 'Late Update' and 'Fixed Update'.\n" +
				"- Update: Only updates in 'Update' frames.\n" +
				"- Late Update: Only updates in 'Late Update' frame.\n" +
				"- Fixed Update: Only updates in 'Fixed Update' frame.")]
			public UpdateMode mode = UpdateMode.Auto;

			public Settings()
			{

			}
		}


		/*
		============================================================================
		Speed class
		============================================================================
		*/
		public class Changes
		{
			// speed
			public float verticalSpeed = 0;

			public float horizontalSpeed = 0;

			public Vector3 velocity = Vector3.zero;


			// position
			public Vector3 lastPosition;

			public Vector3 positionChange = Vector3.zero;

			public Vector3 lastLocalPosition;

			public Vector3 localPositionChange = Vector3.zero;

			public Vector3 localLastDirection = Vector3.zero;


			// rotation
			public Vector3 lastRotation;

			public Vector3 rotationChange = Vector3.zero;

			public Vector3 lastLocalRotation;

			public Vector3 localRotationChange = Vector3.zero;


			// scale
			public Vector3 lastScale;

			public Vector3 scaleChange = Vector3.zero;

			public Changes()
			{

			}

			public virtual void Start(Transform transform)
			{
				this.lastPosition = transform.position;
				this.lastRotation = transform.eulerAngles;
				this.lastScale = transform.localScale;
			}

			public virtual void Update(Transform transform)
			{
				// update position change
				this.positionChange = transform.position - this.lastPosition;
				this.lastPosition = transform.position;
				this.localPositionChange = transform.localPosition - this.lastLocalPosition;
				this.lastLocalPosition = transform.localPosition;

				// update speed
				if(Time.timeScale <= 0)
				{
					this.verticalSpeed = 0;
					this.horizontalSpeed = 0;
				}
				else
				{
					this.velocity = (transform.parent == null ? this.positionChange : this.localPositionChange) / Time.deltaTime;
					Vector3 tmpVelocity = this.velocity;
					if(tmpVelocity.sqrMagnitude > 0)
					{
						this.localLastDirection = transform.InverseTransformDirection(tmpVelocity.normalized);
					}

					if(HorizontalPlaneType.XZ == Maki.GameSettings.horizontalPlane)
					{
						this.verticalSpeed = tmpVelocity.y;
						tmpVelocity.y = 0;
						this.horizontalSpeed = tmpVelocity.magnitude;
					}
					else
					{
						this.verticalSpeed = tmpVelocity.z;
						tmpVelocity.z = 0;
						this.horizontalSpeed = tmpVelocity.magnitude;
					}
				}

				// update rotation change
				this.rotationChange = transform.eulerAngles - this.lastRotation;
				this.lastRotation = transform.eulerAngles;
				this.localRotationChange = transform.localEulerAngles - this.lastLocalRotation;
				this.lastLocalRotation = transform.localEulerAngles;

				// update scale change
				this.scaleChange = transform.localScale - this.lastScale;
				this.lastScale = transform.localScale;
			}
		}
	}
}
