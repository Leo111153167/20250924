﻿
using UnityEngine;
using System.Collections.Generic;

namespace GamingIsLove.Makinom.Components
{
	[AddComponentMenu("Makinom/Scenes/Game Object Manager")]
	public class GameObjectManager : SerializedBehaviour<GameObjectManager.Settings>
	{
		[TextArea]
		public string notes = "";

		public GameObject[] gameObjects = new GameObject[0];


		// in-game
		protected bool initialized = false;

		protected bool registered = false;

		protected DataCall call;

		protected List<VariableHandler> registeredHandlers;

		protected bool changed = true;

		protected bool lastConditionCheck = false;

		protected bool firstChange = true;

		protected virtual void Start()
		{
			this.initialized = true;
			this.Register();
		}

		protected virtual DataCall Call
		{
			get
			{
				if(this.call == null)
				{
					this.call = new DataCall(this.gameObject);
				}
				return this.call;
			}
		}

		protected virtual void Update()
		{
			if(this.registered &&
				this.changed)
			{
				this.changed = false;
				bool tmp = this.lastConditionCheck;
				this.lastConditionCheck = this.settings.condition.Check(this.Call);

				if(tmp != this.lastConditionCheck ||
					this.firstChange)
				{
					this.firstChange = false;
					for(int i = 0; i < this.gameObjects.Length; i++)
					{
						if(this.gameObjects[i] != null &&
							this.gameObjects[i].activeInHierarchy != this.lastConditionCheck)
						{
							this.gameObjects[i].SetActive(this.lastConditionCheck);
						}
					}
				}
			}
		}

		public virtual void ConditionsChanged()
		{
			this.changed = true;
		}


		/*
		============================================================================
		Register functions
		============================================================================
		*/
		protected virtual void OnEnable()
		{
			this.firstChange = true;
			if(this.initialized)
			{
				this.Register();
			}
		}

		protected virtual void OnDisable()
		{
			if(this.initialized)
			{
				this.Unregister();
			}
		}

		public virtual void Register()
		{
			if(!this.registered)
			{
				this.settings.condition.Register(this.Call, this.ConditionsChanged, ref this.registeredHandlers);
				this.registered = true;
				this.changed = true;
			}
		}

		public virtual void Unregister()
		{
			if(this.registered)
			{
				this.settings.condition.Unregister(this.Call, this.ConditionsChanged, this.registeredHandlers);
				if(this.registeredHandlers != null)
				{
					Maki.Pooling.VariableHandlerLists.Add(this.registeredHandlers);
					this.registeredHandlers = null;
				}
				this.registered = false;
				this.call = null;
			}
		}


		/*
		============================================================================
		Settings class
		============================================================================
		*/
		public class Settings : BaseData
		{
			public GeneralConditionSetting<GameObjectSelection> condition = new GeneralConditionSetting<GameObjectSelection>();

			public Settings()
			{

			}
		}
	}
}
