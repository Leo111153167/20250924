
using UnityEngine;
using GamingIsLove.Makinom;
using System.Collections.Generic;

namespace GamingIsLove.Makinom.Components
{
	[AddComponentMenu("Makinom/Scenes/Camera Event")]
	public class CameraEvent : SerializedBehaviour<CameraEvent.Settings>
	{
		// ingame
		protected bool eventActive = false;

		protected Camera foundCamera;

		protected CameraMoverComponent mover;

		protected List<GameObject> registeredGameObjects = new List<GameObject>();


		// initial position
		protected Vector3 initPos = Vector3.zero;

		protected Quaternion initRot = Quaternion.identity;

		protected float initFoV = 40;


		/*
		============================================================================
		Camera functions
		============================================================================
		*/
		protected virtual Camera GetCamera()
		{
			if(this.foundCamera == null)
			{
				if(this.settings.mainCamera)
				{
					this.foundCamera = Maki.Game.Camera;
				}
				else
				{
					Camera[] cams = Camera.allCameras;
					for(int i = 0; i < cams.Length; i++)
					{
						if((this.settings.cameraTag &&
								cams[i].CompareTag(this.settings.cameraName)) ||
							(!this.settings.cameraTag &&
								cams[i].name == this.settings.cameraName))
						{
							this.foundCamera = cams[i];
							break;
						}
					}
				}
			}
			return this.foundCamera;
		}

		protected virtual void UseCamPos()
		{
			Camera cam = this.GetCamera();

			if(cam != null)
			{
				if(this.settings.onObject)
				{
					if(this.settings.placementObject != null)
					{
						cam.transform.SetPositionAndRotation(
							this.settings.placementObject.transform.position,
							this.settings.placementObject.transform.rotation);
						if(cam.orthographic)
						{
							if(this.settings.setOrthographicSize)
							{
								cam.orthographicSize = this.settings.orthographicSize;
							}
						}
						else if(this.settings.setFoV)
						{
							cam.fieldOfView = this.settings.foV;
						}

						if(this.settings.lookAt &&
							this.registeredGameObjects.Count > 0 &&
							this.registeredGameObjects[0] != null)
						{
							cam.transform.LookAt(this.registeredGameObjects[0].transform);
						}
					}
				}
				else
				{
					if(this.settings.cameraPosition.StoredAsset != null)
					{
						if(this.settings.useEventObject)
						{
							this.settings.cameraPosition.StoredAsset.Settings.Use(cam.transform, this.transform);
						}
						else if(this.registeredGameObjects.Count > 0 &&
							this.registeredGameObjects[0] != null)
						{
							this.settings.cameraPosition.StoredAsset.Settings.Use(cam.transform, this.registeredGameObjects[0].transform);
						}
					}
				}
			}
		}

		protected virtual void Update()
		{
			if(this.eventActive &&
				this.settings.updatePosition &&
				(this.settings.inBlockedControls || !Maki.Control.Blocked))
			{
				this.UseCamPos();
			}
		}

		protected virtual void OnDestroy()
		{
			if(this.eventActive)
			{
				Maki.Control.SetBlockCamera(-1, true);
				this.eventActive = false;
				Maki.Control.RemoveCameraEvent(this);
			}
		}


		/*
		============================================================================
		Event functions
		============================================================================
		*/
		public virtual void StartEvent()
		{
			Maki.Control.SetBlockCamera(1, true);
			this.eventActive = true;

			Camera cam = this.GetCamera();

			if(cam != null)
			{
				if(this.settings.resetPosition)
				{
					this.initPos = cam.transform.position;
					this.initRot = cam.transform.rotation;
					this.initFoV = cam.fieldOfView;
				}

				if(!this.settings.updatePosition)
				{
					if(this.settings.interpolate && this.settings.time > 0)
					{
						this.mover = ComponentHelper.Get<CameraMoverComponent>(this.gameObject);
						if(this.mover != null)
						{
							// object position
							if(this.settings.onObject)
							{
								if(this.settings.placementObject != null)
								{
									this.mover.SetTargetData(
										this.settings.placementObject.transform.position,
										this.settings.placementObject.transform.rotation,
										this.settings.setFoV ? this.settings.foV : cam.fieldOfView,
										this.settings.setOrthographicSize ? this.settings.orthographicSize : cam.orthographicSize,
										cam, this.settings.interpolation, this.settings.time, null, Maki.Game.Paused);
								}
							}
							// camera position
							else
							{
								if(this.settings.cameraPosition.StoredAsset != null)
								{
									if(this.settings.useEventObject)
									{
										this.mover.SetTargetData(this.settings.cameraPosition.StoredAsset,
											cam, this.transform,
											this.settings.interpolation, this.settings.time, null, Maki.Game.Paused);
									}
									else if(this.registeredGameObjects.Count > 0 &&
										this.registeredGameObjects[0] != null)
									{
										this.mover.SetTargetData(this.settings.cameraPosition.StoredAsset,
											cam, this.registeredGameObjects[0].transform,
											this.settings.interpolation, this.settings.time, null, Maki.Game.Paused);
									}
								}
							}
						}
						else
						{
							this.UseCamPos();
						}
					}
					else
					{
						this.UseCamPos();
					}
				}
			}
		}

		public virtual void EndEvent()
		{
			if(this.mover != null)
			{
				this.mover.Stop();
			}

			if(this.settings.resetPosition)
			{
				Camera cam = this.GetCamera();

				if(cam != null)
				{
					cam.transform.SetPositionAndRotation(this.initPos, this.initRot);
					cam.fieldOfView = this.initFoV;
				}
			}

			Maki.Control.SetBlockCamera(-1, true);
			this.eventActive = false;
		}


		/*
		============================================================================
		Trigger functions
		============================================================================
		*/
		protected virtual void OnTriggerEnter(Collider other)
		{
			if(Maki.Game.Player.IsPlayer(other.gameObject) &&
				(this.settings.inBlockedControls || !Maki.Control.Blocked))
			{
				this.registeredGameObjects.Add(other.gameObject);
				if(this.registeredGameObjects.Count == 1)
				{
					Maki.Control.AddCameraEvent(this);
				}
			}
		}

		protected virtual void OnTriggerExit(Collider other)
		{
			if(this.registeredGameObjects.Contains(other.gameObject))
			{
				this.registeredGameObjects.Remove(other.gameObject);
				if(this.registeredGameObjects.Count == 0)
				{
					Maki.Control.RemoveCameraEvent(this);
				}
			}
		}


		/*
		============================================================================
		Trigger2D functions
		============================================================================
		*/
		protected virtual void OnTriggerEnter2D(Collider2D other)
		{
			if(Maki.Game.Player.IsPlayer(other.gameObject) &&
				(this.settings.inBlockedControls || !Maki.Control.Blocked))
			{
				this.registeredGameObjects.Add(other.gameObject);
				if(this.registeredGameObjects.Count == 1)
				{
					Maki.Control.AddCameraEvent(this);
				}
			}
		}

		protected virtual void OnTriggerExit2D(Collider2D other)
		{
			if(this.registeredGameObjects.Contains(other.gameObject))
			{
				this.registeredGameObjects.Remove(other.gameObject);
				if(this.registeredGameObjects.Count == 0)
				{
					Maki.Control.RemoveCameraEvent(this);
				}
			}
		}


		/*
		============================================================================
		Gizmo functions
		============================================================================
		*/
		protected virtual void OnDrawGizmos()
		{
			Gizmos.DrawIcon(transform.position, "/GamingIsLove/Makinom/Components/CameraEvent Icon.png");
		}


		/*
		============================================================================
		Settings class
		============================================================================
		*/
		public class Settings : BaseData
		{
			// camera
			[EditorHelp("Use Main Camera", "Use the main camera of the scene.", "")]
			[EditorTitleLabel("Camera Settings")]
			public bool mainCamera = true;

			[EditorHelp("Find With Tag", "Search for a camera with a defined tag.\n" +
				"If disabled, a camera with a defined name will be searched.", "")]
			[EditorCondition("mainCamera", false)]
			public bool cameraTag = false;

			[EditorHelp("Camera Name", "The name/tag that will be searched for.", "")]
			[EditorEndCondition]
			public string cameraName = "";

			[EditorHelp("In Blocked Control", "Use this camera event while the player control is blocked.")]
			[EditorSeparator]
			public bool inBlockedControls = true;


			// camera placement
			[EditorHelp("On Object", "Place the camera on a defined game object's position and rotation.", "")]
			[EditorSeparator]
			[EditorTitleLabel("Camera Placement")]
			public bool onObject = false;

			[EditorHelp("Placement Object", "The game object used for camera placement.", "")]
			[EditorCondition("onObject", true)]
			[EditorInfo(allowSceneObjects = true)]
			public GameObject placementObject;

			[EditorHelp("Set Field of View", "Set the camera's field of view.\n" +
				"Only used by cameras with 'Perspective' projection.")]
			public bool setFoV = true;

			[EditorHelp("Field of View", "The field of view that will be used.", "")]
			[EditorIndent]
			[EditorCondition("setFoV", true)]
			[EditorEndCondition]
			public float foV = 40;

			[EditorHelp("Set Orthographic Size", "Set the camera's orthographic size.\n" +
				"Only used by cameras with 'Orthographic' projection.")]
			public bool setOrthographicSize = false;

			[EditorHelp("Orthographic Size", "The size of an orthographic camera.", "")]
			[EditorIndent]
			[EditorCondition("setOrthographicSize", true)]
			[EditorEndCondition]
			public float orthographicSize = 5;

			[EditorHelp("Look At", "Look at the player's game object.", "")]
			[EditorDefaultValue(false)]
			public bool lookAt = false;

			// camera position
			[EditorHelp("Camera Position", "Select the camera position that will be used.", "")]
			[EditorElseCondition]
			[EditorAutoInit]
			public AssetSelection<CameraPositionAsset> cameraPosition;

			[EditorHelp("Use Event Object", "Use the camera event's game object for the camera position.\n" +
				"If disabled, the player's game object will be used.", "")]
			[EditorDefaultValue(false)]
			[EditorEndCondition]
			public bool useEventObject = false;

			[EditorHelp("Update Position", "Update the camera position each frame.", "")]
			[EditorCondition("lookAt", true)]
			[EditorCondition("onObject", false)]
			[EditorEndCondition]
			[EditorDefaultValue(false)]
			public bool updatePosition = false;

			[EditorHelp("Reset Position", "Reset the camera to its position, rotation and field of view " +
				"it had before starting this camera event.", "")]
			public bool resetPosition = false;


			// interpolation
			[EditorHelp("Interpolate", "Fade to the new camera position.", "")]
			[EditorSeparator]
			[EditorTitleLabel("Fade Settings")]
			[EditorCondition(new string[] { "lookAt", "updatePosition" },
				new object[] { false, false })]
			[EditorDefaultValue(false)]
			public bool interpolate = false;

			[EditorCondition("interpolate", true)]
			[EditorAutoInit]
			public Interpolation interpolation;

			[EditorHelp("Time (s)", "The time in seconds used for interpolation.", "")]
			[EditorEndCondition(2)]
			[EditorLimit(0.0f)]
			public float time = 1;

			public Settings()
			{

			}
		}
	}
}
