﻿
using UnityEngine;
using GamingIsLove.Makinom;
using System.Collections.Generic;

namespace GamingIsLove.Makinom.Components
{
	[AddComponentMenu("Makinom/Scenes/Follow Waypoint Path")]
	public class FollowWaypointPathComponent : SerializedBehaviour<FollowWaypointPathComponent.Settings>
	{
		protected WaypointPathComponent path;

		protected virtual void Start()
		{
			if(this.settings.pathObject != null)
			{
				this.path = this.settings.pathObject.GetComponentInChildren<WaypointPathComponent>();

				if(this.path != null)
				{
					WaypointPathMover mover = ComponentHelper.Get<WaypointPathMover>(this.gameObject);

					if(mover != null)
					{
						DataCall call = new DataCall(this.gameObject);
						Transform lookAt = null;
						float smooth = 0;
						Vector3 rotation = Vector3.zero;

						if(this.settings.ownRotation)
						{
							if(PathRotationType.None != this.settings.rotationSettings.type)
							{
								smooth = this.settings.smoothRotation.GetValue(call);
							}

							if(PathRotationType.Value == this.settings.rotationSettings.type)
							{
								rotation = this.settings.rotation.GetValue(call);
							}
							else if(PathRotationType.LookAtObject == this.settings.rotationSettings.type)
							{
								GameObject tmp = this.settings.lookAtObject.GetObject(call);
								if(tmp != null)
								{
									lookAt = tmp.transform;
								}
							}
						}

						if(PathFollowType.Time == this.settings.followType)
						{
							mover.FollowTime(this.path, this.settings.componentSettings.CreateInstance(this.gameObject),
								this.settings.startSettings, this.settings.value.GetValue(call),
								this.settings.pointTimeout.GetValue(call), this.settings.gravityType,
								this.settings.ownRotation ? this.settings.rotationSettings : null,
								lookAt, rotation, smooth,
								null, false, null);
						}
						else if(PathFollowType.Speed == this.settings.followType)
						{
							mover.FollowSpeed(this.path, this.settings.componentSettings.CreateInstance(this.gameObject),
								this.settings.startSettings, this.settings.value.GetValue(call),
								this.settings.pointTimeout.GetValue(call), this.settings.gravityType,
								this.settings.ownRotation ? this.settings.rotationSettings : null,
								lookAt, rotation, smooth,
								null, false, null);
						}
					}
				}
			}
		}


		/*
		============================================================================
		Settings class
		============================================================================
		*/
		public class Settings : BaseData
		{
			public MoveComponentSettings componentSettings = new MoveComponentSettings();

			[EditorHelp("Gravity", "Select if gravity will be applied to objects following the path:\n" +
				"- None: No additional gravity will be applied.\n" +
				"- Physics: The current physics gravity will be applied (Physics.gravity).\n" +
				"- Physics 2D: The current 2D physics gravity will be applied (Physics2D.gravity).", "")]
			public GravityType gravityType = GravityType.None;


			// path settings
			[EditorHelp("Path Object", "The game object with the 'Waypoint Path' to follow.", "")]
			[EditorSeparator]
			[EditorTitleLabel("Path Settings")]
			[EditorInfo(allowSceneObjects = true)]
			public GameObject pathObject;

			[EditorHelp("Follow Type", "Select how this game object will follow the path:\n" +
				"- Time: Follows the path in a defined amount of time.\n" +
				"- Speed: Follows the path at a defined speed.", "")]
			public PathFollowType followType = PathFollowType.Time;

			public PathStartSettings startSettings = new PathStartSettings();

			[EditorHelp("Wait", "Wait until the game object finished following the path one time.", "")]
			[EditorCondition("waitBetween", true)]
			[EditorEndCondition]
			public bool wait = false;

			[EditorHelp("Time/Speed", "The value used (depending on 'Follow Type'):\n" +
				"- Time: The time in seconds used to follow the path.\n" +
				"- Speed: The speed in world units per second used to follow the path.", "")]
			[EditorSeparator]
			public FloatValue<GameObjectSelection> value = new FloatValue<GameObjectSelection>();

			[EditorHelp("Path Point Timeout (s)", "The time in seconds the moving object will wait at path points.", "")]
			[EditorSeparator]
			public FloatValue<GameObjectSelection> pointTimeout = new FloatValue<GameObjectSelection>();


			// own rotation
			[EditorHelp("Own Rotation", "Overrides the path or path point rotation settings.", "")]
			[EditorSeparator]
			[EditorTitleLabel("Rotation Settings")]
			public bool ownRotation = false;

			[EditorCondition("ownRotation", true)]
			[EditorAutoInit]
			public PathRotationSettings rotationSettings;

			[EditorSeparator]
			[EditorTitleLabel("Rotation")]
			[EditorCondition("rotationSettings.type", PathRotationType.Value)]
			[EditorEndCondition]
			[EditorAutoInit]
			public Vector3Value<GameObjectSelection> rotation;

			[EditorSeparator]
			[EditorTitleLabel("Look At Object")]
			[EditorCondition("rotationSettings.type", PathRotationType.LookAtObject)]
			[EditorEndCondition]
			[EditorAutoInit]
			public GameObjectSelection lookAtObject;

			[EditorHelp("Smooth Rotation", "The value used for smoothing rotations.\n" +
				"Smoothing rotation changes will be used when the value is above 0.\n" +
				"A higher value means a faster change (e.g. 0.3 is slow, 10 is fast).", "")]
			[EditorSeparator]
			[EditorCondition("rotationSettings.type", PathRotationType.None)]
			[EditorElseCondition]
			[EditorEndCondition(2)]
			[EditorAutoInit]
			public FloatValue<GameObjectSelection> smoothRotation;

			public Settings()
			{

			}
		}
	}
}
