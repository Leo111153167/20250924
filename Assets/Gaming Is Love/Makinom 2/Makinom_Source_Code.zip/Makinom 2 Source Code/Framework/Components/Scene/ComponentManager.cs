﻿
using UnityEngine;
using System.Collections.Generic;

namespace GamingIsLove.Makinom.Components
{
	[AddComponentMenu("Makinom/Scenes/Component Manager")]
	public class ComponentManager : SerializedBehaviour<ComponentManager.Settings>
	{
		[TextArea]
		public string notes = "";

		public Behaviour[] components = new Behaviour[0];

		public Collider[] colliders = new Collider[0];

		public Renderer[] renderers = new Renderer[0];

		public LODGroup[] lodGroups = new LODGroup[0];


		// in-game
		protected bool initialized = false;

		protected bool registered = false;

		protected DataCall call;

		protected List<VariableHandler> registeredHandlers;

		protected bool changed = true;

		protected bool lastConditionCheck = false;

		protected bool firstChange = true;

		protected virtual void Start()
		{
			this.initialized = true;
			this.Register();
		}

		protected virtual DataCall Call
		{
			get
			{
				if(this.call == null)
				{
					this.call = new DataCall(this.gameObject);
				}
				return this.call;
			}
		}

		protected virtual void Update()
		{
			if(this.registered &&
				this.changed)
			{
				this.changed = false;
				bool tmp = this.lastConditionCheck;
				this.lastConditionCheck = this.settings.condition.Check(this.Call);

				if(tmp != this.lastConditionCheck ||
					this.firstChange)
				{
					this.firstChange = false;
					// components
					for(int i = 0; i < this.components.Length; i++)
					{
						if(this.components[i] != null)
						{
							this.components[i].enabled = this.lastConditionCheck;
						}
					}
					// colliders
					for(int i = 0; i < this.colliders.Length; i++)
					{
						if(this.colliders[i] != null)
						{
							this.colliders[i].enabled = this.lastConditionCheck;
						}
					}
					// renderers
					for(int i = 0; i < this.renderers.Length; i++)
					{
						if(this.renderers[i] != null)
						{
							this.renderers[i].enabled = this.lastConditionCheck;
						}
					}
					// LOD groups
					for(int i = 0; i < this.lodGroups.Length; i++)
					{
						if(this.lodGroups[i] != null)
						{
							this.lodGroups[i].enabled = this.lastConditionCheck;
						}
					}
				}
			}
		}

		public virtual void ConditionsChanged()
		{
			this.changed = true;
		}


		/*
		============================================================================
		Register functions
		============================================================================
		*/
		protected virtual void OnEnable()
		{
			this.firstChange = true;
			if(this.initialized)
			{
				this.Register();
			}
		}

		protected virtual void OnDisable()
		{
			if(this.initialized)
			{
				this.Unregister();
			}
		}

		public virtual void Register()
		{
			if(!this.registered)
			{
				this.settings.condition.Register(this.Call, this.ConditionsChanged, ref this.registeredHandlers);
				this.registered = true;
				this.changed = true;
			}
		}

		public virtual void Unregister()
		{
			if(this.registered)
			{
				this.settings.condition.Unregister(this.Call, this.ConditionsChanged, this.registeredHandlers);
				if(this.registeredHandlers != null)
				{
					Maki.Pooling.VariableHandlerLists.Add(this.registeredHandlers);
					this.registeredHandlers = null;
				}
				this.registered = false;
				this.call = null;
			}
		}


		/*
		============================================================================
		Settings class
		============================================================================
		*/
		public class Settings : BaseData
		{
			public GeneralConditionSetting<GameObjectSelection> condition = new GeneralConditionSetting<GameObjectSelection>();

			public Settings()
			{

			}
		}
	}
}
