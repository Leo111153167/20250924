
using System.Collections.Generic;

namespace GamingIsLove.Makinom
{
	public class ContentSorter : BaseData
	{
		public enum Type { None, Name, ID, TypeName, TypeID }

		[EditorHelp("Sort By", "Select how the data will be sorted:\n" +
			"- None: The data isn't sorted and will be listet as it appears.\n" +
			"- Name: The data is sorted by name (e.g. item name, ability name).\n" +
			"- ID: The data is sorted by ID (i.e. the index of the data).\n" +
			"- Type Name: The data is first sorted by type, then by name.\n" +
			"- Type ID: The data is first sorted by type, then by ID.", "")]
		public Type sorting = Type.Name;

		[EditorHelp("Invert Order", "The data is sorted in inverted order.", "")]
		public bool invert = false;

		public ContentSorter()
		{

		}

		public ContentSorter(Type sorting)
		{
			this.sorting = sorting;
		}

		public override string ToString()
		{
			return this.sorting.ToString() + (this.invert ? "(Inverted)" : "");
		}


		/*
		============================================================================
		Sort functions
		============================================================================
		*/
		public void Sort<T>(ref List<T> list) where T : IContent
		{
			if(Type.None == this.sorting)
			{
				if(this.invert)
				{
					list.Reverse();
				}
			}
			else if(Type.Name == this.sorting)
			{
				list.Sort(new NameContentSorter<T>(this.invert));
			}
			else if(Type.ID == this.sorting)
			{
				list.Sort(new IDContentSorter<T>(this.invert));
			}
			else if(Type.TypeName == this.sorting)
			{
				list.Sort(new TypeNameContentSorter<T>(this.invert));
			}
			else if(Type.TypeID == this.sorting)
			{
				list.Sort(new TypeIDContentSorter<T>(this.invert));
			}
		}
	}
}
