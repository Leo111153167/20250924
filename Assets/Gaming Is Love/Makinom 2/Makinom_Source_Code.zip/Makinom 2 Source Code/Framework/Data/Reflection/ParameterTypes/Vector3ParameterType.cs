﻿
using UnityEngine;
using System.Collections.Generic;

namespace GamingIsLove.Makinom.Reflection
{
	[EditorSettingInfo("Vector3", "A Vector3 value.")]
	public class Vector3ParameterType<T> : BaseParameterType<T> where T : IObjectSelection, new()
	{
		[EditorTitleLabel("Vector3 Value")]
		public Vector3Value<T> vector3Value = new Vector3Value<T>();

		public Vector3ParameterType()
		{

		}

		public override string ToString()
		{
			return this.vector3Value.ToString();
		}

		public override bool NeedsCall
		{
			get
			{
				return this.vector3Value.NeedsCall;
			}
		}

		public override System.Type GetParameterType()
		{
			return typeof(Vector3);
		}

		public override object GetParameterValue(IDataCall call)
		{
			return this.vector3Value.GetValue(call);
		}
	}
}
