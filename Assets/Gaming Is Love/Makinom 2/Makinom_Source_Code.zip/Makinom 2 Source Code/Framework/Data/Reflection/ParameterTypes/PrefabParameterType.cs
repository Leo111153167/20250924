﻿
using UnityEngine;
using System.Collections.Generic;

namespace GamingIsLove.Makinom.Reflection
{
	[EditorSettingInfo("Prefab", "A prefab.")]
	public class PrefabParameterType<T> : BaseParameterType<T> where T : IObjectSelection, new()
	{
		[EditorHelp("Prefab", "Select the prefab that will be used as parameter.", "")]
		public AssetSource<GameObject> prefab = new AssetSource<GameObject>();

		public PrefabParameterType()
		{

		}

		public override string ToString()
		{
			return this.prefab.ToString();
		}

		public override System.Type GetParameterType()
		{
			return typeof(GameObject);
		}

		public override object GetParameterValue(IDataCall call)
		{
			return this.prefab.StoredAsset;
		}
	}
}
