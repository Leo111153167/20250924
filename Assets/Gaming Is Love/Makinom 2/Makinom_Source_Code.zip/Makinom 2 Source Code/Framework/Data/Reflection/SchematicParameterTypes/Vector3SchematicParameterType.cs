﻿
using UnityEngine;
using GamingIsLove.Makinom.Schematics;
using System.Collections.Generic;

namespace GamingIsLove.Makinom.Reflection
{
	[EditorSettingInfo("Vector3", "A Vector3 value.")]
	public class Vector3SchematicParameterType : BaseSchematicParameterType
	{
		[EditorTitleLabel("Vector3 Value")]
		public Vector3Value<SchematicObjectSelection> vector3Value = new Vector3Value<SchematicObjectSelection>();

		public Vector3SchematicParameterType()
		{

		}

		public override string ToString()
		{
			return this.vector3Value.ToString();
		}

		public override bool NeedsCall
		{
			get
			{
				return this.vector3Value.NeedsCall;
			}
		}

		public override System.Type GetParameterType()
		{
			return typeof(Vector3);
		}

		public override object GetParameterValue(Schematic schematic)
		{
			return this.vector3Value.GetValue(schematic);
		}
	}
}
