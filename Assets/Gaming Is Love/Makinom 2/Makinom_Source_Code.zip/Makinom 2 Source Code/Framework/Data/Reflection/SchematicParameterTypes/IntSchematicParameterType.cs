﻿
using UnityEngine;
using GamingIsLove.Makinom.Schematics;
using System.Collections.Generic;

namespace GamingIsLove.Makinom.Reflection
{
	[EditorSettingInfo("Int", "An integer value.")]
	public class IntSchematicParameterType : BaseSchematicParameterType
	{
		[EditorHelp("Int Value", "Define the int value that will be used as parameter.", "")]
		public FloatValue<SchematicObjectSelection> floatValue = new FloatValue<SchematicObjectSelection>();

		public IntSchematicParameterType()
		{

		}

		public override string ToString()
		{
			return this.floatValue.ToString();
		}

		public override bool NeedsCall
		{
			get
			{
				return this.floatValue.NeedsCall;
			}
		}

		public override System.Type GetParameterType()
		{
			return typeof(int);
		}

		public override object GetParameterValue(Schematic schematic)
		{
			return (int)this.floatValue.GetValue(schematic);
		}
	}
}
