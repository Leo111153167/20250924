﻿
using UnityEngine;
using GamingIsLove.Makinom.Schematics;
using System.Collections.Generic;

namespace GamingIsLove.Makinom.Reflection
{
	[EditorSettingInfo("Physics Material 2D", "A 2D physics material.")]
	public class PhysicsMaterial2DSchematicParameterType : BaseSchematicParameterType
	{
		[EditorHelp("Physics Material 2D", "Select the 2d physics material that will be used as parameter.", "")]
		public SchematicPhysicsMaterial2DSelection physicMaterial2D = new SchematicPhysicsMaterial2DSelection();

		public PhysicsMaterial2DSchematicParameterType()
		{

		}

		public override string ToString()
		{
			return this.physicMaterial2D.ToString();
		}

		public override System.Type GetParameterType()
		{
			return typeof(PhysicsMaterial2D);
		}

		public override object GetParameterValue(Schematic schematic)
		{
			return this.physicMaterial2D.GetPhysicsMaterial2D(schematic);
		}
	}
}
