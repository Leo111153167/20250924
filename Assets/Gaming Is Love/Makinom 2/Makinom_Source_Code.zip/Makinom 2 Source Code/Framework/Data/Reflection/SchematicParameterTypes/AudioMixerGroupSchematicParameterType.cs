﻿
using UnityEngine;
using GamingIsLove.Makinom.Schematics;
using System.Collections.Generic;
using UnityEngine.Audio;

namespace GamingIsLove.Makinom.Reflection
{
	[EditorSettingInfo("Audio Mixer Group", "An audio mixer group.")]
	public class AudioMixerGroupSchematicParameterType : BaseSchematicParameterType
	{
		[EditorHelp("Audio Mixer Group", "Select the audio mixer group that will be used as parameter.", "")]
		public SchematicAudioMixerGroupSelection audioMixerGroup = new SchematicAudioMixerGroupSelection();

		public AudioMixerGroupSchematicParameterType()
		{

		}

		public override string ToString()
		{
			return this.audioMixerGroup.ToString();
		}

		public override System.Type GetParameterType()
		{
			return typeof(AudioMixerGroup);
		}

		public override object GetParameterValue(Schematic schematic)
		{
			return this.audioMixerGroup.GetAudioMixerGroup(schematic);
		}
	}
}
