﻿
using UnityEngine;
using GamingIsLove.Makinom.Schematics;
using System.Collections.Generic;

namespace GamingIsLove.Makinom.Reflection
{
	[EditorSettingInfo("Float", "A float value.")]
	public class FloatSchematicParameterType : BaseSchematicParameterType
	{
		[EditorHelp("Float Value", "Define the float value that will be used as parameter.", "")]
		public FloatValue<SchematicObjectSelection> floatValue = new FloatValue<SchematicObjectSelection>();

		public FloatSchematicParameterType()
		{

		}

		public override string ToString()
		{
			return this.floatValue.ToString();
		}

		public override bool NeedsCall
		{
			get
			{
				return this.floatValue.NeedsCall;
			}
		}

		public override System.Type GetParameterType()
		{
			return typeof(float);
		}

		public override object GetParameterValue(Schematic schematic)
		{
			return this.floatValue.GetValue(schematic);
		}
	}
}
