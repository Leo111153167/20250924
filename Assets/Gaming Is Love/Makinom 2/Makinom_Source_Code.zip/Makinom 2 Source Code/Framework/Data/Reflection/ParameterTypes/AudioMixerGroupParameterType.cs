﻿
using UnityEngine;
using System.Collections.Generic;
using UnityEngine.Audio;

namespace GamingIsLove.Makinom.Reflection
{
	[EditorSettingInfo("Audio Mixer Group", "An audio mixer group.")]
	public class AudioMixerGroupParameterType<T> : BaseParameterType<T> where T : IObjectSelection, new()
	{
		[EditorHelp("Audio Mixer Group", "Select the audio mixer group that will be used as parameter.", "")]
		public AssetSource<AudioMixerGroup> audioMixerGroup = new AssetSource<AudioMixerGroup>();

		public AudioMixerGroupParameterType()
		{

		}

		public override string ToString()
		{
			return this.audioMixerGroup.ToString();
		}

		public override System.Type GetParameterType()
		{
			return typeof(AudioMixerGroup);
		}

		public override object GetParameterValue(IDataCall call)
		{
			return this.audioMixerGroup.StoredAsset;
		}
	}
}
