
using UnityEngine;
using GamingIsLove.Makinom.Schematics;
using System.Text;

namespace GamingIsLove.Makinom.Reflection
{
	public class SchematicChangeFields : BaseData
	{
		[EditorHelp("Class Name", "The name of the class that contains the fields or properties.", "")]
		[EditorWidth(true)]
		[EditorReflectionField(EditorReflectionFieldType.Class, typeof(Component))]
		public string className = "";


		// fields
		[EditorArray("Add Field", "Adds a field that will be changed.", "",
			"Remove", "Removes this field.", "", isMove=true, isCopy=true,
			foldout=true, foldoutText=new string[] {"Field", "The field's value will be changed.", ""})]
		public SchematicFieldChange[] field = new SchematicFieldChange[0];

		public SchematicChangeFields()
		{

		}

		public void Change(object instance, Schematic schematic, bool isStatic)
		{
			if(this.className != "")
			{
				System.Type instanceType = isStatic ?
					Maki.ReflectionHandler.GetType(this.className) :
					Maki.ReflectionHandler.GetTypeOrInterface(this.className, typeof(Component));

				if(instanceType != null)
				{
					if(!isStatic && instance is GameObject)
					{
						instance = ((GameObject)instance).GetComponent(instanceType);
						if(instance == null)
						{
							Debug.LogWarning("Component not found on game object: " + this.className);
						}
					}

					if(isStatic || instance != null)
					{
						for(int i = 0; i < this.field.Length; i++)
						{
							this.field[i].Change(instance, instanceType, schematic, isStatic);
						}
					}
				}
				else
				{
					Debug.LogWarning("Component type not found: " + this.className);
				}
			}
		}

		public override string ToString()
		{
			if(this.field.Length > 0)
			{
				StringBuilder builder = new StringBuilder(this.className).Append(": ");
				for(int i = 0; i < this.field.Length; i++)
				{
					if(i > 0)
					{
						builder.Append(", ");
					}
					builder.Append(this.field[i].ToString());
				}
				return builder.ToString();
			}
			return "";
		}
	}
}
