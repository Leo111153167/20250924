﻿
using UnityEngine;
using System.Reflection;

namespace GamingIsLove.Makinom.Reflection
{
	public class ColorField : BaseData
	{
		[EditorHelp("Class Name", "The name of the class that contains the color field/property.", "")]
		[EditorWidth(true)]
		[EditorReflectionField(EditorReflectionFieldType.Class, typeof(Component))]
		public string className = "";

		[EditorHelp("Field Name", "The name of the color field/property that will be used.", "")]
		[EditorWidth(true)]
		[EditorReflectionField(EditorReflectionFieldType.Field, typeof(Component), "className", 
			propertyFieldName="isProperty", fieldType=typeof(Color))]
		public string fieldName = "";

		[EditorHelp("Is Property", "Uses a property.\n" +
			"If disabled, a field will be used.", "")]
		public bool isProperty = false;

		public ColorField()
		{

		}

		public bool GetColor(object instance, ref Color color)
		{
			if(instance != null)
			{
				System.Type instanceType = instance.GetType();

				if(this.fieldName != "")
				{
					if(this.isProperty)
					{
						PropertyInfo propertyInfo = Maki.ReflectionHandler.GetProperty(
							this.fieldName, ref instance, ref instanceType);
						if(propertyInfo != null)
						{
							try
							{
								if(propertyInfo.PropertyType == typeof(Color))
								{
									color = (Color)propertyInfo.GetValue(instance, null);
									return true;
								}
							}
							catch(System.Exception ex)
							{
								Debug.LogWarning("Getting property value failed (" + instanceType + "): " +
									this.fieldName + "\n" + ex.Message + "\n" + ex.StackTrace);
							}
						}
						else
						{
							Debug.LogWarning("Property not found (" + instanceType + "): " + this.fieldName);
						}
					}
					else
					{
						FieldInfo fieldInfo = Maki.ReflectionHandler.GetField(
							this.fieldName, ref instance, ref instanceType);
						if(fieldInfo != null)
						{
							try
							{
								if(fieldInfo.FieldType == typeof(Color))
								{
									color = (Color)fieldInfo.GetValue(instance);
									return true;
								}
							}
							catch(System.Exception ex)
							{
								Debug.LogWarning("Getting field value failed (" + instanceType + "): " +
									this.fieldName + "\n" + ex.Message + "\n" + ex.StackTrace);
							}
						}
						else
						{
							Debug.LogWarning("Field not found (" + instanceType + "): " + this.fieldName);
						}
					}
				}
			}
			return false;
		}

		public bool GetColor(GameObject gameObject, bool isStatic, ref Color color)
		{
			if(this.className != "")
			{
				System.Type instanceType = isStatic ?
					Maki.ReflectionHandler.GetType(this.className) :
					Maki.ReflectionHandler.GetTypeOrInterface(this.className, typeof(Component));

				if(instanceType != null)
				{
					System.Object instance = isStatic ? null : gameObject.GetComponent(instanceType);
					if(!isStatic && instance == null)
					{
						Debug.LogWarning("Component not found on game object: " + this.className);
					}

					if(isStatic || instance != null)
					{
						if(this.fieldName != "")
						{
							if(this.isProperty)
							{
								PropertyInfo propertyInfo = Maki.ReflectionHandler.GetProperty(
									this.fieldName, ref instance, ref instanceType);
								if(propertyInfo != null)
								{
									try
									{
										if(propertyInfo.PropertyType == typeof(Color))
										{
											color = (Color)propertyInfo.GetValue(isStatic ? null : instance, null);
											return true;
										}
									}
									catch(System.Exception ex)
									{
										Debug.LogWarning("Getting property value failed (" + instanceType + "): " +
											this.fieldName + "\n" + ex.Message + "\n" + ex.StackTrace);
									}
								}
								else
								{
									Debug.LogWarning("Property not found (" + instanceType + "): " + this.fieldName);
								}
							}
							else
							{
								FieldInfo fieldInfo = Maki.ReflectionHandler.GetField(
									this.fieldName, ref instance, ref instanceType);
								if(fieldInfo != null)
								{
									try
									{
										if(fieldInfo.FieldType == typeof(Color))
										{
											color = (Color)fieldInfo.GetValue(isStatic ? null : instance);
											return true;
										}
									}
									catch(System.Exception ex)
									{
										Debug.LogWarning("Getting field value failed (" + instanceType + "): " +
											this.fieldName + "\n" + ex.Message + "\n" + ex.StackTrace);
									}
								}
								else
								{
									Debug.LogWarning("Field not found (" + instanceType + "): " + this.fieldName);
								}
							}
						}
					}
				}
				else
				{
					Debug.LogWarning("Component type not found: " + this.className);
				}
			}
			return false;
		}

		public void SetColor(object instance, Color color)
		{
			if(instance != null)
			{
				System.Type instanceType = instance.GetType();

				if(this.fieldName != "")
				{
					if(this.isProperty)
					{
						PropertyInfo propertyInfo = Maki.ReflectionHandler.GetProperty(
							this.fieldName, ref instance, ref instanceType);
						if(propertyInfo != null)
						{
							try
							{
								if(propertyInfo.PropertyType == typeof(Color))
								{
									propertyInfo.SetValue(instance, color, null);
								}
							}
							catch(System.Exception ex)
							{
								Debug.LogWarning("Property change failed (" + instanceType + "): " +
									this.fieldName + "\n" + ex.Message + "\n" + ex.StackTrace);
							}
						}
						else
						{
							Debug.LogWarning("Property not found (" + instanceType + "): " + this.fieldName);
						}
					}
					else
					{
						FieldInfo fieldInfo = Maki.ReflectionHandler.GetField(
							this.fieldName, ref instance, ref instanceType);
						if(fieldInfo != null)
						{
							try
							{
								if(fieldInfo.FieldType == typeof(Color))
								{
									fieldInfo.SetValue(instance, color);
								}
							}
							catch(System.Exception ex)
							{
								Debug.LogWarning("Field change failed (" + instanceType + "): " +
									this.fieldName + "\n" + ex.Message + "\n" + ex.StackTrace);
							}
						}
						else
						{
							Debug.LogWarning("Field not found (" + instanceType + "): " + this.fieldName);
						}
					}
				}
			}
		}

		public void SetColor(GameObject gameObject, bool isStatic, Color color)
		{
			if(this.className != "")
			{
				System.Type instanceType = isStatic ?
					Maki.ReflectionHandler.GetType(this.className) :
					Maki.ReflectionHandler.GetTypeOrInterface(this.className, typeof(Component));

				if(instanceType != null)
				{
					System.Object instance = isStatic ? null : gameObject.GetComponent(instanceType);
					if(!isStatic && instance == null)
					{
						Debug.LogWarning("Component not found on game object: " + this.className);
					}

					if(isStatic || instance != null)
					{
						if(this.fieldName != "")
						{
							if(this.isProperty)
							{
								PropertyInfo propertyInfo = Maki.ReflectionHandler.GetProperty(
									this.fieldName, ref instance, ref instanceType);
								if(propertyInfo != null)
								{
									try
									{
										if(propertyInfo.PropertyType == typeof(Color))
										{
											propertyInfo.SetValue(isStatic ? null : instance, color, null);
										}
									}
									catch(System.Exception ex)
									{
										Debug.LogWarning("Property change failed (" + instanceType + "): " +
											this.fieldName + "\n" + ex.Message + "\n" + ex.StackTrace);
									}
								}
								else
								{
									Debug.LogWarning("Property not found (" + instanceType + "): " + this.fieldName);
								}
							}
							else
							{
								FieldInfo fieldInfo = Maki.ReflectionHandler.GetField(
									this.fieldName, ref instance, ref instanceType);
								if(fieldInfo != null)
								{
									try
									{
										if(fieldInfo.FieldType == typeof(Color))
										{
											fieldInfo.SetValue(isStatic ? null : instance, color);
										}
									}
									catch(System.Exception ex)
									{
										Debug.LogWarning("Field change failed (" + instanceType + "): " +
											this.fieldName + "\n" + ex.Message + "\n" + ex.StackTrace);
									}
								}
								else
								{
									Debug.LogWarning("Field not found (" + instanceType + "): " + this.fieldName);
								}
							}
						}
					}
				}
				else
				{
					Debug.LogWarning("Component type not found: " + this.className);
				}
			}
		}
	}
}
