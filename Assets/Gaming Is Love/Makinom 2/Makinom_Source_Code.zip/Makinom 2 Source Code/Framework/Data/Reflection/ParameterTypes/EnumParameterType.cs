﻿
using UnityEngine;
using System.Collections.Generic;

namespace GamingIsLove.Makinom.Reflection
{
	[EditorSettingInfo("Enum", "An enumeration value.")]
	public class EnumParameterType<T> : BaseParameterType<T> where T : IObjectSelection, new()
	{
		[EditorHelp("Enum Name", "The name of the enumeration.\n" +
			"An int value will be used as the enum value.", "")]
		[EditorWidth(true)]
		[EditorReflectionField(EditorReflectionFieldType.Enum)]
		public string enumName = "";

		[EditorHelp("Int Value", "Define the int value that will be used as parameter (converted to enum).", "")]
		public FloatValue<T> floatValue = new FloatValue<T>();

		public EnumParameterType()
		{

		}

		public override string ToString()
		{
			return this.enumName + " " + this.floatValue.ToString();
		}

		public override bool NeedsCall
		{
			get
			{
				return this.floatValue.NeedsCall;
			}
		}

		public override System.Type GetParameterType()
		{
			return ReflectionTypeHandler.Instance.GetEnumType(this.enumName);
		}

		public override object GetParameterValue(IDataCall call)
		{
			return (int)this.floatValue.GetValue(call);
		}
	}
}
