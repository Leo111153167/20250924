﻿
using UnityEngine;
using System.Collections.Generic;

namespace GamingIsLove.Makinom.Reflection
{
	[EditorSettingInfo("Bool", "A bool value.")]
	public class BoolParameterType<T> : BaseParameterType<T> where T : IObjectSelection, new()
	{
		[EditorTitleLabel("Bool Value")]
		public BoolValue<T> boolValue = new BoolValue<T>();

		public BoolParameterType()
		{

		}

		public override string ToString()
		{
			return this.boolValue.ToString();
		}

		public override bool NeedsCall
		{
			get
			{
				return this.boolValue.NeedsCall;
			}
		}

		public override System.Type GetParameterType()
		{
			return typeof(bool);
		}

		public override object GetParameterValue(IDataCall call)
		{
			return this.boolValue.GetValue(call);
		}
	}
}
