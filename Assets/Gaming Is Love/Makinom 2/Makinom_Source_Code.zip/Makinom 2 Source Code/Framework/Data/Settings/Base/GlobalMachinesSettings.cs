
using UnityEngine;
using System.Collections.Generic;

namespace GamingIsLove.Makinom
{
	public class GlobalMachinesSettings : GenericAssetListSettings<GlobalMachineAsset, GlobalMachine>
	{
		// ingame
		private List<GlobalMachine> globalMachine = new List<GlobalMachine>();

		private List<GlobalMachine> globalMachineScene = new List<GlobalMachine>();

		public GlobalMachinesSettings(MakinomProjectAsset project)
		{
			this.LoadProject(project);
			this.CreateGUIDLookup();
		}


		/*
		============================================================================
		Properties
		============================================================================
		*/
		public override string Filename
		{
			get { return "Global Machines"; }
		}


		/*
		============================================================================
		Ingame functions
		============================================================================
		*/
		public void ClearGlobalMachines()
		{
			this.globalMachine.Clear();
			this.globalMachineScene.Clear();
		}

		public void InitGlobalMachines()
		{
			this.ClearGlobalMachines();

			for(int i = 0; i < this.assets.Count; i++)
			{
				if(this.assets[i] != null)
				{
					// auto/key machines
					if(this.assets[i].Settings.IsAutoType() ||
						this.assets[i].Settings.IsKeyType())
					{
						this.globalMachine.Add(this.assets[i].Settings);
					}
					// scene machines
					else if(this.assets[i].Settings.IsSceneType())
					{
						this.globalMachineScene.Add(this.assets[i].Settings);
					}
				}
			}
		}

		public void SceneChangeMachines(bool inOldScene, bool beforeFade,
			GlobalMachineSceneChangeType loadType, string customType)
		{
			for(int i = 0; i < this.globalMachineScene.Count; i++)
			{
				if(this.globalMachineScene[i].inOldScene == inOldScene &&
					this.globalMachineScene[i].beforeFade == beforeFade &&
					(GlobalMachineSceneChangeType.All == this.globalMachineScene[i].sceneChangeType ||
						(this.globalMachineScene[i].sceneChangeType == loadType &&
							(GlobalMachineSceneChangeType.Custom != loadType ||
								this.globalMachineScene[i].customSceneChangeType == customType))) &&
					this.globalMachineScene[i].gameState.Check() &&
					this.globalMachineScene[i].variables.CheckVariables(
						new DataCall(this.globalMachineScene[i].inputID.GetInputID(
							Maki.Game.Player.GameObject,
							Maki.Game.Player.GameObject))))
				{
					this.globalMachineScene[i].Call(Maki.Game.Player.GameObject,
						Maki.Game.Player.GameObject, null);
				}
			}
		}

		public void Tick()
		{
			// auto global machines
			for(int i = 0; i < this.globalMachine.Count; i++)
			{
				this.globalMachine[i].Tick();
			}
		}

		public void StopAll()
		{
			for(int i = 0; i < this.assets.Count; i++)
			{
				this.assets[i].Settings.Stop();
			}
		}
	}
}
