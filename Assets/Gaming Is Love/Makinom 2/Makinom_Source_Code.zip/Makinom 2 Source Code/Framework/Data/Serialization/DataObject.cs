
using GamingIsLove.Makinom.IO;
using UnityEngine;
using UnityEngine.Audio;
using System.Collections.Generic;
using System.Text;
using System.Reflection;

namespace GamingIsLove.Makinom
{
	public delegate void LoadDataFromDataObject(DataObject data, object instance);

	/// <summary>
	/// Used to handle data from IBaseData objects for data serialization.
	/// Supported types:
	/// - int, float, bool, string
	/// - int[], float[], bool[], string[]
	/// - enum is used as int
	/// - enum[] is used as int[]
	/// - Vector2, Vector2[], Vector3, Vector3[], Vector4, Vector4[], Rect, Rect[] are used as float[].
	/// </summary>
	public sealed class DataObject
	{
		// base data types
		private Dictionary<string, int> intData;

		private Dictionary<string, float> floatData;

		private Dictionary<string, bool> boolData;

		private Dictionary<string, string> stringData;


		// array base data types
		private Dictionary<string, int[]> intArrayData;

		private Dictionary<string, float[]> floatArrayData;

		private Dictionary<string, bool[]> boolArrayData;

		private Dictionary<string, string[]> stringArrayData;


		// sub data files
		private Dictionary<string, DataObject> subData;

		private Dictionary<string, DataObject[]> subArrayData;


		// assets
		private Dictionary<string, UnityEngine.Object> generalAssetData;


		/// <summary>
		/// Initializes a new instance of a <see cref="GamingIsLove.Makinom.DataObject"/>.
		/// </summary>
		public DataObject()
		{

		}

		/// <summary>
		/// Initializes a new instance of a <see cref="GamingIsLove.Makinom.DataObject"/>, loading byte array data from a <see cref="GamingIsLove.Makinom.DataFile"/>.
		/// </summary>
		/// <param name="byteData">The byte array data</param>
		/// <param name="decrypt"><c>true</c> if the data is encrypted</param>
		/// <param name="file">The data file the data is coming from (used for loading asset references).</param>
		public DataObject(byte[] byteData, bool decrypt, DataFile file)
		{
			this.ReadData(new FastByteDataReader(byteData, decrypt), file);
		}


		/*
		============================================================================
		Contains functions
		============================================================================
		*/
		/// <summary>
		/// Determines if the data object contains the specified key for a data type.
		/// </summary>
		/// <returns>
		/// <c>true</c> if the data object contains the key; otherwise <c>false</c>.
		/// </returns>
		/// <param name='key'>
		/// The key.
		/// </param>
		/// <typeparam name='T'>
		/// The data type used.
		/// Supported types: int, float, bool, string, <see cref="GamingIsLove.Makinom.DataObject"/>.
		/// </typeparam>
		public bool Contains<T>(string key)
		{
			if(typeof(T).IsEnum)
			{
				return this.Contains<int>(key);
			}
			else
			{
				Dictionary<string, T> data = this.GetData<T>(typeof(T));
				if(data != null)
				{
					return data.ContainsKey(key);
				}
				return false;
			}
		}

		/// <summary>
		/// Determines if the data object contains the specified key for an array of a a data type.
		/// </summary>
		/// <returns>
		/// <c>true</c> if the data object contains the key; otherwise <c>false</c>.
		/// </returns>
		/// <param name='key'>
		/// The key.
		/// </param>
		/// <typeparam name='T'>
		/// The data type used.
		/// Supported types: int, float, bool, string, <see cref="GamingIsLove.Makinom.DataObject"/>.
		/// </typeparam>
		public bool ContainsArray<T>(string key)
		{
			Dictionary<string, T[]> data = this.GetArrayData<T>(typeof(T));
			if(data != null)
			{
				return data.ContainsKey(key);
			}
			return false;
		}

		public object Get(string key)
		{
			// base types
			if(this.intData != null &&
				this.intData.ContainsKey(key))
			{
				return this.intData[key];
			}
			else if(this.floatData != null &&
				this.floatData.ContainsKey(key))
			{
				return this.floatData[key];
			}
			else if(this.boolData != null &&
				this.boolData.ContainsKey(key))
			{
				return this.boolData[key];
			}
			else if(this.stringData != null &&
				this.stringData.ContainsKey(key))
			{
				return this.stringData[key];
			}
			// sub data
			else if(this.subData != null &&
				this.subData.ContainsKey(key))
			{
				return this.subData[key];
			}
			// assets
			else if(this.generalAssetData != null &&
				this.generalAssetData.ContainsKey(key))
			{
				return this.generalAssetData[key];
			}
			// arrays
			// base types
			else if(this.intArrayData != null &&
				this.intArrayData.ContainsKey(key))
			{
				return this.intArrayData[key];
			}
			else if(this.floatArrayData != null &&
				this.floatArrayData.ContainsKey(key))
			{
				return this.floatArrayData[key];
			}
			else if(this.boolArrayData != null &&
				this.boolArrayData.ContainsKey(key))
			{
				return this.boolArrayData[key];
			}
			else if(this.stringArrayData != null &&
				this.stringArrayData.ContainsKey(key))
			{
				return this.stringArrayData[key];
			}
			// sub data
			else if(this.subArrayData != null &&
				this.subArrayData.ContainsKey(key))
			{
				return this.subArrayData[key];
			}
			return null;
		}


		/*
		============================================================================
		Remove functions
		============================================================================
		*/
		/// <summary>
		/// Removes content of a specified key for a data type.
		/// </summary>
		/// <returns>
		/// <c>true</c> if the content was removed; otherwise <c>false</c>.
		/// </returns>
		/// <param name='key'>
		/// The key.
		/// </param>
		/// <typeparam name='T'>
		/// The data type used.
		/// Supported types: int, float, bool, string, <see cref="GamingIsLove.Makinom.DataObject"/>.
		/// </typeparam>
		public bool Remove<T>(string key)
		{
			if(typeof(T).IsEnum)
			{
				return this.Remove<int>(key);
			}
			else
			{
				Dictionary<string, T> data = this.GetData<T>(typeof(T));
				if(data != null)
				{
					return data.Remove(key);
				}
				return false;
			}
		}

		/// <summary>
		/// Removes content of a specified key for an array of a a data type.
		/// </summary>
		/// <returns>
		/// <c>true</c> if the content was removed; otherwise <c>false</c>.
		/// </returns>
		/// <param name='key'>
		/// The key.
		/// </param>
		/// <typeparam name='T'>
		/// The data type used.
		/// Supported types: int, float, bool, string, <see cref="GamingIsLove.Makinom.DataObject"/>.
		/// </typeparam>
		public bool RemoveArray<T>(string key)
		{
			Dictionary<string, T[]> data = this.GetArrayData<T>(typeof(T));
			if(data != null)
			{
				return data.Remove(key);
			}
			return false;
		}


		/*
		============================================================================
		Get/Set generic
		============================================================================
		*/
		/// <summary>
		/// Assign a value to a key.
		/// Enum types are converted to integers.
		/// </summary>
		/// <param name='key'>
		/// The key the value will be assigned to.
		/// </param>
		/// <param name='value'>
		/// The value that will be assigned.
		/// </param>
		/// <typeparam name='T'>
		/// The data type used.
		/// Supported types: int, float, bool, string, <see cref="GamingIsLove.Makinom.DataObject"/>.
		/// </typeparam>
		public void Set<T>(string key, T value)
		{
			if(typeof(T).IsEnum)
			{
				this.SetIntConversion(key, value);
			}
			else
			{
				Dictionary<string, T> data = this.GetDataInstantiate<T>(typeof(T));
				if(data != null)
				{
					data[key] = value;
				}
			}
		}

		private void SetIntConversion<T>(string key, T value)
		{
			this.Set(key, System.Convert.ToInt32(value));
		}

		public void Set(string key, int value)
		{
			if(this.intData == null)
			{
				this.intData = new Dictionary<string, int>();
			}
			this.intData.Add(key, value);
		}

		public void Set(string key, float value)
		{
			if(this.floatData == null)
			{
				this.floatData = new Dictionary<string, float>();
			}
			this.floatData.Add(key, value);
		}

		public void Set(string key, bool value)
		{
			if(this.boolData == null)
			{
				this.boolData = new Dictionary<string, bool>();
			}
			this.boolData.Add(key, value);
		}

		public void Set(string key, string value)
		{
			if(this.stringData == null)
			{
				this.stringData = new Dictionary<string, string>();
			}
			this.stringData.Add(key, value);
		}

		public void Set(string key, DataObject value)
		{
			if(this.subData == null)
			{
				this.subData = new Dictionary<string, DataObject>();
			}
			this.subData.Add(key, value);
		}

		public void SetAsset(string key, UnityEngine.Object value)
		{
			if(this.generalAssetData == null)
			{
				this.generalAssetData = new Dictionary<string, UnityEngine.Object>();
			}
			this.generalAssetData.Add(key, value);
		}

		public void SetEnum<T>(string key, T value)
		{
			this.Set(key, System.Convert.ToInt32(value));
		}

		public void Set(string key, Vector2 value)
		{
			if(this.floatArrayData == null)
			{
				this.floatArrayData = new Dictionary<string, float[]>();
			}
			this.floatArrayData.Add(key, ArrayHelper.ToArray(value));
		}

		public void Set(string key, Vector3 value)
		{
			if(this.floatArrayData == null)
			{
				this.floatArrayData = new Dictionary<string, float[]>();
			}
			this.floatArrayData.Add(key, ArrayHelper.ToArray(value));
		}

		public void Set(string key, Vector4 value)
		{
			if(this.floatArrayData == null)
			{
				this.floatArrayData = new Dictionary<string, float[]>();
			}
			this.floatArrayData.Add(key, ArrayHelper.ToArray(value));
		}

		public void Set(string key, Rect value)
		{
			if(this.floatArrayData == null)
			{
				this.floatArrayData = new Dictionary<string, float[]>();
			}
			this.floatArrayData.Add(key, ArrayHelper.ToArray(value));
		}

		public void Set(string key, Color value)
		{
			if(this.floatArrayData == null)
			{
				this.floatArrayData = new Dictionary<string, float[]>();
			}
			this.floatArrayData.Add(key, ArrayHelper.ToArray(value));
		}

		public void Set(string key, AnimationCurve value)
		{
			if(this.floatArrayData == null)
			{
				this.floatArrayData = new Dictionary<string, float[]>();
			}
			this.floatArrayData.Add(key, ArrayHelper.ToArray(value));
		}

		/// <summary>
		/// Get the value assigned to a key.
		/// </summary>
		/// <param name='key'>
		/// The key to look for.
		/// </param>
		/// <param name='value'>
		/// The reference to the variable holding the value.
		/// If the key is found the value is stored in this variable.
		/// </param>
		/// <typeparam name='T'>
		/// The data type used.
		/// Supported types: int, float, bool, string, <see cref="GamingIsLove.Makinom.DataObject"/>.
		/// </typeparam>
		public bool Get<T>(string key, ref T value)
		{
			if(typeof(T).IsEnum)
			{
				return this.GetIntConversion(key, ref value);
			}
			else
			{
				Dictionary<string, T> data = this.GetData<T>(typeof(T));
				if(data != null)
				{
					T tmpValue;
					if(data.TryGetValue(key, out tmpValue))
					{
						value = tmpValue;
						return true;
					}
				}
			}
			return false;
		}

		private bool GetIntConversion<T>(string key, ref T value)
		{
			int i = System.Convert.ToInt32(value);
			if(this.Get(key, ref i))
			{
				value = (T)(object)i;
				return true;
			}
			return false;
		}

		public bool Get(string key, ref int value)
		{
			if(this.intData != null)
			{
				int tmp;
				if(this.intData.TryGetValue(key, out tmp))
				{
					value = tmp;
					return true;
				}
			}
			return false;
		}

		public void LoadInt(FieldInfo field, object instance)
		{
			if(this.intData != null)
			{
				int tmp;
				if(this.intData.TryGetValue(field.Name, out tmp))
				{
					field.SetValue(instance, tmp);
				}
			}
		}

		public bool Get(string key, ref float value)
		{
			if(this.floatData != null)
			{
				float tmp;
				if(this.floatData.TryGetValue(key, out tmp))
				{
					value = tmp;
					return true;
				}
			}
			return false;
		}

		public void LoadFloat(FieldInfo field, object instance)
		{
			if(this.floatData != null)
			{
				float tmp;
				if(this.floatData.TryGetValue(field.Name, out tmp))
				{
					field.SetValue(instance, tmp);
				}
			}
		}

		public bool Get(string key, ref bool value)
		{
			if(this.boolData != null)
			{
				bool tmp;
				if(this.boolData.TryGetValue(key, out tmp))
				{
					value = tmp;
					return true;
				}
			}
			return false;
		}

		public void LoadBool(FieldInfo field, object instance)
		{
			if(this.boolData != null)
			{
				bool tmp;
				if(this.boolData.TryGetValue(field.Name, out tmp))
				{
					field.SetValue(instance, tmp);
				}
			}
		}

		public bool Get(string key, ref string value)
		{
			if(this.stringData != null)
			{
				string tmp;
				if(this.stringData.TryGetValue(key, out tmp))
				{
					value = tmp;
					return true;
				}
			}
			return false;
		}

		public void LoadString(FieldInfo field, object instance)
		{
			if(this.stringData != null)
			{
				string tmp;
				if(this.stringData.TryGetValue(field.Name, out tmp))
				{
					field.SetValue(instance, tmp);
				}
			}
		}

		public bool Get(string key, ref DataObject value)
		{
			if(this.subData != null)
			{
				DataObject tmp;
				if(this.subData.TryGetValue(key, out tmp))
				{
					value = tmp;
					return true;
				}
			}
			return false;
		}

		public bool GetAsset(string key, ref UnityEngine.Object value)
		{
			if(this.generalAssetData != null)
			{
				UnityEngine.Object tmp;
				if(this.generalAssetData.TryGetValue(key, out tmp))
				{
					value = tmp;
					return true;
				}
			}
			return false;
		}

		public void LoadAsset(FieldInfo field, object instance)
		{
			if(this.generalAssetData != null)
			{
				UnityEngine.Object tmp;
				if(this.generalAssetData.TryGetValue(field.Name, out tmp))
				{
					field.SetValue(instance, tmp);
				}
			}
		}

		public bool GetEnum<T>(string key, ref T value)
		{
			int i = System.Convert.ToInt32(value);
			if(this.Get(key, ref i))
			{
				value = (T)(object)i;
				return true;
			}
			return false;
		}

		public bool Get(string key, ref Vector2 value)
		{
			if(this.floatArrayData != null)
			{
				float[] tmp;
				if(this.floatArrayData.TryGetValue(key, out tmp))
				{
					value = ArrayHelper.GetVector2(tmp);
					return true;
				}
			}
			return false;
		}

		public void LoadVector2(FieldInfo field, object instance)
		{
			if(this.floatArrayData != null)
			{
				float[] tmp;
				if(this.floatArrayData.TryGetValue(field.Name, out tmp))
				{
					field.SetValue(instance, ArrayHelper.GetVector2(tmp));
				}
			}
		}

		public bool Get(string key, ref Vector3 value)
		{
			if(this.floatArrayData != null)
			{
				float[] tmp;
				if(this.floatArrayData.TryGetValue(key, out tmp))
				{
					value = ArrayHelper.GetVector3(tmp);
					return true;
				}
			}
			return false;
		}

		public void LoadVector3(FieldInfo field, object instance)
		{
			if(this.floatArrayData != null)
			{
				float[] tmp;
				if(this.floatArrayData.TryGetValue(field.Name, out tmp))
				{
					field.SetValue(instance, ArrayHelper.GetVector3(tmp));
				}
			}
		}

		public bool Get(string key, ref Vector4 value)
		{
			if(this.floatArrayData != null)
			{
				float[] tmp;
				if(this.floatArrayData.TryGetValue(key, out tmp))
				{
					value = ArrayHelper.GetVector4(tmp);
					return true;
				}
			}
			return false;
		}

		public void LoadVector4(FieldInfo field, object instance)
		{
			if(this.floatArrayData != null)
			{
				float[] tmp;
				if(this.floatArrayData.TryGetValue(field.Name, out tmp))
				{
					field.SetValue(instance, ArrayHelper.GetVector4(tmp));
				}
			}
		}

		public bool Get(string key, ref Rect value)
		{
			if(this.floatArrayData != null)
			{
				float[] tmp;
				if(this.floatArrayData.TryGetValue(key, out tmp))
				{
					value = ArrayHelper.GetRect(tmp);
					return true;
				}
			}
			return false;
		}

		public void LoadRect(FieldInfo field, object instance)
		{
			if(this.floatArrayData != null)
			{
				float[] tmp;
				if(this.floatArrayData.TryGetValue(field.Name, out tmp))
				{
					field.SetValue(instance, ArrayHelper.GetRect(tmp));
				}
			}
		}

		public bool Get(string key, ref Color value)
		{
			if(this.floatArrayData != null)
			{
				float[] tmp;
				if(this.floatArrayData.TryGetValue(key, out tmp))
				{
					value = ArrayHelper.GetColor(tmp);
					return true;
				}
			}
			return false;
		}

		public void LoadColor(FieldInfo field, object instance)
		{
			if(this.floatArrayData != null)
			{
				float[] tmp;
				if(this.floatArrayData.TryGetValue(field.Name, out tmp))
				{
					field.SetValue(instance, ArrayHelper.GetColor(tmp));
				}
			}
		}

		public bool Get(string key, ref AnimationCurve value)
		{
			if(this.floatArrayData != null)
			{
				float[] tmp;
				if(this.floatArrayData.TryGetValue(key, out tmp))
				{
					value = ArrayHelper.GetAnimationCurve(tmp);
					return true;
				}
			}
			return false;
		}

		public void LoadAnimationCurve(FieldInfo field, object instance)
		{
			if(this.floatArrayData != null)
			{
				float[] tmp;
				if(this.floatArrayData.TryGetValue(field.Name, out tmp))
				{
					field.SetValue(instance, ArrayHelper.GetAnimationCurve(tmp));
				}
			}
		}

		private Dictionary<string, T> GetDataInstantiate<T>(System.Type type)
		{
			// base types
			if(typeof(int).Equals(type))
			{
				if(this.intData == null)
				{
					this.intData = new Dictionary<string, int>();
				}
				return this.intData as Dictionary<string, T>;
			}
			else if(typeof(float).Equals(type))
			{
				if(this.floatData == null)
				{
					this.floatData = new Dictionary<string, float>();
				}
				return this.floatData as Dictionary<string, T>;
			}
			else if(typeof(bool).Equals(type))
			{
				if(this.boolData == null)
				{
					this.boolData = new Dictionary<string, bool>();
				}
				return this.boolData as Dictionary<string, T>;
			}
			else if(typeof(string).Equals(type))
			{
				if(this.stringData == null)
				{
					this.stringData = new Dictionary<string, string>();
				}
				return this.stringData as Dictionary<string, T>;
			}
			// sub data
			else if(typeof(DataObject).Equals(type))
			{
				if(this.subData == null)
				{
					this.subData = new Dictionary<string, DataObject>();
				}
				return this.subData as Dictionary<string, T>;
			}
			// assets
			else if(typeof(UnityEngine.Object).Equals(type))
			{
				if(this.generalAssetData == null)
				{
					this.generalAssetData = new Dictionary<string, UnityEngine.Object>();
				}
				return this.generalAssetData as Dictionary<string, T>;
			}
			// not found
			else
			{
				return null;
			}
		}

		/// <summary>
		/// Gets a list containing keys and values of a type.
		/// </summary>
		/// <returns>
		/// A Dictionary<string, T> containing keys (string) and values (T).
		/// </returns>
		/// <param name='type'>
		/// The data type (System.Type).
		/// </param>
		/// <typeparam name='T'>
		/// The generic data type.
		/// </typeparam>
		public Dictionary<string, T> GetData<T>(System.Type type)
		{
			// base types
			if(typeof(int).Equals(type))
			{
				return this.intData as Dictionary<string, T>;
			}
			else if(typeof(float).Equals(type))
			{
				return this.floatData as Dictionary<string, T>;
			}
			else if(typeof(bool).Equals(type))
			{
				return this.boolData as Dictionary<string, T>;
			}
			else if(typeof(string).Equals(type))
			{
				return this.stringData as Dictionary<string, T>;
			}
			// sub data
			else if(typeof(DataObject).Equals(type))
			{
				return this.subData as Dictionary<string, T>;
			}
			// assets
			else if(typeof(UnityEngine.Object).Equals(type))
			{
				return this.generalAssetData as Dictionary<string, T>;
			}
			// not found
			else
			{
				return null;
			}
		}

		/// <summary>
		/// Sets a list containing keys and values of a type.
		/// </summary>
		/// <param name='data'>
		/// A Dictionary<string, T> containing keys (string) and values (T).
		/// </param>
		/// <param name='type'>
		/// The data type (System.Type).
		/// </param>
		/// <typeparam name='T'>
		/// The generic data type.
		/// </typeparam>
		public void SetData<T>(Dictionary<string, T> data, System.Type type)
		{
			// base types
			if(typeof(int).Equals(type))
				this.intData = data as Dictionary<string, int>;
			else if(typeof(float).Equals(type))
				this.floatData = data as Dictionary<string, float>;
			else if(typeof(bool).Equals(type))
				this.boolData = data as Dictionary<string, bool>;
			else if(typeof(string).Equals(type))
				this.stringData = data as Dictionary<string, string>;
			// sub data
			else if(typeof(DataObject).Equals(type))
				this.subData = data as Dictionary<string, DataObject>;
			// assets
			else if(typeof(UnityEngine.Object).Equals(type))
				this.generalAssetData = data as Dictionary<string, UnityEngine.Object>;
		}


		/*
		============================================================================
		Get/Set generic arrays
		============================================================================
		*/
		/// <summary>
		/// Assign an array to a key.
		/// Enum arrays are used as integer arrays.
		/// </summary>
		/// <param name='key'>
		/// The key the array will be assigned to.
		/// </param>
		/// <param name='value'>
		/// The array that will be assigned.
		/// </param>
		/// <typeparam name='T'>
		/// The data type used.
		/// Supported types: int, float, bool, string, <see cref="GamingIsLove.Makinom.DataObject"/>.
		/// </typeparam>
		public void Set<T>(string key, T[] value)
		{
			Dictionary<string, T[]> data = this.GetArrayDataInstantiate<T>(typeof(T));
			if(data != null)
			{
				T[] newValue = new T[value.Length];
				System.Array.Copy(value, newValue, value.Length);
				data[key] = newValue;
			}
		}

		public void Set(string key, int[] value)
		{
			if(this.intArrayData == null)
			{
				this.intArrayData = new Dictionary<string, int[]>();
			}
			int[] newValue = new int[value.Length];
			// use Copy instead of BlockCopy due to possible enum arrays
			System.Array.Copy(value, newValue, value.Length);
			this.intArrayData.Add(key, newValue);
		}

		public void Set(string key, float[] value)
		{
			if(this.floatArrayData == null)
			{
				this.floatArrayData = new Dictionary<string, float[]>();
			}
			float[] newValue = new float[value.Length];
			System.Buffer.BlockCopy(value, 0, newValue, 0, value.Length * sizeof(float));
			this.floatArrayData.Add(key, newValue);
		}

		public void Set(string key, bool[] value)
		{
			if(this.boolArrayData == null)
			{
				this.boolArrayData = new Dictionary<string, bool[]>();
			}
			bool[] newValue = new bool[value.Length];
			System.Buffer.BlockCopy(value, 0, newValue, 0, value.Length * sizeof(bool));
			this.boolArrayData.Add(key, newValue);
		}

		public void Set(string key, string[] value)
		{
			if(this.stringArrayData == null)
			{
				this.stringArrayData = new Dictionary<string, string[]>();
			}
			string[] newValue = new string[value.Length];
			System.Array.Copy(value, newValue, value.Length);
			this.stringArrayData.Add(key, newValue);
		}

		public void Set(string key, DataObject[] value)
		{
			if(this.subArrayData == null)
			{
				this.subArrayData = new Dictionary<string, DataObject[]>();
			}
			this.subArrayData.Add(key, value);
		}

		public void Set(string key, Vector2[] value)
		{
			if(this.floatArrayData == null)
			{
				this.floatArrayData = new Dictionary<string, float[]>();
			}
			this.floatArrayData.Add(key, ArrayHelper.ToArray(value));
		}

		public void Set(string key, Vector3[] value)
		{
			if(this.floatArrayData == null)
			{
				this.floatArrayData = new Dictionary<string, float[]>();
			}
			this.floatArrayData.Add(key, ArrayHelper.ToArray(value));
		}

		public void Set(string key, Vector4[] value)
		{
			if(this.floatArrayData == null)
			{
				this.floatArrayData = new Dictionary<string, float[]>();
			}
			this.floatArrayData.Add(key, ArrayHelper.ToArray(value));
		}

		public void Set(string key, Rect[] value)
		{
			if(this.floatArrayData == null)
			{
				this.floatArrayData = new Dictionary<string, float[]>();
			}
			this.floatArrayData.Add(key, ArrayHelper.ToArray(value));
		}

		public void Set(string key, Color[] value)
		{
			if(this.floatArrayData == null)
			{
				this.floatArrayData = new Dictionary<string, float[]>();
			}
			this.floatArrayData.Add(key, ArrayHelper.ToArray(value));
		}

		/// <summary>
		/// Get the array assigned to a key.
		/// </summary>
		/// <param name='key'>
		/// The key to look for.
		/// </param>
		/// <param name='value'>
		/// The reference to the array holding the value.
		/// If the key is found the array is copied into this variable.
		/// Else an array with length 0 will be assigned.
		/// </param>
		/// <typeparam name='T'>
		/// The data type used.
		/// Supported types: int, float, bool, string, <see cref="GamingIsLove.Makinom.DataObject"/>.
		/// </typeparam>
		public bool Get<T>(string key, out T[] value)
		{
			Dictionary<string, T[]> data = this.GetArrayData<T>(typeof(T));
			if(data != null)
			{
				T[] array;
				if(data.TryGetValue(key, out array))
				{
					value = new T[array.Length];
					System.Array.Copy(array, value, value.Length);
					return true;
				}
			}
			value = (T[])System.Array.CreateInstance(typeof(T), 0);
			return false;
		}

		public bool Get(string key, out int[] value)
		{
			if(this.intArrayData != null)
			{
				int[] tmp;
				if(this.intArrayData.TryGetValue(key, out tmp))
				{
					value = new int[tmp.Length];
					// use Copy instead of BlockCopy due to possible enum arrays
					System.Array.Copy(tmp, value, value.Length);
					return true;
				}
			}
			value = new int[0];
			return false;
		}

		public void LoadIntArray(FieldInfo field, object instance)
		{
			if(this.intArrayData != null)
			{
				int[] tmp;
				if(this.intArrayData.TryGetValue(field.Name, out tmp))
				{
					int[] value = new int[tmp.Length];
					System.Buffer.BlockCopy(tmp, 0, value, 0, tmp.Length * sizeof(int));
					field.SetValue(instance, value);
				}
			}
		}

		public void LoadEnumArray(FieldInfo field, object instance)
		{
			if(this.intArrayData != null)
			{
				int[] tmp;
				if(this.intArrayData.TryGetValue(field.Name, out tmp))
				{
					int[] value = new int[tmp.Length];
					// use Copy instead of BlockCopy due to enum arrays
					System.Array.Copy(tmp, value, value.Length);
					field.SetValue(instance, value);
				}
			}
		}

		public bool Get(string key, out float[] value)
		{
			if(this.floatArrayData != null)
			{
				float[] tmp;
				if(this.floatArrayData.TryGetValue(key, out tmp))
				{
					value = new float[tmp.Length];
					System.Buffer.BlockCopy(tmp, 0, value, 0, tmp.Length * sizeof(float));
					return true;
				}
			}
			value = new float[0];
			return false;
		}

		public void LoadFloatArray(FieldInfo field, object instance)
		{
			if(this.floatArrayData != null)
			{
				float[] tmp;
				if(this.floatArrayData.TryGetValue(field.Name, out tmp))
				{
					float[] value = new float[tmp.Length];
					System.Buffer.BlockCopy(tmp, 0, value, 0, tmp.Length * sizeof(float));
					field.SetValue(instance, value);
				}
			}
		}

		public bool Get(string key, out bool[] value)
		{
			if(this.boolArrayData != null)
			{
				bool[] tmp;
				if(this.boolArrayData.TryGetValue(key, out tmp))
				{
					value = new bool[tmp.Length];
					System.Buffer.BlockCopy(tmp, 0, value, 0, tmp.Length * sizeof(bool));
					return true;
				}
			}
			value = new bool[0];
			return false;
		}

		public void LoadBoolArray(FieldInfo field, object instance)
		{
			if(this.boolArrayData != null)
			{
				bool[] tmp;
				if(this.boolArrayData.TryGetValue(field.Name, out tmp))
				{
					bool[] value = new bool[tmp.Length];
					System.Buffer.BlockCopy(tmp, 0, value, 0, tmp.Length * sizeof(bool));
					field.SetValue(instance, value);
				}
			}
		}

		public bool Get(string key, out string[] value)
		{
			if(this.stringArrayData != null)
			{
				string[] tmp;
				if(this.stringArrayData.TryGetValue(key, out tmp))
				{
					value = new string[tmp.Length];
					System.Array.Copy(tmp, value, value.Length);
					return true;
				}
			}
			value = new string[0];
			return false;
		}

		public void LoadStringArray(FieldInfo field, object instance)
		{
			if(this.stringArrayData != null)
			{
				string[] tmp;
				if(this.stringArrayData.TryGetValue(field.Name, out tmp))
				{
					string[] value = new string[tmp.Length];
					System.Array.Copy(tmp, value, value.Length);
					field.SetValue(instance, value);
				}
			}
		}

		public bool Get(string key, out DataObject[] value)
		{
			if(this.subArrayData != null)
			{
				if(this.subArrayData.TryGetValue(key, out value))
				{
					return true;
				}
			}
			value = new DataObject[0];
			return false;
		}

		public bool Get(string key, out Vector2[] value)
		{
			if(this.floatArrayData != null)
			{
				float[] tmp;
				if(this.floatArrayData.TryGetValue(key, out tmp))
				{
					value = ArrayHelper.GetVector2Array(tmp);
					return true;
				}
			}
			value = new Vector2[0];
			return false;
		}

		public void LoadVector2Array(FieldInfo field, object instance)
		{
			if(this.floatArrayData != null)
			{
				float[] tmp;
				if(this.floatArrayData.TryGetValue(field.Name, out tmp))
				{
					field.SetValue(instance, ArrayHelper.GetVector2Array(tmp));
				}
			}
		}

		public bool Get(string key, out Vector3[] value)
		{
			if(this.floatArrayData != null)
			{
				float[] tmp;
				if(this.floatArrayData.TryGetValue(key, out tmp))
				{
					value = ArrayHelper.GetVector3Array(tmp);
					return true;
				}
			}
			value = new Vector3[0];
			return false;
		}

		public void LoadVector3Array(FieldInfo field, object instance)
		{
			if(this.floatArrayData != null)
			{
				float[] tmp;
				if(this.floatArrayData.TryGetValue(field.Name, out tmp))
				{
					field.SetValue(instance, ArrayHelper.GetVector3Array(tmp));
				}
			}
		}

		public bool Get(string key, out Vector4[] value)
		{
			if(this.floatArrayData != null)
			{
				float[] tmp;
				if(this.floatArrayData.TryGetValue(key, out tmp))
				{
					value = ArrayHelper.GetVector4Array(tmp);
					return true;
				}
			}
			value = new Vector4[0];
			return false;
		}

		public void LoadVector4Array(FieldInfo field, object instance)
		{
			if(this.floatArrayData != null)
			{
				float[] tmp;
				if(this.floatArrayData.TryGetValue(field.Name, out tmp))
				{
					field.SetValue(instance, ArrayHelper.GetVector4Array(tmp));
				}
			}
		}

		public bool Get(string key, out Rect[] value)
		{
			if(this.floatArrayData != null)
			{
				float[] tmp;
				if(this.floatArrayData.TryGetValue(key, out tmp))
				{
					value = ArrayHelper.GetRectArray(tmp);
					return true;
				}
			}
			value = new Rect[0];
			return false;
		}

		public void LoadRectArray(FieldInfo field, object instance)
		{
			if(this.floatArrayData != null)
			{
				float[] tmp;
				if(this.floatArrayData.TryGetValue(field.Name, out tmp))
				{
					field.SetValue(instance, ArrayHelper.GetRectArray(tmp));
				}
			}
		}

		public bool Get(string key, out Color[] value)
		{
			if(this.floatArrayData != null)
			{
				float[] tmp;
				if(this.floatArrayData.TryGetValue(key, out tmp))
				{
					value = ArrayHelper.GetColorArray(tmp);
					return true;
				}
			}
			value = new Color[0];
			return false;
		}

		public void LoadColorArray(FieldInfo field, object instance)
		{
			if(this.floatArrayData != null)
			{
				float[] tmp;
				if(this.floatArrayData.TryGetValue(field.Name, out tmp))
				{
					field.SetValue(instance, ArrayHelper.GetColorArray(tmp));
				}
			}
		}

		private Dictionary<string, T[]> GetArrayDataInstantiate<T>(System.Type type)
		{
			// base types
			if(typeof(int) == type)
			{
				if(this.intArrayData == null)
				{
					this.intArrayData = new Dictionary<string, int[]>();
				}
				return this.intArrayData as Dictionary<string, T[]>;
			}
			else if(typeof(float) == type)
			{
				if(this.floatArrayData == null)
				{
					this.floatArrayData = new Dictionary<string, float[]>();
				}
				return this.floatArrayData as Dictionary<string, T[]>;
			}
			else if(typeof(bool) == type)
			{
				if(this.boolArrayData == null)
				{
					this.boolArrayData = new Dictionary<string, bool[]>();
				}
				return this.boolArrayData as Dictionary<string, T[]>;
			}
			else if(typeof(string) == type)
			{
				if(this.stringArrayData == null)
				{
					this.stringArrayData = new Dictionary<string, string[]>();
				}
				return this.stringArrayData as Dictionary<string, T[]>;
			}
			// sub data
			else if(typeof(DataObject).IsAssignableFrom(type))
			{
				if(this.subArrayData == null)
				{
					this.subArrayData = new Dictionary<string, DataObject[]>();
				}
				return this.subArrayData as Dictionary<string, T[]>;
			}
			// not found
			else
			{
				return null;
			}
		}

		/// <summary>
		/// Gets a list containing keys and values of an array type.
		/// </summary>
		/// <returns>
		/// A Dictionary<string, T[]> containing keys (string) and array values (T[]).
		/// </returns>
		/// <param name='type'>
		/// The data type (System.Type).
		/// </param>
		/// <typeparam name='T'>
		/// The generic data type.
		/// </typeparam>
		public Dictionary<string, T[]> GetArrayData<T>(System.Type type)
		{
			// base types
			if(typeof(int) == type)
			{
				return this.intArrayData as Dictionary<string, T[]>;
			}
			else if(typeof(float) == type)
			{
				return this.floatArrayData as Dictionary<string, T[]>;
			}
			else if(typeof(bool) == type)
			{
				return this.boolArrayData as Dictionary<string, T[]>;
			}
			else if(typeof(string) == type)
			{
				return this.stringArrayData as Dictionary<string, T[]>;
			}
			// sub data
			else if(typeof(DataObject).IsAssignableFrom(type))
			{
				return this.subArrayData as Dictionary<string, T[]>;
			}
			// not found
			else
			{
				return null;
			}
		}

		/// <summary>
		/// Sets a list containing keys and values of an array type.
		/// </summary>
		/// <param name='data'>
		/// A Dictionary<string, T[]> containing keys (string) and array values (T[]).
		/// </param>
		/// <param name='type'>
		/// The data type (System.Type).
		/// </param>
		/// <typeparam name='T'>
		/// The generic data type.
		/// </typeparam>
		public void SetArrayData<T>(Dictionary<string, T[]> data, System.Type type)
		{
			// base types
			if(typeof(int) == type)
			{
				this.intArrayData = data as Dictionary<string, int[]>;
			}
			else if(typeof(float) == type)
			{
				this.floatArrayData = data as Dictionary<string, float[]>;
			}
			else if(typeof(bool) == type)
			{
				this.boolArrayData = data as Dictionary<string, bool[]>;
			}
			else if(typeof(string) == type)
			{
				this.stringArrayData = data as Dictionary<string, string[]>;
			}
			// sub data
			else if(typeof(DataObject).IsAssignableFrom(type))
			{
				this.subArrayData = data as Dictionary<string, DataObject[]>;
			}
		}


		/*
		============================================================================
		Get/Add sub data
		============================================================================
		*/
		/// <summary>
		/// Gets the <see cref="GamingIsLove.Makinom.DataObject"/> assigned to a key.
		/// </summary>
		/// <returns>
		/// The <see cref="GamingIsLove.Makinom.DataObject"/> if the key is found.
		/// Returns null if the key isn't found.
		/// </returns>
		/// <param name='key'>
		/// The key to look for.
		/// </param>
		public DataObject GetFile(string key)
		{
			if(this.subData != null)
			{
				DataObject data;
				if(this.subData.TryGetValue(key, out data))
				{
					return data;
				}
			}
			return null;
		}

		/// <summary>
		/// Gets the <see cref="GamingIsLove.Makinom.DataObject"/> array assigned to a key.
		/// </summary>
		/// <returns>
		/// The <see cref="GamingIsLove.Makinom.DataObject"/> array if the key is found.
		/// Returns an array with length 0 if the key isn't found.
		/// </returns>
		/// <param name='key'>
		/// The key to look for.
		/// </param>
		public DataObject[] GetFileArray(string key)
		{
			if(this.subArrayData != null)
			{
				DataObject[] data;
				if(this.subArrayData.TryGetValue(key, out data))
				{
					return data;
				}
			}
			return null;
		}


		/*
		============================================================================
		XML string processing
		============================================================================
		*/
		public string ToXML(string name)
		{
			System.Globalization.CultureInfo tmp = System.Threading.Thread.CurrentThread.CurrentCulture;
			System.Threading.Thread.CurrentThread.CurrentCulture = System.Globalization.CultureInfo.InvariantCulture;
			string xml = this.GetXMLString(name, null);
			System.Threading.Thread.CurrentThread.CurrentCulture = tmp;
			return xml;
		}

		public string ToXML(string name, DataFile file)
		{
			System.Globalization.CultureInfo tmp = System.Threading.Thread.CurrentThread.CurrentCulture;
			System.Threading.Thread.CurrentThread.CurrentCulture = System.Globalization.CultureInfo.InvariantCulture;
			string xml = this.GetXMLString(name, file);
			System.Threading.Thread.CurrentThread.CurrentCulture = tmp;
			return xml;
		}

		private string GetXMLString(string name, DataFile file)
		{
			StringBuilder text = new StringBuilder();

			// XML node name and int values
			text.Append('<').Append(name);

			// parse int list
			if(this.intData != null && this.intData.Count > 0)
			{
				text.Append(' ');
				foreach(KeyValuePair<string, int> pair in this.intData)
				{
					text.Append(pair.Key).Append('=').Append('"').Append(pair.Value).Append('"').Append(' ');
				}
			}
			text.Append('>').Append('\n');

			// base data
			if(this.floatData != null && this.floatData.Count > 0)
			{
				text.Append("<_float ");
				foreach(KeyValuePair<string, float> pair in this.floatData)
				{
					text.Append(pair.Key).Append('=').Append('"').Append(pair.Value).Append('"').Append(' ');
				}
				text.Append('/').Append('>').Append('\n');
			}
			if(this.boolData != null && this.boolData.Count > 0)
			{
				text.Append("<_bool ");
				foreach(KeyValuePair<string, bool> pair in this.boolData)
				{
					text.Append(pair.Key).Append('=').Append('"').Append(pair.Value).Append('"').Append(' ');
				}
				text.Append('/').Append('>').Append('\n');
			}

			// arrays
			if(this.intArrayData != null && this.intArrayData.Count > 0)
			{
				text.Append("<_intarrays>\n");
				foreach(KeyValuePair<string, int[]> pair in this.intArrayData)
				{
					text.Append('<').Append(pair.Key);
					for(int i = 0; i < pair.Value.Length; i++)
					{
						text.Append(' ').Append(pair.Value[i]);
					}
					text.Append(" />\n");
				}
				text.Append("</_intarrays>\n");
			}
			if(this.floatArrayData != null && this.floatArrayData.Count > 0)
			{
				text.Append("<_floatarrays>\n");
				foreach(KeyValuePair<string, float[]> pair in this.floatArrayData)
				{
					text.Append('<').Append(pair.Key);
					for(int i = 0; i < pair.Value.Length; i++)
					{
						text.Append(' ').Append(pair.Value[i]);
					}
					text.Append(" />\n");
				}
				text.Append("</_floatarrays>\n");
			}
			if(this.boolArrayData != null && this.boolArrayData.Count > 0)
			{
				text.Append("<_boolarrays>\n");
				foreach(KeyValuePair<string, bool[]> pair in this.boolArrayData)
				{
					text.Append('<').Append(pair.Key);
					for(int i = 0; i < pair.Value.Length; i++)
					{
						text.Append(' ').Append(pair.Value[i]);
					}
					text.Append(" />\n");
				}
				text.Append("</_boolarrays>\n");
			}

			// strings and string arrays as CDATA
			if(this.stringData != null && this.stringData.Count > 0)
			{
				text.Append("<_string>\n");
				foreach(KeyValuePair<string, string> pair in this.stringData)
				{
					text.Append('<').Append(pair.Key).
						Append("><![CDATA[").Append(pair.Value).Append("]]></").
						Append(pair.Key).Append('>').Append('\n');
				}
				text.Append("</_string>\n");
			}
			if(this.stringArrayData != null && this.stringArrayData.Count > 0)
			{
				text.Append("<_stringarrays>\n");
				foreach(KeyValuePair<string, string[]> pair in this.stringArrayData)
				{
					text.Append('<').Append(pair.Key).Append('>').Append('\n');
					for(int i = 0; i < pair.Value.Length; i++)
					{
						text.Append('<').Append(i).
							Append("><![CDATA[").Append(pair.Value[i]).Append("]]></").
							Append(i).Append('>').Append('\n');
					}
					text.Append('<').Append('/').Append(pair.Key).Append('>').Append('\n');
				}
				text.Append("</_stringarrays>\n");
			}

			// assets
			if(file != null && this.generalAssetData != null && this.generalAssetData.Count > 0)
			{
				text.Append("<_asset");
				foreach(KeyValuePair<string, UnityEngine.Object> pair in this.generalAssetData)
				{
					text.Append(' ').Append(pair.Key).Append('=').Append('"').
						Append(file.LookUp.AddAsset(pair.Value)).Append('"');
				}
				text.Append(" />\n");
			}

			// sub files
			if(this.subData != null && this.subData.Count > 0)
			{
				foreach(KeyValuePair<string, DataObject> pair in this.subData)
				{
					if(pair.Value != null)
					{
						text.Append(pair.Value.GetXMLString(pair.Key, file));
					}
				}
			}
			if(this.subArrayData != null && this.subArrayData.Count > 0)
			{
				text.Append("<_subarrays>\n");
				foreach(KeyValuePair<string, DataObject[]> pair in this.subArrayData)
				{
					if(pair.Value != null)
					{
						text.Append('<').Append(pair.Key).Append('>').Append('\n');
						for(int i = 0; i < pair.Value.Length; i++)
						{
							if(pair.Value[i] == null)
							{
								text.Append('<').Append(i).Append('>').Append('<').Append('/').Append(i).Append('>').Append('\n');
							}
							else
							{
								text.Append(pair.Value[i].GetXMLString(i.ToString(), file));
							}
						}
						text.Append('<').Append('/').Append(pair.Key).Append('>').Append('\n');
					}
				}
				text.Append("</_subarrays>\n");
			}


			// close XML file node
			text.Append('<').Append('/').Append(name).Append('>').Append('\n');

			return text.ToString();
		}


		/*
		============================================================================
		DataFile processing
		============================================================================
		*/
		/// <summary>
		/// Converts the data into a <see cref="GamingIsLove.Makinom.DataFile"/>, writing the data as a byte array.
		/// </summary>
		/// <param name='name'>
		/// The name of the data file.
		/// </param>
		/// <param name='encrypt'>
		/// The byte array data will be encrypted.
		/// </param>
		/// <returns>
		/// A <see cref="GamingIsLove.Makinom.DataFile"/> that represents the current data of the <see cref="GamingIsLove.Makinom.DataObject"/>.
		/// </returns>
		public DataFile GetDataFile(string name, bool encrypt, DataFile.SaveFormatType format)
		{
			DataFile file = new DataFile(name, encrypt);
			if(DataFile.SaveFormatType.XMLString == format)
			{
				string xml = null;
				try
				{
					xml = this.ToXML("xmldata", file);
				}
				finally
				{
					file.SetXMLData(xml);
				}
			}
			else
			{
				ByteDataWriter writer = new ByteDataWriter(encrypt);
				try
				{
					this.WriteData(writer, file);
				}
				finally
				{
					file.SetData(writer.Close());
				}
			}
			return file;
		}

		public ComponentDataFile GetComponentDataFile(string name, bool encrypt)
		{
			ComponentDataFile file = new ComponentDataFile(name, encrypt);
			string xml = null;
			try
			{
				xml = this.ToXML("xmldata", file);
			}
			finally
			{
				file.SetXMLData(xml);
			}
			/*ByteDataWriter writer = new ByteDataWriter(encrypt);
			try
			{
				this.WriteData(writer, file);
			}
			finally
			{
				file.SetData(writer.Close());
			}*/
			return file;
		}

		private void WriteData(ByteDataWriter writer, DataFile file)
		{
			// single data
			// int
			writer.Write(this.intData != null ? this.intData.Count : 0);
			if(this.intData != null && this.intData.Count > 0)
			{
				foreach(KeyValuePair<string, int> pair in this.intData)
				{
					writer.Write(pair.Key);
					writer.Write(pair.Value);
				}
			}
			// float
			writer.Write(this.floatData != null ? this.floatData.Count : 0);
			if(this.floatData != null && this.floatData.Count > 0)
			{
				foreach(KeyValuePair<string, float> pair in this.floatData)
				{
					writer.Write(pair.Key);
					writer.Write(pair.Value);
				}
			}
			// bool
			writer.Write(this.boolData != null ? this.boolData.Count : 0);
			if(this.boolData != null && this.boolData.Count > 0)
			{
				foreach(KeyValuePair<string, bool> pair in this.boolData)
				{
					writer.Write(pair.Key);
					writer.Write(pair.Value);
				}
			}
			// string
			writer.Write(this.stringData != null ? this.stringData.Count : 0);
			if(this.stringData != null && this.stringData.Count > 0)
			{
				foreach(KeyValuePair<string, string> pair in this.stringData)
				{
					writer.Write(pair.Key);
					writer.Write(pair.Value);
				}
			}

			// array data
			// int array
			writer.Write(this.intArrayData != null ? this.intArrayData.Count : 0);
			if(this.intArrayData != null && this.intArrayData.Count > 0)
			{
				foreach(KeyValuePair<string, int[]> pair in this.intArrayData)
				{
					writer.Write(pair.Key);
					writer.Write(pair.Value);
				}
			}
			// float array
			writer.Write(this.floatArrayData != null ? this.floatArrayData.Count : 0);
			if(this.floatArrayData != null && this.floatArrayData.Count > 0)
			{
				foreach(KeyValuePair<string, float[]> pair in this.floatArrayData)
				{
					writer.Write(pair.Key);
					writer.Write(pair.Value);
				}
			}
			// bool array
			writer.Write(this.boolArrayData != null ? this.boolArrayData.Count : 0);
			if(this.boolArrayData != null && this.boolArrayData.Count > 0)
			{
				foreach(KeyValuePair<string, bool[]> pair in this.boolArrayData)
				{
					writer.Write(pair.Key);
					writer.Write(pair.Value);
				}
			}
			// string array
			writer.Write(this.stringArrayData != null ? this.stringArrayData.Count : 0);
			if(this.stringArrayData != null && this.stringArrayData.Count > 0)
			{
				foreach(KeyValuePair<string, string[]> pair in this.stringArrayData)
				{
					writer.Write(pair.Key);
					writer.Write(pair.Value);
				}
			}

			// asset
			writer.Write(this.generalAssetData != null ? this.generalAssetData.Count : 0);
			if(this.generalAssetData != null && this.generalAssetData.Count > 0)
			{
				foreach(KeyValuePair<string, UnityEngine.Object> pair in this.generalAssetData)
				{
					writer.Write(pair.Key);
					writer.Write(file.LookUp.AddAsset(pair.Value));
				}
			}

			// sub file
			writer.Write(this.subData != null ? this.subData.Count : 0);
			if(this.subData != null && this.subData.Count > 0)
			{
				foreach(KeyValuePair<string, DataObject> pair in this.subData)
				{
					writer.Write(pair.Key);
					writer.Write(pair.Value != null);
					if(pair.Value != null)
					{
						pair.Value.WriteData(writer, file);
					}
				}
			}
			// sub file array
			writer.Write(this.subArrayData != null ? this.subArrayData.Count : 0);
			if(this.subArrayData != null && this.subArrayData.Count > 0)
			{
				foreach(KeyValuePair<string, DataObject[]> pair in this.subArrayData)
				{
					writer.Write(pair.Key);
					writer.Write(pair.Value != null ? pair.Value.Length : 0);
					for(int i = 0; i < pair.Value.Length; i++)
					{
						writer.Write(pair.Value[i] != null);
						if(pair.Value[i] != null)
						{
							pair.Value[i].WriteData(writer, file);
						}
					}
				}
			}
		}

		private void ReadData(FastByteDataReader reader, DataFile file)
		{
			// single data
			// int
			int count = reader.ReadInt();
			if(count > 0)
			{
				this.intData = new Dictionary<string, int>();
				for(int i = 0; i < count; i++)
				{
					this.intData.Add(reader.ReadString(), reader.ReadInt());
				}
			}
			// float
			count = reader.ReadInt();
			if(count > 0)
			{
				this.floatData = new Dictionary<string, float>();
				for(int i = 0; i < count; i++)
				{
					this.floatData.Add(reader.ReadString(), reader.ReadFloat());
				}
			}
			// bool
			count = reader.ReadInt();
			if(count > 0)
			{
				this.boolData = new Dictionary<string, bool>();
				for(int i = 0; i < count; i++)
				{
					this.boolData.Add(reader.ReadString(), reader.ReadBool());
				}
			}
			// string
			count = reader.ReadInt();
			if(count > 0)
			{
				this.stringData = new Dictionary<string, string>();
				for(int i = 0; i < count; i++)
				{
					this.stringData.Add(reader.ReadString(), reader.ReadString());
				}
			}

			// array data
			// int array
			count = reader.ReadInt();
			if(count > 0)
			{
				this.intArrayData = new Dictionary<string, int[]>();
				for(int i = 0; i < count; i++)
				{
					this.intArrayData.Add(reader.ReadString(), reader.ReadArrayInt());
				}
			}
			// float array
			count = reader.ReadInt();
			if(count > 0)
			{
				this.floatArrayData = new Dictionary<string, float[]>();
				for(int i = 0; i < count; i++)
				{
					this.floatArrayData.Add(reader.ReadString(), reader.ReadArrayFloat());
				}
			}
			// bool array
			count = reader.ReadInt();
			if(count > 0)
			{
				this.boolArrayData = new Dictionary<string, bool[]>();
				for(int i = 0; i < count; i++)
				{
					this.boolArrayData.Add(reader.ReadString(), reader.ReadArrayBool());
				}
			}
			// string array
			count = reader.ReadInt();
			if(count > 0)
			{
				this.stringArrayData = new Dictionary<string, string[]>();
				for(int i = 0; i < count; i++)
				{
					this.stringArrayData.Add(reader.ReadString(), reader.ReadArrayString());
				}
			}

			// asset
			count = reader.ReadInt();
			if(count > 0)
			{
				this.generalAssetData = new Dictionary<string, UnityEngine.Object>();
				for(int i = 0; i < count; i++)
				{
					this.generalAssetData.Add(reader.ReadString(), file.LookUp.GetAsset(reader.ReadInt()));
				}
			}

			// sub file
			count = reader.ReadInt();
			if(count > 0)
			{
				this.subData = new Dictionary<string, DataObject>();
				for(int i = 0; i < count; i++)
				{
					string key = reader.ReadString();
					if(reader.ReadBool())
					{
						DataObject dataObject = new DataObject();
						dataObject.ReadData(reader, file);
						this.subData.Add(key, dataObject);
					}
					else
					{
						this.subData.Add(key, null);
					}
				}
			}
			// sub file array
			count = reader.ReadInt();
			if(count > 0)
			{
				this.subArrayData = new Dictionary<string, DataObject[]>();
				for(int i = 0; i < count; i++)
				{
					string key = reader.ReadString();
					DataObject[] dataObject = new DataObject[reader.ReadInt()];
					if(dataObject.Length > 0)
					{
						for(int j = 0; j < dataObject.Length; j++)
						{
							if(reader.ReadBool())
							{
								dataObject[j] = new DataObject();
								dataObject[j].ReadData(reader, file);
							}
						}
					}
					this.subArrayData.Add(key, dataObject);
				}
			}
		}
	}
}
