﻿
using UnityEngine;
using System.Collections.Generic;
using System.IO;
using System.Security.Cryptography;

namespace GamingIsLove.Makinom.IO
{
	public class ByteDataReader
	{
		private static System.Text.UTF8Encoding encoding = new System.Text.UTF8Encoding();

		private readonly MemoryStream memoryStream;

		private readonly BinaryReader binaryReader;

		public ByteDataReader(byte[] data, bool decrypt)
		{
			this.memoryStream = new MemoryStream(decrypt ? Maki.SecurityHandler.Decrypt(data) : data);
			this.binaryReader = new BinaryReader(this.memoryStream, encoding);
		}

		public void Close()
		{
			this.binaryReader.Close();
			this.memoryStream.Close();
		}


		/*
		============================================================================
		Value functions
		============================================================================
		*/
		public bool ReadBool()
		{
			return this.binaryReader.ReadBoolean();
		}

		public int ReadInt()
		{
			return this.binaryReader.ReadInt32();
		}

		public float ReadFloat()
		{
			return this.binaryReader.ReadSingle();
		}

		public string ReadString()
		{
			return this.binaryReader.ReadString();
		}


		/*
		============================================================================
		List/array functions
		============================================================================
		*/
		public int[] ReadArrayInt()
		{
			int[] array = new int[this.binaryReader.ReadInt32()];
			for(int i = 0; i < array.Length; i++)
			{
				array[i] = this.binaryReader.ReadInt32();
			}
			return array;
		}

		public float[] ReadArrayFloat()
		{
			float[] array = new float[this.binaryReader.ReadInt32()];
			for(int i = 0; i < array.Length; i++)
			{
				array[i] = this.binaryReader.ReadSingle();
			}
			return array;
		}

		public bool[] ReadArrayBool()
		{
			bool[] array = new bool[this.binaryReader.ReadInt32()];
			for(int i = 0; i < array.Length; i++)
			{
				array[i] = this.binaryReader.ReadBoolean();
			}
			return array;
		}

		public string[] ReadArrayString()
		{
			string[] array = new string[this.binaryReader.ReadInt32()];
			for(int i = 0; i < array.Length; i++)
			{
				array[i] = this.binaryReader.ReadString();
			}
			return array;
		}
	}
}
