﻿
using UnityEngine;
using System.Collections.Generic;

namespace GamingIsLove.Makinom
{
	[System.AttributeUsage(System.AttributeTargets.Class, AllowMultiple = false)]
	public class EditorSettingInfoAttribute : System.Attribute
	{
		// index:
		// 0 = name
		// 1 = text
		// 2 = info
		public GUIContent content;

		public string listName;

		public int sortIndex = -1;

		public EditorSettingInfoAttribute(string name, string text) :
			this(name, text, name)
		{

		}

		public EditorSettingInfoAttribute(string name, string text, string listName)
		{
			this.content = new GUIContent(name, text);
			this.listName = string.IsNullOrEmpty(listName) ? name : listName;
		}
	}
}
